# Details.pm: Details Conversions for OIM Reports

package Convert::OFM::OIM::Details;

# $Id: Details.pm,v 1.6 2014/08/19 16:13:58 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/Convert/OFM/OIM/Details.pm,v 1.6 2014/08/19 16:13:58 RDA Exp $
#
# Change History
# 20140819  MSC  Improve the documentation.

=head1 NAME

Convert::OFM::OIM::Details - Details Conversions for OFM.OIM Reports

=head1 SYNOPSIS

 require Convert::OFM::OIM::Details;

=head1 DESCRIPTION

This package regroups conversion methods of C<Details> cells contained in the
OFM.OIM module reports.

It is only provided as plugin example and is thus incomplete by nature.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::Text qw(get_string);
  use RDA::Driver::Convert;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA %PLUGIN);
$VERSION = sprintf('%d.%02d', q$Revision: 1.6 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(Exporter);
%PLUGIN  = (
  cnv => [{blk => {
             db_connect => [
               [qr{^Database Connectivity Check$},  ## no critic (Fix)
                {q{*}      => 'sdp_table',
                 'details' => \&fmt_details,
                }]],
             },
           nam => 'Details Conversions',
           rnk => 10,
           sel => \&RDA::Driver::Convert::sel_block,
           typ => 'T',
         },
        ],
  );

# Define the global private constants

# Define the global private variables

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<fmt_details($ctl,$str)>

This method converts the details cell content.

=cut

sub fmt_details
{ my ($ctl, $str) = @_;
  my ($buf, $cnt);

  $buf = q{};
  $cnt = 0;
  $str =~ s/\`\`//g;
  $str =~ s/&nbsp;/ /g;
  foreach my $lin (split(/\%BR\%/, $str))
  { if ($lin =~ s/^\s+//)
    { $buf .= qq{<sdp_detail parameter='$1' value='$2'/>\n}
        if $lin =~ m/^([^:]*):\s*(.*)$/;
    }
    elsif ($lin)
    { $buf .= qq{</sdp_details></sdp_test>\n} if $cnt++;
      $buf .= qq{<sdp_test desc='$lin'><sdp_details>\n};
    }
  }
  $buf .= qq{</sdp_details></sdp_test>\n} if $cnt;
  return $buf;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Driver::Convert|RDA::Driver::Convert>,
L<RDA::Request::CONVERT|RDA::Request::CONVERT>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
