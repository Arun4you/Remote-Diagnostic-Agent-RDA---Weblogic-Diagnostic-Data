# Linux.pm: Linux-specific Conversions for OS.OS Reports

package Convert::OS::OS::Linux;

# $Id: Linux.pm,v 1.6 2014/08/19 16:13:58 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/Convert/OS/OS/Linux.pm,v 1.6 2014/08/19 16:13:58 RDA Exp $
#
# Change History
# 20140819  MSC  Improve the documentation.

=head1 NAME

Convert::OS::OS::Linux - Linux-specific Conversions for OS.OS Reports

=head1 SYNOPSIS

 require Convert::OS::OS::Linux;

=head1 DESCRIPTION

This package regroups Linux-specific conversion methods for the OS.OS module
reports.

It is only provided as plugin example and is thus incomplete by nature.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::Text qw(get_string);
  use RDA::Driver::Convert;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA %PLUGIN);
$VERSION = sprintf('%d.%02d', q$Revision: 1.6 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(Exporter);
%PLUGIN  = (
  cnv => [{blk => {
            cpu_info => [
             [qr{^CPU Information$},                       ## no critic (Fix)
             \&ext_value]],
            memory_info => [
             [qr{^Physical Memory Installed$},             ## no critic (Fix)
             \&ext_value]],
            services => [
             [qr{^Runlevel Information for System Services$}, ## no critic (Fix)
             \&ext_svc_level],
             [qr{^System Service Status$},                  ## no critic (Fix)
             \&ext_svc_status]],
            sysdef => [
             [qr{^System/Kernel Settings$},                 ## no critic (Fix)
             \&ext_sysdef_info]],
            },
           nam => 'Linux-specific Conversions',
           osn => 'linux',
           rnk => 10,
           sel => \&RDA::Driver::Convert::sel_block,
           typ => 'B',
          },
          {blk => {
             packages => [
               [qr{^Operating System Package Information$}, ## no critic (Fix)
                {q{*} => 'package_list'}]],
             sysdef => [
               [qr{^Main Kernel Parameters$},               ## no critic (Fix)
                {q{*} => 'kernel_parameters'}]],
             },
           nam => 'Linux-specific Custom Table Tags',
           osn => 'linux',
           rnk => 10,
           sel => \&RDA::Driver::Convert::sel_block,
           typ => 'T',
          },
         ],
  );

# Define the global private constants

# Define the global private variables
my %tb_val = (
  'CPU Information'           => 'cpu_details',
  'Physical Memory Installed' => 'mem_details',
  );

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<ext_svc_level($ctl,$ofh,$blk)>

This method converts C<chkconfig --list> output.

=cut

sub ext_svc_level
{ my ($ctl, $ofh, $blk) = @_;
  my ($lin, $sum, $svc, @lvl, @xml);

  # Treat init level part
  print {$ofh} qq{<service_levels summary='$blk'>\n};
  while (defined($lin = $ctl->get_line))
  { if ($lin =~ m/^([\w\s]*):$/)
    { $sum = $1;
      last;
    }
    ($svc, @lvl, @xml) = split(/\s+/, $lin);
    foreach my $lvl (@lvl)
    { push(@xml, qq{init$1='$2'}) if $lvl =~ m/^(\d):(.*)$/;
    }
    print {$ofh} qq{<sdp_row service='$svc' }.join(q{ }, @xml).qq{/>\n};
  }
  print {$ofh} qq{</service_levels>\n};

  # Treat other part
  if ($sum)
  { print {$ofh} qq{<sdp_table summary='$sum'>\n};
    while (defined($lin = $ctl->get_line))
    { if ($lin =~ m/^\s+(.*):\s*(.+)$/)
      { print {$ofh} qq{<sdp_row service='$1' status='$2'/>\n};
      }
      else
      { $ctl->trace(4, qq{** skipping: $lin});
      }
    }
    print {$ofh} qq{</sdp_table>\n};
  }
  return;
}

=head2 S<ext_svc_status($ctl,$ofh,$blk)>

This method converts C<service --status-all> output.

=cut

sub ext_svc_status
{ my ($ctl, $ofh, $blk) = @_;
  my ($lin);

  print {$ofh} qq{<service_statuses summary='$blk'>\n};
  while (defined($lin = $ctl->get_line))
  { if ($lin =~ m/^(.*) is (.*)\.*$/ || $lin =~ m/^(.*) ((dead|loaded).*)$/)
    { print {$ofh} qq{<sdp_row service='$1' status='$2'/>\n};
    }
    elsif ($lin)
    { $ctl->trace(4, qq{** skipping: $lin});
    }
  }
  print {$ofh} qq{</service_statuses>\n};
  return;
}

=head2 S<ext_sysdef_info($ctl,$ofh,$blk)>

This method converts C<sysdef> output.

=cut

sub ext_sysdef_info
{ my ($ctl, $ofh, $blk) = @_;
  my ($key, $lin, $val);

  print {$ofh} qq{<sysdef_details summary='$blk'>\n};
  while (defined($lin = $ctl->get_line))
  { ($key, $val) = split(/\s*=\s*/, $lin);
    print {$ofh} qq{<sdp_row parameter='$key' value='$val'/>\n};
  }
  print {$ofh} qq{</sysdef_details>\n};
  return;
}

=head2 S<ext_value($ctl,$ofh,$blk)>

This method converts C<parameter:value> pairs.

=cut

sub ext_value
{ my ($ctl, $ofh, $blk) = @_;
  my ($key, $lin, $tag, $val);

  $tag = exists($tb_val{$blk}) ? $tb_val{$blk} : 'sdp_table';
  print {$ofh} qq{<$tag summary='$blk'>\n};
  while (defined($lin = $ctl->get_line))
  { next unless $lin;
    ($key, $val) = split(/\s*:\s*/, $lin);
    print {$ofh} qq{<sdp_row parameter='$key' value='$val'/>\n}
      if defined($key) && defined($val);
  }
  print {$ofh} qq{</$tag>\n};
  return;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Driver::Convert|RDA::Driver::Convert>,
L<RDA::Request::CONVERT|RDA::Request::CONVERT>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
