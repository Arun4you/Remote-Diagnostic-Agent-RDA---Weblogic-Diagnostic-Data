# Adrci.pm: Discovery Plug-in Related to adrci

package IRDA::CV0200::Adrci;

# $Id: Adrci.pm,v 1.7 2013/11/22 11:37:06 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/IRDA/CV0200/Adrci.pm,v 1.7 2013/11/22 11:37:06 RDA Exp $
#
# Change History
# 20131115  MSC  Improve the documentation.

=head1 NAME

IRDA::CV0200::Adrci - Discovery Plug-in Related to F<adrci>

=head1 SYNOPSIS

 require IRDA::CV0200::Adrci;

=head1 DESCRIPTION

This package regroups the definition of the discovery mechanisms for getting
values from F<adrci>.

The following methods are available:

=cut

use strict;

BEGIN
{ use RDA::Text qw(get_string);
  use RDA::Object::Rda;
}

# Define the global public variables
use vars qw($STRINGS $VERSION $PLUGIN);
$VERSION = sprintf('%d.%02d', q$Revision: 1.7 $ =~ /(\d+)\.(\d+)/);

# Define the global private variables
my %tb_run = (
  'get_incident_date'  => \&_get_incident_date,
  );

# Report the module version number
sub Version
{ return $VERSION;
}

=head2 S<$h = IRDA::CV0200::Adrci-E<gt>load($tbl)>

This method loads the mechanism definition in the mechanism table.

=cut

sub load
{ my ($cls, $tbl) = @_;

  foreach my $nam (keys(%tb_run))
  { $tbl->{$nam} = $tb_run{$nam};
  }
  return;
}

=head1 OPERATOR DEFINITIONS

=head2 get_incident_date - Get date from incident

This discovery mechanism retrieves the incident date by using F<adrci>.

=cut

sub _get_incident_date
{ my ($slf, $nam) = @_;
  my ($beg, $cmd, $end, $env, $id, $ora, $sid, $sys, $trc, @adr, @tbl);

  $sys = $slf->get_system;
  $trc = $slf->get_trace;

  # Set ADRCI environment
  die get_string('NO_INCIDENT')
    unless defined($id = $slf->get_request_value('INCIDENT_ID'));
  die get_string('NO_ORACLE_HOME')
    unless defined($ora = $slf->get_request_value('ORACLE_HOME'));

  $env = {ORACLE_HOME => $ora};
  $env->{'ORACLE_SID'}  = $sid
    if defined($sid = $slf->get_request_value('ORACLE_SID'));

  # Assemble the ADRCI command
  $cmd = RDA::Object::Rda->clean_path($slf->get_request_value('ADR_HOME'), 1);
  die get_string('NO_ADR_HOME') unless defined($cmd);
  if (RDA::Object::Rda->is_windows)
  { (undef, @tbl) = split(/\\/, $cmd);
  }
  else
  { (undef, @tbl) = split(/\//, $cmd);
  }
  @adr = splice(@tbl, -4);
  die get_string('BAD_ADR_HOME', $cmd) unless (scalar @adr) == 4;
  $cmd = RDA::Object::Rda->quote(RDA::Object::Rda->cat_file($ora, 'bin',
    'adrci'));
  if (RDA::Object::Rda->is_windows)
  { $cmd .= ' exec=set homepath '.join('\\\\', @adr)
      .';query (create_time) incident -p \\\\\\"incident_id='.$id.'\\\\\\"';
  }
  elsif (RDA::Object::Rda->is_cygwin)
  { $cmd .=  ' exec=\'set homepath '.join('\\\\', @adr)
      .';query (create_time) incident -p \\"incident_id='.$id.'\\"\'';
  }
  elsif (RDA::Object::Rda->is_vms)
  { $cmd = 'PIPE '.$cmd.' exec=\'set homepath '.join(q{/}, @adr)
      .';query (create_time) incident -p \"incident_id='.$id.'\"\'';
  }
  else
  { $cmd .= ' exec=\'set homepath '.join(q{/}, @adr)
      .';query (create_time) incident -p \"incident_id='.$id.'\"\'';
  }
  print "[Adrci/get_incident_date] exec: $cmd\n" if $trc;

  # Run the adrci command and parse the output
  $env = $sys->set_context($env);
  open(OUT, "$cmd |")  ## no critic (Handle,Open)
    or die get_string('ERR_ADRCI', $!);
  while(<OUT>)
  { s/[\n\r\s]+$//;
    print "adrci> $_\n" if $trc;
    if (m/^(\d{4})-(\d{2})-(\d{2})\s(\d{2}):(\d{2}):(\d{2})/)
    { @tbl = ($6, $5, $4, $3, $2 - 1, $1 - 1900, 0, 0, -1);
      last;
    }
  }
  close(OUT);
  $sys->restore_context($env);

  # Derive the time stamps
  eval {
    require POSIX;
    ## no critic qw(Call,Number)
    POSIX::tzset();
    $beg = $end = POSIX::mktime(@tbl);
    $beg -= 3600 * $slf->get_prepare_value('hours_before_incident', 1);
    $end += 3600 * $slf->get_prepare_value('hours_after_incident', 0.5);
    $beg = POSIX::strftime('%d-%b-%Y_%H:%M:%S', localtime($beg));
    $end = POSIX::strftime('%d-%b-%Y_%H:%M:%S', localtime($end));
  };
  die get_string('ERR_TIMESTAMP', $@) if $@;
  $slf->set_change('DB.LOG.B_RUN_MERGE',   1);
  $slf->set_change('DB.LOG.T_MERGE_BEGIN', $beg);
  $slf->set_change('DB.LOG.T_MERGE_END',   $end);
  $slf->set_change('DB.LOG.W_MERGE_SET',   'adr');
  return;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Object::Rda|RDA::Object::Rda>,
L<RDA::Object::View|RDA::Object::View>,
L<IRDA::Prepare|IRDA::Prepare>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
