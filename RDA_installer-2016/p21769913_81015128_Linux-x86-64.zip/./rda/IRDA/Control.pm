# Control.pm: IRDA Control Commands

package IRDA::Control;

# $Id: Control.pm,v 1.11 2015/05/08 18:25:43 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/IRDA/Control.pm,v 1.11 2015/05/08 18:25:43 RDA Exp $
#
# Change History
# 20150508  MSC  Improve the documentation.

=head1 NAME

IRDA::Control - IRDA Control Commands

=head1 SYNOPSIS

 require IRDA::Control;

=head1 DESCRIPTION

The following management methods are available:

=cut

use strict;

BEGIN
{ use File::Basename qw(basename dirname);
  use File::Copy qw(copy);
  use IO::Handle;
  use IO::File;
  use RDA::Text qw(get_string);
  use RDA::Object::Content qw($RE_MOD);
  use RDA::Object::Rda qw($CREATE);
}

# Define the global public variables
use vars qw($STRINGS $VERSION);
$VERSION = sprintf('%d.%02d', q$Revision: 1.11 $ =~ /(\d+)\.(\d+)/);

# Define the global private constants
my $CNF = 'irdacfg.ini';
my $EXT = qr/\.(vms|win|cyg|ini)$/;
my $VER = 'cv0200';

# Define the global private variables
my @tb_fil = ('irda.pl');
my @tb_trc = (q{}, 't:', 'T:', 'T:', 'T:', 'T:', 'T:', 'T:', 'T:', 'T:');

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<IRDA::Control-E<gt>check($agt,$opt)>

This method checks the IRDA configuration.

=cut

sub check
{ my ($agt, $opt) = @_;
  my ($dsp, $obj);

  $dsp = $agt->is_verbose;

  # Load the request parameters, the rules and the plug-ins
  $dsp->dsp_line(get_string('VI_Load')) if $dsp;
  eval 'require IRDA::Prepare';
  $agt->abort($@, get_string('ERR_REQUIRE', 'IRDA::Prepare')) if $@;
  $obj = IRDA::Prepare->new($agt, $VER);
  $obj->load_rules;
  $obj->load_plugins;

  # Check the rule files
  return 1 if $obj->check_rules($opt->{'f'});

  # Indicate the completion status
  $dsp->dsp_line(get_string('NoErrors')) if $dsp;
  return 0;
}

=head2 S<IRDA::Control-E<gt>check($agt,$opt,@ora)>

This method installs an IRDA bootstrap in Oracle homes.

=cut

sub do_install  ## no critic (Complex)
{ my ($agt, $opt, @ora) = @_;
  my ($cfg, $cnf, $cnt, $dsp, $dst, $ext, $frc, $ifh, $ofh, $pro, $rda, $src,
      $top);

  $cfg = $agt->get_config;
  $dsp = $agt->is_verbose;
  $top = $cfg->get_group('D_RDA');

  # Check the prototype file and its extension
  $cnf = $CNF;
  if (defined($pro = $opt->{'c'}))
  { die get_string('NO_PROTOTYPE', $pro)  unless -f $pro;
    die get_string('BAD_PROTOTYPE', $pro) unless $pro =~ $EXT;
    $ext = lc($1);
    $cnf =~ s/\.ini$/.$ext/;
  }

  # Create the bootstrap in the target directories
  $frc = $opt->{'f'};
  foreach my $ora (@ora)
  { # Check the target directory
    die get_string('NO_TARGET', $ora) unless -d $ora;
    $rda = $cfg->cat_dir($ora, 'rda');
    $dsp->dsp_line('VI_Bootstrap', $rda) if $dsp;
    if (-e $rda)
    { die get_string('NO_RDA', $rda) unless $frc;
      die get_string('BAD_RDA', $rda) unless -d $rda;
    }
    else
    { mkdir($rda, 0755)  ## no critic (Number)
        or die get_string('ERR_MKDIR', $rda, $!);
    }

    # Copy the script files
    foreach my $fil (@tb_fil)
    { $src = $cfg->cat_file($top, $fil);
      next unless -e $src;
      $dst = $cfg->cat_file($rda, $fil);

      # Remove any existent version
      if (-f $dst)
      { $cnt = 0;
        $cnt++ while unlink($dst);
        die get_string('ERR_UNLINK', $dst, $!) unless $cnt;
      }

      # Copy the file
      copy($src, $dst) or die get_string('ERR_INSTALL', $dst, $!);
      chmod(0555, $dst);  ## no critic (Number)
    }

    # Create the configuration file
    $dst = $cfg->cat_file($rda, $cnf);
    if (-f $dst)
    { $cnt = 0;
      $cnt++ while unlink($dst);
      die get_string('ERR_UNLINK', $dst, $!) unless $cnt;
    }
    $ofh = IO::File->new;
    $ofh->open($dst, $CREATE, 0644)  ## no critic (Number,Zero)
      or die get_string('ERR_CREATE', $dst, $!);
    binmode($ofh);
    print {$ofh} "RDA_HOME=\"$top\"\n";
    if (defined($pro))
    { $ifh = IO::File->new;
      $ifh->open("<$pro")
        or die get_string('ERR_OPEN', $pro, $!);
      while(<$ifh>)
      { s/[\n\r\s]+$//;
        print {$ofh} "$_\n" unless m/^RDA_HOME=/;
      }
      $ifh->close;
    }
    $ofh->close;
    chmod(0444, $dst);
  }

  # Indicate the successful completion
  return 0;
}

=head2 S<IRDA::Control-E<gt>run($agt,$opt,$req)>

This method performs an RDA collection.

=cut

sub run
{ my ($agt, $opt, $req) = @_;
  my ($cfg, $cnf, $cnt, $col, $dsp, $key, $obj, $ofh, $val, @mod);

  $cfg = $agt->get_config;
  $col = $agt->get_collector;
  $dsp = $agt->is_verbose;

  # Open the progress log
  $cnf = $agt->get_info('aux');
  unless (exists($cnf->{'RDA_NO_PROGRESS'}))
  { $ofh = IO::File->new;
    $col->set_progress($ofh, "RDA %s/%s: %s\n", 2)
      if $ofh->open('>>'.$cfg->cat_file($cfg->{'D_PAR'}, 'progress.log'));
  }

  # Load the rules and the plug-ins
  $cnt = 1;
  $col->log_progress(get_string('Prepare'));
  $dsp->dsp_line(get_string('VI_Load')) if $dsp;
  eval 'require IRDA::Prepare';
  $agt->abort($@, get_string('ERR_REQUIRE', 'IRDA::Prepare')) if $@;
  $obj = IRDA::Prepare->new($agt, $VER,
    (exists($cnf->{'RDA_PREPARE'}) && $cnf->{'RDA_PREPARE'} =~ m/^(\d)$/)
      ? $1
      : $agt->get_level % 10);
  $obj->load_rules;
  $obj->load_plugins;

  # Resolve the rule selection settings
  $dsp->dsp_line(get_string('VI_Select')) if $dsp;
  $obj->apply_selections($req, $cnf);

  # Discover the module settings
  $dsp->dsp_line(get_string('VI_Discover')) if $dsp;
  $obj->discover_settings;

  # Setup RDA
  $dsp->dsp_line(get_string('VI_Setup')) if $dsp;
  $col->set_profile($obj);
  foreach my $mod ($obj->get_modules)
  { $val = 0;
    if ($mod =~ $RE_MOD)
    { $key = 'TRACE_'.uc($2).'_'.uc($4);
      $val = $1
        if exists($cnf->{$key}) && $cnf->{$key} =~ m/^(\d)$/;
    }
    push(@mod, $tb_trc[$val].$mod);
  }
  $col->add_setup([], 1, 1, @mod);
  $col->end_setup(0);

  # Collect diagnostic information
  $dsp->dsp_line(get_string('VI_Collect')) if $dsp;
  $col->add_collect([], @mod);
  $col->reset_progress(1);
  $col->end_collect(0);

  # Render RDA
  $col->log_progress(get_string('Render'));
  $dsp->dsp_line(get_string('VI_Render')) if $dsp;
  $agt->submit(q{.}, 'RENDER.GEN_HTML');

  # Close the progress log
  $col->log_progress([get_string('End'), "\n"]);

  # Cleanup
  $col->save if $opt->{'s'};

  # Indicate the successful completion
  return 0;
}

1;

__END__

=head1 SEE ALSO

L<IRDA::Prepare|IRDA::Prepare>,
L<RDA::Agent|RDA::Agent>,
L<RDA::Object::Collect|RDA::Object::Collect>,
L<RDA::Object::Content|RDA::Object::Content>,
L<RDA::Object::Message|RDA::Object::Message>,
L<RDA::Object::Rda|RDA::Object::Rda>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
