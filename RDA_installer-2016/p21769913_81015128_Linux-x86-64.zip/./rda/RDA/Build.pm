# Build.pm: Class for Detecting Obsolete Versions (generated file)
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/bin/mk_rda_adm,v 1.25 2015/10/28 18:20:18 RDA Exp $
package RDA::Build;
use strict;
use vars qw($BUILD $VERSION);
$BUILD   = '20151208';
$VERSION = '8.10';
1;
