# 7Zip.pm: Class Used to Manage Archives using 7-Zip

package RDA::Driver::7Zip;

# $Id: 7Zip.pm,v 1.10 2015/10/19 04:40:13 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Driver/7Zip.pm,v 1.10 2015/10/19 04:40:13 RDA Exp $
#
# Change History
# 20151019  MSC  Support Windows disks where short names are not available.

=head1 NAME

RDA::Driver::7Zip - Class Used to Manage Archives using 7-Zip

=head1 SYNOPSIS

 require RDA::Driver::7Zip;

=head1 DESCRIPTION

The objects of the C<RDA::Driver::7Zip> class are used to manage archives using
F<7z>. It is a subclass of L<RDA::Object::Archive|RDA::Object::Archive>.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use IO::File;
  use RDA::Text qw(get_string);
  use RDA::Object::Archive;
  use RDA::Object::Rda qw($DIR_PERMS);
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.10 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(RDA::Object::Archive RDA::Object Exporter);

# Define the global private constants

# Define the global private variables

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<$h-E<gt>create($opt[,$dir[,$fil,...]])>

This method creates the archive file. Unless files are specified as arguments,
it includes recursively the whole directory in the archive. By default, it
compresses the files but does not create a manifest file.

It supports the following request options:

=over 9

=item B<    'm' > Creates a manifest file.

=item B<    's' > Stores only.

=back

It returns the exit code.

=cut

sub create
{ my ($slf, $req, $dir, @fil) = @_;
  my ($cmd, $cwd, $lvl, $man, $msk, $pth, $sta);

  # Determine the archive path
  $cwd = $slf->{'cwd'};
  $dir = RDA::Object::Rda->current_dir unless defined($dir);
  $pth = RDA::Object::Rda->cat_file($cwd, $pth)
    unless RDA::Object::Rda->is_absolute($pth = $slf->{'pth'});

  # Prepare the command
  $lvl = $slf->get_info('lvl', 9);
  $cmd = RDA::Object::Rda->quote(RDA::Object::Rda->is_windows
    ? RDA::Object::Rda->short($slf->get_info('arc'))
    : $slf->get_info('arc'));
  $cmd .= ' a -tzip '.RDA::Object::Rda->quote($pth);
  $cmd .= (index($req, 's') < 0) ? ' -mx='.$lvl : ' -mx=0';
  $cmd .= ' -y >'.RDA::Object::Rda->dev_null;

  # Treat manifest file
  unless (index($req, 'm') < 0)  ## no critic (Unless)
  { $man = RDA::Object::Rda->create_dir(
      RDA::Object::Rda->cat_dir($dir, 'META-INF'), $DIR_PERMS);
    $slf->get_info('man')->save(RDA::Object::Rda->cat_file($man,
      'MANIFEST.MF'));
  }

  # Execute the command
  chdir($dir) or die get_string('CD_PKG', $dir);
  $msk = umask(027);  ## no critic (Number)
  $sta = system($cmd);
  umask($msk);
  chdir($cwd) or get_string('CD_WRK', $cwd);

  # Return the exit code
  return $sta;
}

=head2 S<$h-E<gt>extract($arc,$flg,$fil...)>

This method extracts files from the specified archive file. It stores the files
in the directory associated to the current archive.

=cut

sub extract
{ my ($slf, $arc, $flg, @fil) = @_;
  my ($cmd, $cwd, $dir, $msk, $pth, $sta);

  # Determine the archive path
  $cwd = $slf->{'cwd'};
  $pth = RDA::Object::Rda->is_absolute($arc)
    ? $arc
    : RDA::Object::Rda->cat_file($cwd, $arc);

  # Prepare the command
  $cmd = join(q{ }, RDA::Object::Rda->quote(RDA::Object::Rda->is_windows
    ? RDA::Object::Rda->short($slf->get_info('ext'))
    : $slf->get_info('ext')),
    'e', RDA::Object::Rda->quote($pth), @fil, '>'.RDA::Object::Rda->dev_null);

  # Execute the command
  chdir($dir = $slf->{'dir'}) or die get_string('CD_PKG', $dir);
  $msk = umask(027);
  $sta = system($cmd);
  umask($msk);
  chdir($cwd) or get_string('CD_WRK', $cwd);

  # Return the exit code
  return $sta;
}

=head2 S<$h-E<gt>get_extension>

This method returns the usual archive extension.

=cut

sub get_extension
{ return '.zip';
}

1;

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Object::Archive|RDA::Object::Archive>,
L<RDA::Object::Rda|RDA::Object::Rda>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
