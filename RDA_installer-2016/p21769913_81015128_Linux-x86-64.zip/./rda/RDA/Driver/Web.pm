# Web.pm: Class Used for Managing Web Pages

package RDA::Driver::Web;

# $Id: Web.pm,v 1.24 2015/07/03 11:27:26 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Driver/Web.pm,v 1.24 2015/07/03 11:27:26 RDA Exp $
#
# Change History
# 20150703  MSC  Improve abbreviation handlink in links.

=head1 NAME

RDA::Driver::Web - Class Used for Managing Web Pages

=head1 SYNOPSIS

 require RDA::Driver::Web;

=head1 DESCRIPTION

The objects of the C<RDA::Driver::Web> class are used to manage web pages. It
is a subclass of L<RDA::Object|RDA::Object>.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::Text qw(get_string);
  use RDA::Object;
  use IO::File;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @EXPORT_OK @ISA %MIMES);
$VERSION   = sprintf('%d.%02d', q$Revision: 1.24 $ =~ /(\d+)\.(\d+)/);
@EXPORT_OK = qw(decode_uri encode_uri fmt_date fmt_mode %MIMES);
@ISA       = qw(RDA::Object Exporter);
%MIMES     = (
  bz2  => 'application/x-bzip2',
  css  => 'text/css',
  gz   => 'application/x-gzip',
  htm  => 'text/html',
  html => 'text/html',
  tar  => 'application/x-tar',
  tgz  => 'application/x-gzip',
  txt  => 'text/plain',
  xml  => 'application/xml',
  xz   => 'application/x-xz',
  z    => 'application/x-compress',
  zip  => 'application/zip',
  );

# Define the global private constants
## no critic (Long,Newline)
my $BEG = q{<!DOCTYPE html PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN'>
<html lang='}.get_string('Lang').qq{'><head>
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/>\n};

my $CSS = qq{<style type='text/css'>
<!--
.rda { font-size:9pt;
       font-family:sans-serif;
     }
.rda h1 { border-bottom-width:1px;
          border-bottom-style:solid;
          border-bottom-color:#CBD8E7;
          color:#333333;
          font-family:sans-serif;
          font-size:12pt;
          padding-top:4px;
        }
.rda h2 { color:#333333;
          font-family:sans-serif;
          font-size:11pt;
          padding-top:4px;
        }
.rda h3 { color:#666666;
          font-family:sans-serif;
          font-size:10pt;
        }
.rda h4 { color:#666666;
          font-family:sans-serif;
          font-size:9pt
        }
.rda input { font-size:9pt;
             font-family:sans-serif;
           }
.rda p { font-size:9pt;
         font-family:sans-serif;
       }
.rda table { border-style:none;
           }
.rda tr { padding-top:1px;
          padding-bottom:1px;
        }
.rda td { border-style:none;
          font-size:9pt;
          font-family:sans-serif;
          padding:2px;
          padding-top:1px;
          padding-bottom:1px;
          vertical-align:top;
        }
.rda th { border-style:none;
          font-size:9pt;
          font-family:sans-serif;
          font-weight:bold;
          padding:2px;
          color:#336699
          vertical-align:top;
        }
.rda a:hover { color:#0033CC;
             }
.rda_footer { color:#454545;
              font-size:8pt;
              font-family:sans-serif;
            }
.rda_footer h1 { color:#454545;
                 font-family:sans-serif;
                 font-size:10pt;
                 padding-top:2px;
               }
.rda_footer h2 { color:#454545;
                 font-family:sans-serif;
                 font-size:9pt;
                 padding-top:2px;
               }
.rda_footer h3 { color:#666666;
                 font-family:sans-serif;
                 font-size:9pt;
               }
.rda_footer h4 { color:#666666;
                 font-family:sans-serif;
                 font-size:8pt
               }
.rda_links table { border-top-width:1px;
                   border-top-style:solid;
                   border-top-color:#CBD8E7;
                   border-left-width:1px;
                   border-left-style:solid;
                   border-left-color:#CBD8E7;
                 }
.rda_links td { background:#FBFCFD;
                border-right-width:1px;
                border-right-style:solid;
                border-right-color:#CBD8E7;
                border-bottom-width:1px;
                border-bottom-style:solid;
                border-bottom-color:#CBD8E7;
                font-size:9pt;
                padding:4px;
                vertical-align:top;
              }
.rda_links th { background-color:#ECF3F9;
                border-right-width:1px;
                border-right-style:solid;
                border-right-color:#CBD8E7;
                border-bottom-width:1px;
                border-bottom-style:solid;
                border-bottom-color:#CBD8E7;
                font-size:9pt;
                font-weight:bold;
                padding:4px;
                text-align:left;
                vertical-align:top
              }
.rda_report table { border-style:solid;
                    border-width:1px;
                    border-color:#CBD8E7;
                    border-collapse:collapse;
                    border-spacing:0px;
                    empty-cells: show;
                  }
.rda_report td { background:#FBFCFD;
                 border-style:solid;
                 border-width:1px;
                 border-color:#CBD8E7;
                 font-size:9pt;
                 font-family:sans-serif;
                 padding:2px;
               }
.rda_report th { background:#ECF3F9;
                 border-style:solid;
                 border-width:1px;
                 border-color:#CBD8E7;
                 color:#336699;
                 font-size:9pt;
                 font-family:sans-serif;
                 font-weight:bold;
                 padding:2px;
               }
.rda_report tr { vertical-align:top;
               }
.rda_value table { border-style:none;
                   padding:0px;
                 }
.rda_value td { border-style:none;
                font-size:9pt;
                padding:0px;
                vertical-align:top;
              }

\# -->
</style>\n};

my $END = qq{</div></body></html>\n};

my $LNK = q{L<[^<>]+>|[^<>]*?>};

my $NOT = q{<hr/></div><div class='rda_footer'>}
  .q{<h1><a name='copyright_notice'>}.get_string('TtlCN')
  .qq{</a></h1>\n<p>}.get_string('CN')
  .qq{</p>\n<h1><a name='trademark_notice'>}.get_string('TtlTN')
  .qq{</a></h1>\n<p>}.get_string('TN')
  .qq{</p>\n<h1><a name='legal_notice'>}.get_string('TtlLN')
  .qq{</a></h1>\n<p>}.get_string('LN')
  .qq{</p>\n<h1><a name='accessibility_notice'>}.get_string('TtlAN')
  .qq{</a></h1>\n<p>}.get_string('AN1')
  .qq{</p>\n<p><strong>}.get_string('AN2')
  .q{</strong> }.get_string('AN3')
  .qq{</p>\n<p><strong>}.get_string('AN4')
  .q{</strong> }.get_string('AN5')
  .q{</p>};

my $TOP = qq{<body><div class='rda'><p><a name='top'></a>
<!-- Oracle Remote Diagnostic Agent / Documentation 5.0 -->\n};
## use critic

# Define acronyms
my $RDA = q{<acronym title='}.get_string('RDA').q{'>RDA</acronym>};
my %ABR = (
  CFM  => q{<acronym title='}.get_string('CFM').q{'>CFM</acronym>},
  HCVE => q{<acronym title='}.get_string('HCVE').q{'>HCVE</acronym>},
  IRDA => q{<acronym title='}.get_string('IRDA').q{'>IRDA</acronym>},
  OCM  => q{<acronym title='}.get_string('OCM').q{'>OCM</acronym>},
  RDA  => $RDA,
  SDCI => q{<acronym title='}.get_string('SDCI').q{'>SDCI</acronym>},
  SDCL => q{<acronym title='}.get_string('SDCL').q{'>SDCL</acronym>},
  SDSL => q{<acronym title='}.get_string('SDSL').q{'>SDSL</acronym>},
  );
my $ABR = join(q{|}, keys(%ABR));

# Define the global private variables
my @tb_bit = qw(
  --- --x -w- -wx r-- r-x rw- rwx
  --S --s -wS -ws r-S r-s rwS rws);

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<$h = RDA::Driver::Web-E<gt>new($cfg)>

The object constructor. It takes a reference to RDA software configuration as
an argument.

C<RDA::Driver::Web> is represented by a blessed hash reference. The following
special keys are used:

=over 12

=item S<    B<'oid' > > Object identifier

=item S<    B<'_reg'> > Applicable regions

=item S<    B<'_ver'> > RDA software version

=item S<    B<'_wdt'> > Page width parameter

=back

Internal keys are prefixed by an underscore.

=cut

sub new
{ my ($cls, $cfg) = @_;
  my ($slf, $val);

  # Create the render object
  $slf = bless {
    oid  => 'WEB',
    _reg => {text => 1},
    _ver => $cfg->get_version,
    _wdt => $cfg->get_columns,
    }, ref($cls) || $cls;

  # Identify applicable regions
  if (defined($val = $cfg->get_env('RDA_MAN')))
  { foreach my $key (split(/,/, $val))
    { $slf->{'_reg'}->{$key} = 1 if $key;
    }
  }

  # Return the object reference
  return $slf;
}

=head2 S<$h-E<gt>pod($ofh,$name,$file[,$fct[,$pre]])>

This method extracts the Plain Old Documentation (POD) from the specified file
and converts it into HTML. You can specify a function to convert the links as
an extra argument.

=cut

sub pod  ## no critic (Complex)
{ my ($slf, $ofh, $nam, $fil, $fct, $pre) = @_;
  my ($cut, $flg, $ifh, $max, $nwl, $off, $reg, $str, $tag, @tbl);
  local $/   = q{};    # Treat multiple empty lines as a single empty line

  $cut = $off = 2;
  $fct = \&_fmt_link unless defined($fct);
  $flg = 0;
  $nwl = q{};
  $tag = [0, q{<p>}, qq{</p>\n}, q{<p>}, qq{</p>\n}];

  # Extract the documentation and format it
  if (ref($fil))
  { $ifh = $fil;
  }
  else
  { $ifh = IO::File->new;
    $ifh->open("<$fil") or die get_string('ERR_OPEN', $fil, $!);
  }
  while (<$ifh>)
  { # Extract the documentation
    if ($cut)
    { next unless m/^=/;
      $cut = 0;
    }
    if ($reg)
    { next unless m/^=end\s+$reg[\n\r\s]*$/;
      $reg = undef;
    }

    # Resolve attributes
    $max = 10;
    s{\&}{\&amp;}g;
    s{E<(\d+)>}{\&\#$1;}g;
    s{E<(\w+)>}{\&$1;}g;
    s{^(\s*)((?:<|require |use |(?:rda|sdci|sdp)\.\w+ ).*)$}
     {qq{$1\001code\002}._fmt_preformed($2).qq{\001/code\002}}sge;
    s{B<(\s*)>}{$1}sg;
    s{^(=item(?:\s+o)?\s+S<\s*B<\s*)($LNK|[^<>]*?)\s*>\s*>\s*(\S.*)}
     {$1$2>>\003$3}s ||
    s{^(=item(?:\s+o)?\s+B<\s*)($LNK|[^<>]*?)\s*>\s*(\S.*)}
     {$1$2>\003$3}s;
    while ($max-- && /[A-Z]</)
    { s{L<([^|>]+)\|([^>]+)>}{&{$fct}(_fmt_lnk($1), $2, $pre)}sge;
      s{B<(.*?)>}{qq{\001strong\002\001tt\002}._fmt_space($1, 1).
        qq{\001/tt\002\001/strong\002}}sge;
      s{[CF]<(.*?)>}{qq{\001code\002}._fmt_space($1).qq{\001/code\002}}sge;
      s{I<(.*?)>}{\001em\002$1\001/em\002}sg;
      s{S<(.*?)>}{_fmt_space($1)}sge;
      s{X<.*?>}{}sg;
      s{[A-Z]<(.*?)>}{$1}sg;
    }
    s{<}{&lt;}g;
    s{>}{&gt;}g;
    s{\001}{<}g;
    s{\002}{>}g;
    s{[\s\r\n]+$}{};

    # Treat the pod directives
    if (s/^=(\S*)\s?//)
    { my $cmd = $1;

      $nwl = q{};
      if ($cmd eq 'cut')
      { $cut = 1;
      }
      elsif ($cmd eq 'pod')
      { $cut = 0;
      }
      elsif ($cmd eq 'head1')
      { if (m/(?:COPYRIGHT|TRADEMARK) NOTICE/)
        { $cut = 1;
        }
        elsif ($_ eq 'NAME')
        { $str = _fmt_name($nam);
          _prt_str($ofh,
            qq{<h1><a id='$str' name='$str'>}._fmt_abbr($nam).qq{</a></h1>\n});
        }
        else
        { _prt_str($ofh, qq{<h2>$_</h2>\n});
        }
      }
      elsif ($cmd eq 'head2')
      { _prt_str($ofh, qq{<h3>$_</h3>\n});
      }
      elsif ($cmd eq 'head3')
      { _prt_str($ofh, qq{<h4>$_</h4>\n});
      }
      elsif ($cmd eq 'over')
      { unshift(@tbl, $tag);
        _prt_str($ofh,
          qq{<table summary=''><tr><td style='white-space:nowrap'>\n});
        $tag = [1,
                qq{<br/>\n},
                q{},
                qq{</td></tr>\n<tr><td style='white-space:nowrap'>},
                qq{</td>\n<td>},
                q{}];
        $flg = 1;
        $off = 5;
      }
      elsif ($cmd eq 'back')
      { if ($tag = shift(@tbl))
        { _prt_str($ofh, qq{</td></tr></table>\n});
        }
        else
        { $tag = [0, q{<p>}, qq{</p>\n}, q{<p>}, qq{</p>\n}];
        }
        $flg = $tag->[0];
        $off = 3;
      }
      elsif ($cmd eq 'item')
      { s/^(\s*)[o\*](?:\s|\z)/$1&middot;\003/;
        s/\003/$tag->[4]/g;
        _prt_str($ofh, $tag->[$off].$_.$tag->[4]);
        $off = 3;
        $flg = 1;
      }
      elsif ($cmd eq 'begin')
      { if (!exists($slf->{'_reg'}->{$_}))
        { $reg = $_;
        }
        elsif ($_ eq 'credits')
        { _prt_str($ofh, qq{<h1>CREDITS</h1>\n});
        }
      }
    }
    elsif (m/^\s+/)
    { ($flg, $str) = ($flg < 0) ? ($flg, $tag->[1]) : (-$flg, q{});
      s{\n}{<br/>}g;
      _prt_str($ofh, $nwl.$str.q{<tt>}._fmt_space($_).qq{</tt><br/>\n});
      $nwl = q{<br/>};
    }
    else
    { ($flg, $str) = ($flg > 0) ? (-$flg, q{}) : ($flg, $tag->[1]);
      _prt_str($ofh, $str.$_.$tag->[2]);
      $nwl = q{};
    }
  }
  while ($tag = shift(@tbl))
  { _prt_str($ofh, qq{</td></tr></table>\n});
  }
  $ifh->close;
  return;
}

sub _fmt_lnk
{ my ($str) = @_;

  $str =~ s/:/./g if $str =~ s/^abr://;
  return $str;
}

sub _prt_str
{ my ($ofh, $str) = @_;

  syswrite($ofh, $str, length($str));
  return;
}

=head2 S<$h-E<gt>render($ofh,$def)>

This method converts the specified documentation in the POD format into
HTML. The definition hash can contain the following keys:

=over 11

=item B<    'css' > Style definition

=item B<    'det' > List of files to render

=item B<    'dsp' > Display format indicator

=item B<    'fct' > Function to format links

=item B<    'nam' > Page name

=item B<    'not' > Specific page notice

=item B<    'pre' > URL prefix

=item B<    'rel' > List of related links

=item B<    'tab' > List of main links

=item B<    'ttl' > Page title

=back

A link item is represented by a scalar, used as text, or by an array reference
containing the text and URL.

=cut

sub render
{ my ($slf, $ofh, $def) = @_;
  my ($buf, $col, $fct, $nam, $pre, $tbl, $ttl, $val, @arg);

  # Initialization
  $fct = $def->{'fct'} || \&_fmt_link;
  $pre = $def->{'pre'} || q{};
  $nam = _fmt_name($def->{'nam'} || q{});
  $ttl = $def->{'ttl'} || get_string('Title');

  # Start the page
  unless ($def->{'dsp'})
  { $buf = $BEG
      .(defined($def->{'css'}) ? $def->{'css'} : $CSS)
      .qq{<title>$ttl</title></head>\n}.$TOP
      .qq{<h1>$RDA }.$slf->{'_ver'}.qq{ - $ttl</h1>\n};
    syswrite($ofh, $buf, length($buf));
  }

  # Add the tab section
  if (ref($tbl = $def->{'tab'}) eq 'ARRAY' && ($col = scalar @{$tbl}))
  { $buf = q{<div class='rda_links'><table border='0' cellspacing='0'}
      .qq{ cellpadding='0' summary='Main Links' width='100%'>\n}
      .qq{<tr><th colspan='$col'>}.get_string('Main', $RDA)
      .qq{</th></tr><tr>\n};
    $val = int(100 / $col);
    foreach my $det (@{$tbl})
    { if (!ref($det))
      { $buf .= qq{<td align='center' width='$val%'><strong>}
          ._fmt_abbr($det).qq{</strong></td>\n};
      }
      elsif ($det->[2] eq $nam)
      { $buf .= qq{<td align='center' width='$val%'><strong>}
          ._fmt_abbr($det->[0]).qq{</strong></td>\n};
      }
      else
      { $buf .= qq{<td align='center' width='$val%'><a href='}
          .encode_uri($pre.$det->[1]).q{'>}
          ._fmt_abbr($det->[0]).qq{</a></td>\n};
      }
    }
    $buf .= qq{</tr></table></div>\n};
    syswrite($ofh, $buf, length($buf));
  }

  # Add the related link section
  if (ref($tbl = $def->{'rel'}) eq 'ARRAY')
  { $buf = q{<h1>}.get_string('Related').qq{</h1>\n}
      ._rel2html($tbl, $nam, $pre);
    syswrite($ofh, $buf, length($buf));
  }

  # Add the page content
  foreach my $det (@{$def->{'det'}})
  { if (ref($nam = $det->[0]) eq 'CODE')
    { (undef, @arg) = @{$det};
      &$nam($ofh, @arg);
    }
    else
    { pod($slf, $ofh, $nam, $det->[1], $fct, $pre);
    }
  }

  # Terminate the page with all notices
  unless ($def->{'dsp'})
  { $buf = (defined($def->{'not'}) ? $def->{'not'} : $NOT).$END;
    syswrite($ofh, $buf, length($buf));
  }
  return;
}

sub _rel2html
{ my ($tbl, $nam, $pre) = @_;
  my ($buf);

  $buf = qq{<table summary='Related Links'><tr>\n};
  foreach my $det (@{$tbl})
  { if (ref($det))
    { $buf .= q{<td>}._idx2html($det, $nam, $pre).qq{</td>\n};
    }
    else
    { $buf .= q{<td>}._fmt_abbr($det).qq{</td>\n};
    }
  }
  $buf .= qq{</tr></table>\n};
  return $buf;
}

sub _idx2html
{ my ($tbl, $nam, $pre) = @_;
  my ($buf);

  $buf = qq{<ul>\n};
  foreach my $det (@{$tbl})
  { if (!ref($det))
    { $buf .= q{<li>}._fmt_abbr($det).qq{</li>\n};
    }
    elsif (defined($det->[2]) && $det->[2] eq $nam)
    { next;
    }
    elsif (ref($det->[1]))
    { $buf .= q{<li>}._fmt_abbr($det->[0])._idx2html($det->[1], $nam, $pre)
        .qq{</li>\n};
    }
    else
    { $buf .= q{<li><a href='}.encode_uri($pre.$det->[1]).q{'>}
        ._fmt_abbr($det->[0]).qq{</a></li>\n};
    }
  }
  $buf .= qq{</ul>\n};
  return $buf;
}

# Document abbreviations and acronyms
sub _fmt_abbr
{ my ($txt) = @_;

  $txt =~ s{\b($ABR)\b}{$ABR{$1}}egs;
  return $txt;
}

# Generate a link
sub _fmt_link
{ return shift;
}

# Generate an anchor
sub _fmt_name
{ my ($str) = @_;
  $str =~ s{^.*\s-\s+}{};
  $str =~ s{\.\w+$}{};
  $str =~ s{\.[\/\\]}{};
  $str =~ s{[\/\\]}{::}g;
  $str =~ s{[_\s]+}{_}g;
  return $str;
}

# Replace the spaces by non blanking spaces in preformed strings
sub _fmt_preformed
{ my ($str, $flg) = @_;
  $str =~ s{'}{}g if $flg;
  $str =~ s{^(\s+)}{"&nbsp;" x length($1)}e;
  $str =~ s{\\\n\040+}{}gm;
  $str =~ s{\n\040+}{ }gm;
  $str =~ s{\s+}{&nbsp;}g;
  $str =~ s{a&nbsp;href=}{a href=}g;
  return $str;
}

# Replace the spaces by non blanking spaces
sub _fmt_space
{ my ($str, $flg) = @_;
  $str =~ s{'}{}g if $flg;
  $str =~ s{\s}{&nbsp;}g;
  $str =~ s{a&nbsp;href=}{a href=}g;
  return $str;
}

# --- Formatting routines -----------------------------------------------------

# Decode an URI
sub decode_uri
{ my ($str) = @_;

  if (defined($str))
  { $str =~ s/\+/ /g;
    $str =~ s/%([\dA-Fa-f]{2})/chr(hex($1))/eg;
  }
  return $str;
}

# Encode an URI
sub encode_uri
{ my ($str);

  $str = join (q{/}, @_);
  $str =~ s/([^\w\-\.\!\~\*\:\/])/sprintf('%%%02x', ord($1))/ge;
  return $str;
}

# Format permissions
sub fmt_bits
{ my ($val, $flg) = @_;

  $val += 8 if $flg;
  return $tb_bit[$val];
}

# Format a date
sub fmt_date
{ my ($str) = @_;

  return q{} unless $str;
  $str = gmtime($str);
  return q{ }.substr($str, 4, 12).q{ }.substr($str, 20, 4);
}

# Format the file mode
sub fmt_mode
{ my ($mod) = @_;

  ## no critic (Bit,Number,Zero)
  return substr("Lpc?d?b?-?l?s?w?", ($mod >> 12) & 017, 1)
    .fmt_bits(($mod >> 6) & 07, $mod & 04000)
    .fmt_bits(($mod >> 3) & 07, $mod & 02000)
    .fmt_bits($mod & 07,        $mod & 01000);
  ## use critic
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Object|RDA::Object>,
L<RDA::Object::Rda|RDA::Object::Rda>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
