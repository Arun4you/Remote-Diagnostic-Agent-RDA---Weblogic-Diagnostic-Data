# Proto.pm: Class Used as External Perl Macro Prototype

package RDA::Extern::Proto;

# $Id: Proto.pm,v 1.6 2015/05/08 18:31:05 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Extern/Proto.pm,v 1.6 2015/05/08 18:31:05 RDA Exp $
#
# Change History
# 20150508  MSC  Improve the documentation.

=head1 NAME

RDA::Extern::Proto - Class Used as External Perl Macro Prototype

=head1 SYNOPSIS

 require RDA::Proto;

=head1 DESCRIPTION

Objects of the C<RDA::Extern::Proto> class can be used as example of external
Perl macros.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::SDCL::Value qw(convert_value);
}

# Define the global public variables
use vars qw($VERSION);
$VERSION = sprintf('%d.%02d', q$Revision: 1.6 $ =~ /(\d+)\.(\d+)/);

# Define the global private constants

# Define the global private variables

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<RDA::Extern::Proto::dump($ctx[,$arg,...])>

The routine dumps the argument list.

=cut

sub dump  ## no critic (Builtin)
{ my $ctx = shift;

  return convert_value({q{@_} => [@_]})->dump;  ## no critic (Interpolation)
}

=head2 S<RDA::Extern::Proto::version($typ)>

The routine reports the module version.

=cut

sub version
{ my ($ctx, $typ) = @_;
  my ($maj, $min) = split(/\./, $VERSION);

  if ($typ)
  { return [$VERSION, undef, $maj, $min] if $typ eq 'A';
    return [{Version => [$maj, $min]}]   if $typ eq 'C';
    return {Version => [$maj, $min]}     if $typ eq 'H';
    return                               if $typ eq 'U';
  }
  return $VERSION;
}

=head2 S<RDA::Extern::Proto::write($ctx[,$arg,...])>

The routine writes the arguments in the current report. Arguments other than
numbers and strings are simply ignored. An end-of-line is added at the end of
the resulting string.

=cut

sub write  ## no critic (Builtin)
{ my $ctx = shift;
  my $rpt;

  return ($rpt = $ctx->get_report)
    ? $rpt->write(join(q{}, grep {$_ && !ref($_)} @_).qq{\n})
    : undef;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::SDCL::Block|RDA::SDCL::Block>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
