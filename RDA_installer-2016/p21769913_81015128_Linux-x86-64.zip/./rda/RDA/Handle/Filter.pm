# Filter.pm: Class Used to Filter RDA Output

package RDA::Handle::Filter;

# $Id: Filter.pm,v 1.13 2014/05/15 10:17:28 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Handle/Filter.pm,v 1.13 2014/05/15 10:17:28 RDA Exp $
#
# Change History
# 20140515  MSC  Decrease the regroup factor.

=head1 NAME

RDA::Handle::Filter - Class Used to Filter RDA Output

=head1 SYNOPSIS

 require RDA::Handle::Filter;

=head1 DESCRIPTION

The objects of the C<RDA::Handle::Filter> class are used to filter sensitive
information out the generated reports.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use IO::File;
  use RDA::Text qw(get_string);
  use RDA::Object::View;
  use Symbol;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @EXPORT_OK @ISA %FLT_FORMATS);
@EXPORT_OK = qw(%FLT_FORMATS);
@ISA       = qw(Exporter);
$VERSION   = sprintf('%d.%02d', q$Revision: 1.13 $ =~ /(\d+)\.(\d+)/);

# Define the global private constants
%FLT_FORMATS = (
  ## no critic (Interpolation)
  DFT     => '$str =~ s/\b%s\b/%s%s%s/go%s;',
  DFT_ATT => '<<$1:$4>>$str =~ s/(\b%s\s*=\s*([\'"]))(.*?)(\2)/%s%s%s/go%s;',
  DFT_HST => '<<$1:$2>>$str =~ s/(\b|\bnode|_)%s(\b|_)/%s%s%s/go%s;',
  DFT_IP4 => '<<$1:$2>>1 '.
             'while $str =~ s/(^|[^\.])\b%s\b($|[^\.])/%s%s%s/o%s;',
  DFT_IP6 => '<<$1:$2>>1 '.
             'while $str =~ s/(^|[^\:\dA-F])%s($|[^\:\dA-Z])/%s%s%s/io%s;',
  DFT_SYS => '<<:$1>>$str =~ s/\b%s(\b|_)/%s%s%s/go%s;',
  );

# Define the global private variables
my $EMPTY = q{};

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<$h = RDA::Handle::Filter-E<gt>new($def)>

The control object constructor. This method takes the filter definition
reference as an argument.

It is represented by a blessed hash reference. The following special keys are
used:

=over 12

=item S<    B<'def' > > Reference to the filter definition

=item S<    B<'rul' > > Filter rules

=item S<    B<'sub' > > Filter function reference

=back

=head2 S<$h-E<gt>new>

The output object constructor. It derives its attributes from the control
object and it returns the output file handle.

=cut

sub new
{ my $cls = shift;
  my $slf;

  if (ref($cls))
  { # Create the filter output object
    $slf = bless Symbol::gensym(), ref($cls);
    tie *$slf, $slf;  ##  no critic (Tie)
    *$slf->{'sub'} = $cls->{'sub'};
  }
  else
  { my $def = shift;

    # Create the filter control object
    $slf = bless {def => $def}, $cls;

    # Define the filter
    _def_filter($slf, $def);
  }

  # Return the object reference
  return $slf;
}

sub _def_filter  ## no critic (Complex)
{ my ($slf, $def) = @_;
  my ($fmt, $min, $max, $num, $set, @rul, %fmt);

  # Define the substitution formats
  foreach my $nam (keys(%FLT_FORMATS))
  { $fmt = $FLT_FORMATS{$nam};
    ($min, $max) = ($fmt =~ s/^<<(\$\d+)?:(\$\d+)?>>//)
      ? ($1, $2) : ($EMPTY, $EMPTY);
    $fmt{$nam} = [$min, $max, $fmt];
  }
  if (ref($set = $def->get_value('T_FORMATS')) eq 'HASH')
  { foreach my $nam (keys(%{$set}))
    { next unless ($fmt = $set->{$nam});
      ($min, $max) = ($fmt =~ s/^<<(\$\d+)?:(\$\d+)?>>//)
        ? ($1, $2) : ($EMPTY, $EMPTY);
      $fmt{$nam} = [$min, $max, $fmt];
    }
  }

  # Get the filter rules
  $num = $def->get_first('N_REGROUP', 1);
  foreach my $nam ($def->get_value('W_SETS'))
  { my ($grp, $opt, $str, @pat);

    next unless ($set = $def->find($nam))
      && exists($fmt{$fmt = $set->get_first('W_FORMAT', 'DFT')});
    $opt = $set->get_first('W_OPTIONS', $EMPTY);
    $str = $set->get_first('T_STRING', $EMPTY);
    $fmt = $fmt{$fmt};
    foreach my $pat ($set->get_value('T_PATTERNS'))
    { next unless $pat;
      if ($pat =~ s/^<<(\$\d+)?:(\$\d+)?>>//)
      { ($min, $max) = ($1, $2);
        push(@rul,
          sprintf($fmt->[2], $pat, $min || $EMPTY, $str, $max || $EMPTY, $opt))
          if defined($pat = RDA::Object::View->is_re($pat, 1));
      }
      else
      { push(@pat, $pat);
      }
    }
    while (@pat)
    { $grp = q{(?:}.join(q{|}, splice(@pat, 0, $num)).q{)};
      push(@rul, sprintf($fmt->[2], $grp, $fmt->[0] || $EMPTY, $str,
        $fmt->[1] || $EMPTY, $opt))
        if defined($grp = RDA::Object::View->is_re($grp, 1));
    }
  }
  die get_string('NO_RULES') unless @rul;
  $slf->{'rul'} = [@rul];

  # Generate the filter routine
  ## no critic (Eval,Interpolation)
  $slf->{'sub'} = eval join(qq{\n},
    'sub { my $str = shift;',
    'unless ($str =~ m#^<\/?(code|pre|verbatim(:\w+)?)>$#',
    '|| $str =~ m#^%(DATA|TOC[\d\-]*)%$#){',
    @rul,
    '}$str;}');
  die get_string('ERR_CODE', $@) if $@;
  return;
}

=head2 S<$h-E<gt>display>

This method returns the filter code.

=cut

sub display
{ return join(qq{\n}, 'Filter rules:', @{shift->{'rul'}}, $EMPTY);
}

=head2 S<$h-E<gt>filter($str)>

This method filters sensitive information out of the specified string.

=cut

sub filter
{ my ($slf, $str) = @_;

  return &{$slf->{'sub'}}($str);
}

# --- Functions to emulate a file handle --------------------------------------

sub _not_implemented
{ return;
}

*blocking = \&_not_implemented;
*clearerr = \&_not_implemented;
*eof = \&_not_implemented;
*error = \&_not_implemented;
*fileno = \&_not_implemented;
*getc = \&_not_implemented;
*getline = \&_not_implemented;
*getlines = \&_not_implemented;
*getpos = \&_not_implemented;
*input_line_number = \&_not_implemented;
*opened = \&_not_implemented;
*printflush = \&_not_implemented;
*read = \&_not_implemented;
*seek = \&_not_implemented;
*setpos = \&_not_implemented;
*stat = \&_not_implemented;
*sync = \&_not_implemented;
*sysread = \&_not_implemented;
*tell = \&_not_implemented;
*truncate = \&_not_implemented;
*ungetc = \&_not_implemented;
*untaint = \&_not_implemented;

sub autoflush
{ my $slf = shift;

  return *$slf->{'rpt'}->autoflush(@_) if *$slf->{'rpt'};
  return;
}

sub close  ## no critic (Ambiguous,Builtin)
{ my $slf = shift;

  return *$slf->{'rpt'} ? *$slf->{'rpt'}->close : 1;
}

sub flush
{ my $slf = shift;

  return unless *$slf->{'rpt'};
  return *$slf->{'rpt'}->flush;
}

sub open  ## no critic (Builtin)
{ my $slf = shift;

  return (*$slf->{'rpt'} = IO::File->new)->open(@_);
}

sub print  ## no critic (Builtin)
{ my $slf = shift;

  return unless *$slf->{'rpt'};
  return *$slf->{'rpt'}->print(map {&{*$slf->{'sub'}}($_)} @_);
}

sub printf  ## no critic (Builtin)
{ my $slf = shift;
  my $fmt = shift;

  return unless *$slf->{'rpt'};
  return *$slf->{'rpt'}->print(&{*$slf->{'sub'}}(sprintf($fmt, @_)));
}

sub sysseek  ## no critic (Builtin)
{ my $slf = shift;

  return unless *$slf->{'rpt'};
  return sysseek(*$slf->{'rpt'}, $_[0], $_[1]);
}

sub syswrite  ## no critic (Builtin)
{ my $slf = shift;
  my $str = shift;
  my $lgt = shift;

  $str = substr($str, 0, $lgt) if defined($lgt);
  $str = &{*$slf->{'sub'}}($str);
  return unless *$slf->{'rpt'};
  return *$slf->{'rpt'}->syswrite($str, length($str));
}

sub write  ## no critic (Builtin)
{ my $slf = shift;
  my $str = shift;
  my $lgt = shift;

  $str = substr($str, 0, $lgt) if defined($lgt);
  $str = &{*$slf->{'sub'}}($str);
  return unless *$slf->{'rpt'};
  return *$slf->{'rpt'}->write($str, length($str));
}

sub BINMODE
{ my $slf = shift;

  return unless *$slf->{'rpt'};
  return @_ ? binmode(*$slf->{'rpt'}, @_) : binmode(*$slf->{'rpt'});
}

*CLOSE = \&close;
*EOF = \&_not_implemented;
*FILENO = \&_not_implemented;
*GETC = \&_not_implemented;
*OPEN = \&open;
*PRINT = \&print;
*PRINTF = \&printf;
*READ = \&_not_implemented;
*READLINE = \&_not_implemented;
*SEEK = \&_not_implemented;
*TELL = \&_not_implemented;
*WRITE = \&write;

sub DESTROY
{
}

sub TIEHANDLE
{ return shift;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Object::Output|RDA::Object::Output>,
L<RDA::Object::View|RDA::Object::View>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
