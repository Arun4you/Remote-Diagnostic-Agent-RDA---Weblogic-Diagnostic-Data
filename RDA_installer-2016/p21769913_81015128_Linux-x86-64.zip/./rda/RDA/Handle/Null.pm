# Null.pm: Class Used to Discard any Output

package RDA::Handle::Null;

# $Id: Null.pm,v 1.2 2013/11/22 11:34:59 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Handle/Null.pm,v 1.2 2013/11/22 11:34:59 RDA Exp $
#
# Change History
# 20131107  MSC  Initial version.

=head1 NAME

RDA::Handle::Null - Class Used to Discard any Output

=head1 SYNOPSIS

 require RDA::Handle::Null;

=head1 DESCRIPTION

The objects of the C<RDA::Handle::Null> class are used to discard any output.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use IO::File;
  use RDA::Text qw(get_string);
  use RDA::Object::Rda qw($CREATE $FIL_PERMS);
  use Symbol;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.2 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(Exporter);

# Define the global private constants

# Define the global private variables

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<$h = Rda::Handle::Null-E<gt>new>

The object constructor.

C<Rda::Handle::Null> is represented by a blessed hash reference. The following
special keys are used:

=over 12

=item S<    B<'_ofh'> > Output file handle

=back

Internal keys are prefixed by an underscore.

=cut

sub new
{ my ($cls) = @_;
  my ($ofh, $slf);

  # Create the object
  $slf = bless {}, ref($cls) || $cls;

  # Create the null handle
  $slf->{'_ofh'} = $ofh = bless Symbol::gensym(), ref($slf);
  tie *$ofh, $ofh;  ## no critic (Tie)

  # Return the object reference
  return $slf;
}

# --- Functions to emulate a file handle --------------------------------------

sub _not_implemented
{ return;
}

sub _ret_one
{ return 1;
}

sub _ret_zero
{ return 0;
}

*autoflush = \&_not_implemented;
*blocking = \&_not_implemented;
*clearerr = \&_not_implemented;
*close = \&_ret_one;
*eof = \&_not_implemented;
*error = \&_not_implemented;
*fileno = \&_not_implemented;
*flush = \&_not_implemented;
*getc = \&_not_implemented;
*getline = \&_not_implemented;
*getlines = \&_not_implemented;
*getpos = \&_not_implemented;
*input_line_number = \&_not_implemented;
*open = \&_ret_one;
*opened = \&_not_implemented;
*print = \&_ret_zero;
*printf = \&_ret_zero;
*printflush = \&_not_implemented;
*read = \&_not_implemented;
*seek = \&_not_implemented;
*setpos = \&_not_implemented;
*stat = \&_not_implemented;
*sync = \&_not_implemented;
*sysread = \&_not_implemented;
*sysseek = \&_not_implemented;
*syswrite = \&_ret_zero;
*tell = \&_not_implemented;
*truncate = \&_not_implemented;
*ungetc = \&_not_implemented;
*untaint = \&_not_implemented;
*write = \&_ret_zero;

*BINMODE = \&_not_implemented;
*CLOSE = \&_ret_one;
*EOF = \&_not_implemented;
*FILENO = \&_not_implemented;
*GETC = \&_not_implemented;
*OPEN = \&_ret_one;
*PRINT = \&_ret_zero;
*PRINTF = \&_ret_zero;
*READ = \&_not_implemented;
*READLINE = \&_not_implemented;
*SEEK = \&_not_implemented;
*TELL = \&_not_implemented;
*WRITE = \&_ret_zero;

sub DESTROY
{
}

sub TIEHANDLE
{ return shift;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Object::Output|RDA::Object::Output>,
L<RDA::Object::Rda|RDA::Object::Rda>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
