# Event.pm: Class Regrouping Common Event-Based Collection Methods

package RDA::Limit::Event;

# $Id: Event.pm,v 1.5 2015/11/13 15:54:14 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Limit/Event.pm,v 1.5 2015/11/13 15:54:14 RDA Exp $
#
# Change History
# 20151113  MSC  Modify Timing handle creation.

=head1 NAME

RDA::Limit::Event - Class Regrouping Common Event-Based Collection Methods

=head1 SYNOPSIS

 require RDA::Limit::Event;

=head1 DESCRIPTION

The C<RDA::Limit::Event> class regroups common methods for collections based
on an event time.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::Text qw(get_string);
  use RDA::Handle::Timing;
  use RDA::Limit::Period;
  use RDA::Limit::Common;
  use RDA::Object::Buffer;
  use RDA::Object::Timing;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.5 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(RDA::Limit::Common Exporter);

# Define the global private constants
my $MON_11G = '[PS]MON started with pid';
my $MON_12C = 'Starting background process [PS]MON';

# Define the global private variables

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<$h-E<gt>open_alert_log($file[,$vms])>

This methods returns a buffer on the specified alert log file. It returns an
undefined value in case of errors.

=cut

sub open_alert_log
{ my ($slf, $fil, $flg) = @_;
  my ($hnd);

  return ($hnd = RDA::Handle::Timing->new($fil, $slf->{'_tim'},
    [ ($fil =~ m/\.xml$/) ? \&_compare_xml :
      $flg                ? \&_compare_vms :
                            \&_compare_db,
      sub { my ($slf, $buf, $chk) = @_;
            my ($off);

            return ($buf !~ m/\b[PS]MON\b/mo ||
                    $buf !~ m/^(?:$MON_11G|$MON_12C)/mo)    ?  0 :
                   ($buf =~ m/^Starting ORACLE instance/mo) ?  1 :
                                                              -1
              if $chk;

            return (($off = rindex($buf, 'Starting ORACLE instance')) < 0)
              ? 0
              : $off;
          },
      64]))
    ? RDA::Object::Buffer->new('B', $hnd, $fil)
    : undef;
}

# --- Compare routines --------------------------------------------------------

# Extract and compare DB time stamp
#  Wed Sep 26 11:34:02 2012
sub _compare_db
{ my ($slf, $buf, $dft) = @_;

  return
    ($buf =~ m/^((Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s.*?\d{4})/mo)
    ? *$slf->{'tim'}->compare_db($1)
    : $dft;
}

# Extract and compare VMS DB time stamp
#   16-FEB-2006 10:31:05.95:
sub _compare_vms
{ my ($slf, $buf, $dft) = @_;

  return
    ($buf =~ m/^\s?(\d{1,2}-[A-Za-z]{3}-\d{4}\s+\d{2}:\d{2}:\d{2})\.\d+:/mo)
    ? *$slf->{'tim'}->compare_db($1)
    : $dft;
}

# Extract and compare XML time stamp
#   <msg time='2012-09-26T11:34:02.534+05:30' ...
sub _compare_xml
{ my ($slf, $buf, $dft) = @_;

  return ($buf =~ m/^<msg time='(.*?)'/mo)
    ? *$slf->{'tim'}->compare_odl($1)
    : $dft;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Limit::Common|RDA::Limit::Common>,
L<RDA::Limit::Period|RDA::Limit::Period>,
L<RDA::Object::Buffer|RDA::Object::Buffer>,
L<RDA::Object::Limit|RDA::Object::Limit>,
L<RDA::Object::Timing|RDA::Object::Timing>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
