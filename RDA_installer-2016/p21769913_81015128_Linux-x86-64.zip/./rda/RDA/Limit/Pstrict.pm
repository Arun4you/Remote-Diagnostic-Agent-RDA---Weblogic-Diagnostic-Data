# Pstrict.pm: Class Used for Managing Limits for Period Strict Mode

package RDA::Limit::Pstrict;

# $Id: Pstrict.pm,v 1.3 2015/11/13 15:54:35 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Limit/Pstrict.pm,v 1.3 2015/11/13 15:54:35 RDA Exp $
#
# Change History
# 20151113  MSC  Access control object through the collector.

=head1 NAME

RDA::Limit::Pstrict - Class Used for Managing Limits for Period Strict Mode

=head1 SYNOPSIS

 require RDA::Limit::Pstrict;

=head1 DESCRIPTION

The objects of the C<RDA::Limit::Pstrict> class are used to manage limits for
collections based on time period and using a strict approach. It is a subclass
of L<RDA::Limit::Period|RDA::Limit::Period>.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::Text qw(get_string);
  use RDA::Limit::Common;
  use RDA::Limit::Period;
  use RDA::Object;
  use RDA::Object::Timing;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.3 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(RDA::Limit::Period RDA::Limit::Common RDA::Object Exporter);

# Define the global private constants

# Define the global private variables

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<$h = RDA::Limit::Pstrict-E<gt>new($collector)>

The limit control object constructor. This method enables you to specify the
collector object reference as an argument.

It is represented by a blessed hash reference. The following special keys are
used:

=over 12

=item S<    B<'oid' > > Object identifier

=item S<    B<'_col'> > Reference to the collector object

=item S<    B<'_def'> > Limit context definition hash

=item S<    B<'_key'> > Corresponding item key

=item S<    B<'_tim'> > Reference to the timing control object

=back

Internal keys are prefixed by an underscore.

=cut

sub new
{ my ($cls, $col) = @_;

  # Create the object and return its reference
  return bless {
    oid  => 'P',
    _col => $col,
    _def => {},
    _key => '.T_PS',
    _tim => $col->get_timing,
  }, ref($cls) || $cls;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Limit::Common|RDA::Limit::Common>,
L<RDA::Limit::Period|RDA::Limit::Period>,
L<RDA::Object|RDA::Object>,
L<RDA::Object::Limit|RDA::Object::Limit>,
L<RDA::Object::Timing|RDA::Object::Timing>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
