# Manifest.pm: Class Used to Manage Manifest Files

package RDA::Object::Manifest;

# $Id: Manifest.pm,v 1.7 2015/05/05 13:18:39 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Object/Manifest.pm,v 1.7 2015/05/05 13:18:39 RDA Exp $
#
# Change History
# 20150505  MSC  Improve the documentation.

=head1 NAME

RDA::Object::Manifest - Class Used to Manage Manifest Files

=head1 SYNOPSIS

 require RDA::Object::Manifest;

=head1 DESCRIPTION

The objects of the C<RDA::Object::Manisfest> class are used to manage manifest
files. It is a subclass of L<RDA::Object|RDA::Object>.

The following methods are available:

=cut

use strict;

BEGIN
{ use Cwd;
  use Exporter;
  use IO::File;
  use RDA::Text qw(get_string);
  use RDA::Object::Rda qw($CREATE $FIL_PERMS);
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA %SDCL);
$VERSION = sprintf('%d.%02d', q$Revision: 1.7 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(RDA::Object Exporter);
%SDCL    = (
  inc => [qw(RDA::Object)],
  met => {
    'clone'    => {ret => 0},
    'save'     => {ret => 0},
    'set_info' => {ret => 0},
    }
  );

# Define the global private constants
my $EOL = "\015\012";
my $VER = '12.1.0.0.0';

# Define the global private variables

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<$h = RDA::Object::Manifest-E<gt>new([$version[,key=>$val,...]])>

The object constructor. It takes the current version and initial attributes as
arguments.

C<RDA::Object::Manifest> is represented by a blessed hash reference.

=cut

sub new
{ my ($cls, $ver, @arg) = @_;
  my ($key, $slf, $val);

  # Create the object
  $slf = bless {
    'Created-By'       => defined($ver) ? "Oracle Remote Diagnostic Agent $ver"
                                        : 'Oracle Remote Diagnostic Agent',
    'Manifest-Version' => $VER,
    }, ref($cls) || $cls;

  # Define extra attributes
  while (($key, $val) = splice(@arg, 0, 2))
  { $slf->{$key} = $val if defined($val);
  }

  # Return the object reference
  return $slf;
}

=head2 S<$h-E<gt>clone>

This method clones the manifest object.

=cut

sub clone
{ my ($slf) = @_;

  return bless {%{$slf}}, ref($slf);
}

=head2 S<$h-E<gt>save($path)>

This method saves the manifest in the specified file. It returns the file path.

=cut

sub save
{ my ($slf, $pth) = @_;
  my ($buf, $ofh);

  # Write the manifest file
  $ofh = IO::File->new;
  $ofh->open($pth, $CREATE, $FIL_PERMS)
    or die get_string('ERR_CREATE', $pth, $!);
  binmode($ofh);
  foreach my $key (sort keys(%{$slf}))
  { next unless $key =~ m/^[A-Z][\w\-]*$/;
    $buf = $key.': '.$slf->{$key}.$EOL;
    $ofh->syswrite($buf, length($buf))
      or die get_string('ERR_WRITE', $pth, $!);
  }
  $ofh->syswrite($EOL, length($EOL))
    or die get_string('ERR_COMPLETE', $pth, $!);
  $ofh->close
    or die get_string('ERR_CLOSE', $pth, $!);

  # Return the object reference
  return $pth;
}

1;

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Object|RDA::Object>,
L<RDA::Object::Archive|RDA::Object::Archive>,
L<RDA::Object::Rda|RDA::Object::Rda>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
