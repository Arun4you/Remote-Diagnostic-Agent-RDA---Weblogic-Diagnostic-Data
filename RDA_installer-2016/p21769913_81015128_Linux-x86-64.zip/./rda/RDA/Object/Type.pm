# Type.pm: Class Used for Identifying File Types

package RDA::Object::Type;

# $Id: Type.pm,v 1.17 2015/08/14 19:40:11 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Object/Type.pm,v 1.17 2015/08/14 19:40:11 RDA Exp $
#
# Change History
# 20150814  MSC  Reduce the package list.

=head1 NAME

RDA::Object::Type - Class Used for Identifying File Types

=head1 SYNOPSIS

 require RDA::Object::Type;

=head1 DESCRIPTION

This package is designed to identify file and MIME types. It is a subclass of
L<RDA::Object|RDA::Object>.

It is a Perl implementation of the UNIX F<file> command. It supports a large
set of the features described in the C<magic(5)> man page.

=cut

use strict;

BEGIN {
  use IO::File;
  use RDA::Text qw(debug get_string);
  use RDA::Object;
  use RDA::Object::Buffer;
  use RDA::Object::Rda;
  use RDA::Object::View;
}

# Define the global public variables
use vars qw($DUMP $STRINGS $VERSION @ISA %SDCL);
$DUMP    = 0;
$VERSION = sprintf('%d.%02d', q$Revision: 1.17 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(RDA::Object Exporter);
%SDCL    = (
  als => {
    ## no critic (Interpolation)
    'file' => ['$[TYP]', 'get_type'],
    'mime' => ['$[TYP]', 'get_mime'],
    },
  beg => \&_begin_control,
  end => \&_end_control,
  inc => [qw(RDA::Object)],
  met => {
    'add_magic'   => {ret => 0},
    'check_magic' => {ret => 0},
    'get_info'    => {ret => 0},
    'get_mime'    => {ret => 0},
    'get_type'    => {ret => 0},
    'set_info'    => {ret => 0},
    },
  new => 1,
  top => 'TYP',
  );

# Define the global private constants
my $LGT = 0x8564;                 ## no critic (Number)
my $NUM = q{\d+|0x[\da-z]+};
my $OPR = q{[\+\-\*\/\%\&\^\|]};
my $SIZ = q{[blsBLS]};

# Define the global private variables
my @tb_rel = (q{}, q{&});
my %tb_dsc = (
  bin => [q{application/octet-stream}, q{binary}],
  sys => [q{x-system/x-unix; %s},      q{%s}],
  txt => [q{text/plain},               q{text}],
  );
my %tb_esc = (
  b => "\b",
  f => "\f",
  n => "\n",
  r => "\r",
  t => "\t",
  );
my %tb_ind = (
  B => [ 'c',            1],
  L => [['N', 'I', 'i'], 4],
  S => [['n', 'S', 's'], 2],
  b => [ 'c',            1],
  l => [['V', 'I', 'i'], 4],
  s => [['v', 'S', 's'], 2],
  );
my %tb_pat = (
  q{message/news}   =>
    [q{^(Newsgroups|Path|X-Newsreader): },
    ],
  q{message/rfc822} =>
    [q{^(Received|From|To|Return-Path|Cc|X-Mailer):},
    ],
  q{text/html}      =>
    [q{<(html|HTML|head|HEAD|body|BODY|title|TITLE|h1|h2)[^>]*>},
    ],
  q{text/x-roff}    =>
    ['^\\.\\\\"',
     "^\\.(BR|IR|PP|SH|SS|TH|TP) ",
    ],
  );
my %tb_typ = (
  q{message/news}   => q{news},
  q{message/rfc822} => q{mail},
  q{text/html}      => q{html},
  q{text/x-roff}    => q{nroff},
  );
my %tb_tpl = (
  byte     => ['c', 1],
  char     => ['c', 1],
  date     => ['l', 4],
  double   => ['d', 8],
  float    => ['f', 4],
  llong    => ['q', 8],
  long     => ['l', 4],
  quad     => ['q', 8],
  short    => ['s', 2],
  ubyte    => ['C', 1],
  uchar    => ['C', 1],
  ullong   => ['Q', 8],
  ulong    => ['L', 4],
  uquad    => ['Q', 8],
  ushort   => ['S', 2],

  bedate   => [ 'N',             4],
  bedouble => [ 'd>',            8],
  befloat  => [ 'f>',            8],
  belong   => [['N', 'I', 'i' ], 4],
  quad     => [ 'q>',            8],
  beshort  => [['n', 'S', 's' ], 2],
  ubelong  => [ 'N',             4],
  ubeshort => [ 'n', 2 ],

  ledate   => [ 'V',           4],
  ledouble => [ 'd<',          8],
  lefloat  => [ 'f<',          8],
  lelong   => [['V', 'I', 'i'],4],
  lequad   => [ 'q<',          8],
  leshort  => [['v', 'S', 's'],2],
  uleshort => [ 'v',           2],
  ulelong  => [ 'V',           4],
  );

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<$h = RDA::Object::Type-E<gt>new($file)>

The object constructor. It takes the path to the magic file as an argument.

C<RDA::Object::Type> is represented by a blessed hash reference. The following
special keys are used:

=over 12

=item S<    B<'ebc' > > When true, supports 8-bit characters

=item S<    B<'lnk' > > When true, follows symbolic links

=item S<    B<'_buf'> > Buffered magic line

=item S<    B<'_def'> > Magic definition

=item S<    B<'_err'> > Number of parsing errors

=item S<    B<'_ifh'> > Magic file handle

=item S<    B<'_lin'> > Number of the current magic line

=item S<    B<'_pat'> > Pattern hash

=item S<    B<'_sta'> > When true, always use stat()

=back

Internal keys are prefixed by an underscore.

=cut

sub new
{ my ($cls, $fil) = @_;
  my ($flg, $ifh);

  # Associate a magic file
  die get_string('NO_MAGIC') unless defined($fil);
  $ifh = IO::File->new;
  $ifh->open(qq{<$fil}) or die get_string('ERR_MAGIC', $fil, $!);
  binmode($ifh);

  # Create the object and return its reference
  $flg = RDA::Object::Rda->is_unix || RDA::Object::Rda->is_cygwin;
  return bless {
    ebc  => 1,
    lnk  => $flg,
    _buf => undef,
    _def => [],
    _err => 0,
    _ifh => $ifh,
    _lin => 0,
    _pat => {%tb_pat},
    _sta => !$flg,
    _typ => {%tb_typ},
    }, ref($cls) || $cls;
}

=head2 S<$h-E<gt>get_mime($file[,$flag])>

This methods returns the MIME type associated to the specified file. Unless the
flag is set, it raises an error instead of returning an undefined value.

=cut

sub get_mime
{ return _get_file_desc(0, @_);
}

=head2 S<$h-E<gt>get_type($file[,$flag])>

This methods returns the type associated to the specified file. Unless the flag
is set, it raises an error instead of returning an undefined value.

=cut

sub get_type
{ return _get_file_desc(1, @_);
}

=head2 S<$h-E<gt>add_patterns($key,$typ,$pat...)>

When a file type cannot be determined by magic numbers, extra checks are done
based on extra regular expressions, which can be defined here. This method
associates patterns to a file type. The first argument is the MIME type, the
second argument is the file type, and the remaining arguments are one or more
regular expressions.

By default, patterns are defined for C<message/news>, C<message/rfc822>,
C<text/html>, C<text/x-roff>.

=cut

sub add_patterns
{ my ($slf, $key, $typ, @arg) = @_;
  my (@pat);

  # Validate the regular expressions
  foreach my $pat (@arg)
  { push(@pat, RDA::Object::View->is_re($pat));
  }

  # Create the entry
  if (@pat)
  { $slf->{'_pat'}->{$key} = [@pat];
    $slf->{'_typ'}->{$key} = $typ;
  }
  return $slf;
}

=head2 S<$h-E<gt>remove_patterns($key,...)>

This method removes special regular expressions for the specified types. When
no types are specified, it removes all special patterns. It returns a hash
containing the removed entries.

=cut

sub remove_patterns
{ my ($slf, @key) = @_;
  my (%tbl);

  @key = keys(%{$slf->{'_pat'}}) unless @key;
  foreach my $key (@key)
  { $tbl{$key} = [delete($slf->{'_typ'}->{$key}),
                  @{delete($slf->{'_pat'}->{$key})}]
      if exists($slf->{'_pat'}->{$key});
  }
  return %tbl;
}

=head1 MAGIC DEFINITION METHODS

=head2 S<$h-E<gt>add_magic($lin...)>

This method adds a new magic entry in the object. The format is same as the
magic(5) file. For example,

  $h->add_magic(
    '0               string          MZ',
    '>24             leshort         >0x3f',
    '!:mime application/octet-stream',
    '>>(60.l)        string          PE\0\0  PE',
    '>>>(60.l+25)    byte            1       \b32 executable',
    '>>>(60.l+25)    byte            2       \b32+ executable');

=cut

sub add_magic
{ my ($slf, @lin) = @_;
  my ($cnt, $def, $pre, $rec);

  $cnt = 0;
  foreach my $lin (@lin)
  { ++$cnt;
    if ($lin =~ s/^!:(mime)\s+(\S+)//)
    { $rec->[3]->{$1} = $2 if defined($rec);
    }
    elsif ($lin =~ s/^>//)
    { $def = $slf->{'_def'}->[0]->[2];
      $pre = q{>};
      while ($lin =~ s/^>//)
      { $def = $def->[0]->[2];
        $pre .= q{>};
      }
      push(@{$def}, $rec = [$pre.$lin, "A$cnt", [], {}]);
    }
    else
    { unshift(@{$slf->{'_def'}}, $rec = [$lin, "A$cnt", [], {}]);
    }
  }
  return $slf;
}

=head2 S<$h-E<gt>check_magic([$flg])>

This method reads the magic file and dumps the definition entries when the
flag is set. It returns the number of parsing errors.

=cut

sub check_magic
{ my ($slf, $flg) = @_;

  # When not yet done, read the whole magic file
  _read_entry($slf, $slf->{'_def'}, 0) while !$slf->{'_ifh'}->eof;

  # Dump the magic definitions
  _dump_magic($slf, $slf->{'_def'}, q{}) if $flg;

  # Return the number of parsing errors
  return $slf->{'_err'};
}

# --- Internal routines -------------------------------------------------------

# Dump the magic definitions
sub _dump_magic
{ my ($slf, $tbl, $pre) = @_;
  my ($buf, $lgt, $mim, $msg, $msk, $off, $opr, $sub, $tmp, $tpl, $typ, $val);

  if ($tbl)
  { foreach my $itm (@{$tbl})
    { # Treat delayed evaluation
      if (@{$itm} == 4)
      { next unless ($tmp = _parse_line($slf, @{$itm}));
        @{$itm} = @{$tmp};
      }
      next unless defined($itm);

      # Treat a record
      ($off, $lgt, $typ, $msk, $opr, $val, $tpl, $msg, $mim, $sub) = @{$itm};
      $buf = $pre._fmt_off(defined($off) ? $off : q{&0}).qq{\t}.$typ;
      if (ref($msk) eq 'ARRAY')
      { $buf = join(q{/}, $buf, @{$msk});
      }
      elsif ($msk)
      { $buf .= q{&}.$msk;
      }
      $buf .= qq{\t};
      $buf .= $opr           if defined($opr) && $opr ne q{=};
      $buf .= _fmt_str($val) if defined($val);
      $buf .= qq{\t}.$msg    if defined($msg) && length($msg);
      $buf .= qq{\n};
      $buf .= qq{!:mime $mim\n} if defined($mim);
      syswrite($RDA::Text::TRACE, $buf, length($buf));

      # Treat sub tests
      _dump_magic($slf, $sub, q{>}.$pre) if $sub;
    }
  }
  return;
}

# Format an offset for display
sub _fmt_off
{ my ($cmd) = @_;
  my ($typ);

  return $cmd ? sprintf('0%o', $cmd) : $cmd unless ref($cmd) eq 'ARRAY';
  $typ = $cmd->[0];
  return $tb_rel[$cmd->[2]]._fmt_off($cmd->[1]) if $typ eq 'seek';
  return _fmt_off($cmd->[1]).q{.}.$cmd->[2]     if $typ eq 'read';
  return q{(}._fmt_off($cmd->[1]).q{)}          if $typ eq 'dir'
                                                || $typ eq 'ind';
  return _fmt_off($cmd->[1]).$typ._fmt_off($cmd->[2]);
}

# Format a string for display
sub _fmt_str
{ my ($str) = @_;

  $str =~ s{([^\041-\176])}{sprintf('\\%03o',ord($1))}egs;
  $str =~ s/^([!=])/\\$1/;
  return $str;
}

# Get the description from a file
sub _get_file_desc
{ my ($flg, $slf, $fil, $ret) = @_;
  my ($ifh, $lin, $typ);

  # Treat a buffer request
  return _get_handle_desc($slf, $fil->get_handle, $flg)
    if ref($fil) eq 'RDA::Object::Buffer';

  # Abort when the file is not readable
  unless (-r $fil)
  { die get_string('NO_READ', $fil) unless $ret;
    return;
  }

  # Treat special files
  return sprintf($tb_dsc{'sys'}->[$flg], $typ)
    if defined($typ = _is_special($slf, $fil));

  # Get a file handle
  $ifh = IO::File->new;
  unless ($ifh->open(qq{< $fil}))
  { die get_string('ERR_OPEN', $fil, $!) unless $ret;
    return;
  }
  binmode($ifh);

  # Check for script and possible bang line
  if (-x $fil)
  { if (RDA::Object::Rda->is_unix && -T _)
    { $lin = <$ifh>;
      $ifh->close;
      return sprintf($tb_dsc{'sys'}->[$flg], ($lin =~ /^\#!\s*(\S+)/)
        ? qq{executable $1 script text}
        : q{commands text});
    }
    if (RDA::Object::Rda->is_windows && -T _)
    { $ifh->close;
      return sprintf($tb_dsc{'sys'}->[$flg], q{commands text});
    }
    if (RDA::Object::Rda->is_cygwin && -T _)
    { $lin = <$ifh>;
      if ($lin =~ /^\#!\s*(\S+)/)
      { $ifh->close;
        return sprintf($tb_dsc{'sys'}->[$flg], qq{executable $1 script text})
      }
    }
  }

  # Determine the file type
  $typ = _get_handle_desc($slf, $ifh, $flg);
  $ifh->close;
  return $typ;
}

# Get the description from a handle
sub _get_handle_desc  ## no critic (Complex)
{ my ($slf, $ifh, $flg) = @_;
  my ($dat, $dsc, $min, $pos, $rec, $typ, @key, %val);

  binmode($ifh);

  # Treat magic entries already loaded
  foreach my $rec (@{$slf->{'_def'}})
  { return $dsc
      if _match_entry($slf, $ifh, $rec, \$dsc, $flg)
      && defined($dsc) && $dsc ne q{};
  }

  # Read more entries from the magic file
  while (!$slf->{'_ifh'}->eof)
  { return $dsc
      if ($rec = _read_entry($slf, $slf->{'_def'}, 0, 1))
      && _match_entry($slf, $ifh, $rec, \$dsc, $flg)
      && defined($dsc) && $dsc ne q{};
  }

  # Check data
  return $tb_dsc{'txt'}->[$flg]
    unless $ifh->seek(0, 0) && $ifh->read($dat, $LGT);

  # Check the presence of any pattern
  foreach my $typ (keys(%{$slf->{'_pat'}}))
  { $min = undef;
    foreach my $tok (@{$slf->{'_pat'}->{$typ}})
    { pos($dat) = 0;
      if ($dat =~ /$tok/mg)
      { $pos = pos $dat;
        $min = $pos unless defined($min) && $pos >= $min;  ## no critic (Unless)
      }
    }
    $val{$typ} = $min if defined($min);
  }
  return $flg ? $slf->{'_typ'}->{$key[0]} : $key[0]
    if (@key = sort {$val{$a} <=> $val{$b}} keys(%val));

  # Return the data type
  return _is_binary($slf, $dat) ? $tb_dsc{'bin'}->[$flg]
                                : $tb_dsc{'txt'}->[$flg];
}

# Determine whether it is a binary file
sub _is_binary
{ my ($slf, $dat) = @_;
  my ($cnt, $lgt);

  return 1 unless ($lgt = length($dat));
  if ($slf->{'8bc'})
  { $cnt = ($dat =~ tr/\x00-\x08\x0b-\x0c\x0e-\x1a\x1c-\x1f//);
    return 1 if ($cnt / $lgt) > 0.1;  ## no critic (Number)
  }
  else
  { $cnt = ($dat =~ tr/\x00-\x08\x0b-\x0c\x0e-\x1a\x1c-\x1f\x80-\xff//);
    return 1 if ($cnt / $lgt) > 0.3;  ## no critic (Number)
  }
  return 0;
}

# Determine whether it is a special file
sub _is_special
{ my ($slf, $fil) = @_;

  if ($slf->{'_sta'} || $slf->{'lnk'})
  { stat($fil);
  }
  else
  { lstat($fil);
  }
  unless (-f _)
  { return q{symbolic link to }.readlink($fil)
      if !$slf->{'_sta'} && !$slf->{'lnk'} && -l _;
    return q{directory}        if -d _;
    return q{named pipe}       if -p _;
    return q{socket}           if -S _;
    return q{block device}     if -b _;
    return q{character device} if -c _;
    return q{special};
  }
  return q{empty} if -z _;
  return;
}

# Compare the magic item with the file handle
sub _match_entry  ## no critic (Complex)
{ my ($slf, $ifh, $itm, $dsc, $flg) = @_;
  my ($chr, $dat, $hit, $lgt, $mim, $msg, $msk, $off, $opr, $pos, $sub, $tmp,
      $tpl, $typ, $val, @dat, @tst);

  # Parse an entry on first use
  if (@{$itm} == 4)
  { $tmp = _parse_line($slf, @{$itm});
    return unless defined($tmp);
    @{$itm} = @{$tmp};
  }
  return unless defined($itm) && defined($ifh);
  ($off, $lgt, $typ, $msk, $opr, $val, $tpl, $msg, $mim, $sub) = @{$itm};

  # Adjust the current position
  _set_off($ifh, $off) if defined($off);

  # Check for a hit
  @dat = ($dat = q{});
  $hit = 0;
  if ($typ eq 'string')
  { # Read the string
    if ($lgt > 0)
    { return if $ifh->read($dat, $lgt) != $lgt;
      ($dat) = @dat = ($dat =~ m/(.*)/s);
    }
    else
    { ($dat) = @dat = _read_line($ifh, (index($msk->[0], 's', 1) < 0) ? 0 : 8);
    }

    # Apply string transformations
    if (index($msk->[0], 't', 1) > 0)
    { $dat =~ s/^\s+//;
      $dat =~ s/[\n\r\s]+$//;
    }
    $dat =~ s/\s+/ /g if index($msk->[0], 'b', 1) > 0;
    $dat = lc($dat) if index($msk->[0], 'c', 1) > 0;

    # Perform the comparison
    if ($opr eq q{=})
    { $hit = ($dat eq $val);
    }
    elsif ($opr eq q{x})
    { $hit = 1;
    }
    elsif ($opr eq q{!})
    { $hit = ($dat ne $val);
    }
    elsif ($opr eq q{<})
    { $hit = ($dat lt $val);
    }
    elsif ($opr eq q{>})
    { $hit = ($dat gt $val);
    }
    debug('TYPE> STRING: '._fmt_str($dat)." $opr "._fmt_str($val)
      ." => $hit") if $DUMP;
  }
  elsif ($typ eq 'clear')
  { $hit = 1;
    debug('TYPE> CLEAR') if $DUMP;
  }
  elsif ($typ eq 'default')
  { $hit = !$$dsc;
    debug("TYPE> DEFAULT: $hit") if $DUMP;
  }
  elsif ($typ eq 'regex')
  { # Read the string
    ($dat) = @dat = _read_line($ifh, (index($msk->[0], 's', 1) < 0) ? 0 : 8);

    # Perform the comparison
    if (index($msk->[0], 'c', 1) > 0)
    { if ($opr eq q{?})
      { $hit = $dat =~ m/$val/i;
      }
      elsif ($opr eq q{~})
      { $hit = @dat = $dat =~ m/$val/i;
      }
    }
    else
    { if ($opr eq q{?})
      { $hit = $dat =~ m/$val/;
      }
      elsif ($opr eq q{~})
      { $hit = @dat = $dat =~ m/$val/;
      }
    }
    debug('TYPE> REGEX: '._fmt_str($dat)." $opr "._fmt_str($val)
      ." => $hit") if $DUMP;
  }
  elsif ($typ eq 'search')
  { debug('TYPE> SEARCH: not implemented') if $DUMP;
  }
  else
  { # Read the number
    return if $ifh->read($dat, $lgt) != $lgt;
    ($dat) = ($dat =~ m/(.*)/s);
    $dat = ref($tpl)
      ? unpack($tpl->[2], pack($tpl->[1], unpack($tpl->[0], $dat)))
      : unpack($tpl, $dat);

    # Apply a mask
    $dat &= $msk if defined($msk);      ## no critic (Bit)
    @dat = ($dat);

    # Perform the comparison
    if ($opr eq q{=})
    { $hit = ($dat == $val);
    }
    elsif ($opr eq q{x})
    { $hit = 1;
    }
    elsif ($opr eq q{&})
    { $hit = (($dat & $val) == $val);   ## no critic (Bit)
    }
    elsif ($opr eq q{^})
    { $hit = ((~$dat & $val) == $val);  ## no critic (Bit)
    }
    elsif ($opr eq q{!})
    { $hit = ($dat != $val);
    }
    elsif ($opr eq q{<})
    { $hit = ($dat < $val);
    }
    elsif ($opr eq q{>})
    { $hit = ($dat > $val);
    }
    debug(sprintf(($val > 255)
      ? q{TYPE> NUMERIC: 0x%x %s 0x%x => %s}
      : q{TYPE> NUMERIC: %d %s %d => %s}, $dat, $opr, $val, $hit)) if $DUMP;
  }
  return 0 unless $hit;

  # Apply a format
  if ($flg)
  { $$dsc = defined($$dsc)
      ? $$dsc.sprintf(($msg =~ m/^\\b(.*)/) ? $1 :
                      length($$dsc)         ? q{ }.$msg :
                                              $msg, @dat)
      : sprintf(($msg =~ m/^\\b(.*)/) ? $1 : $msg, @dat)
      if defined($msg) && length($msg);
  }
  elsif (defined($mim))
  { $$dsc = $mim;
    return -1;
  }

  # Perform sub tests
  if (@tst = (@{$sub}))
  { $pos = $ifh->getpos;
    foreach my $tst (@{$sub})
    { return -1 if _match_entry($slf, $ifh, $tst, $dsc, $flg) < 0;
      $ifh->setpos($pos);
    }
  }
  return 1;
}

# Parse a magic line
sub _parse_line  ## no critic (Complex)
{ my ($slf, $lin, $num, $sub, $opt) = @_;
  my ($mim, $msg, $msk, $off, $opr, $rec, $siz, $tpl, $typ, $val);

  # Extract the offset and its type
  if ($lin =~ s/^>*(&?\(?[\dA-FLSa-flsx\.\+\-\*\/\&\^\!\%\|]+\)?)\s+(\S+)\s+//)
  { ($off, $typ) = ($1, $2);

    if ($off =~ m/^(&)?\((&)?($NUM)(\.($SIZ))?(($OPR)?($NUM))?\)/)
    { $rec = ['seek', (substr($3, 0, 1) eq q{0}) ? oct($3) : $3, $2 ? 1 : 0];
      $rec = ['read', $rec, defined($4) ? $5 : q{l}];
      $rec = [$7 || q{+}, $rec, (substr($8, 0, 1) eq q{0}) ? oct($8) : $8]
        if defined($6);
      $off = $1
        ? ['seek', ['ind', $rec], 1]
        : ['seek', ['dir', $rec], 0];
    }
    elsif ($off =~ /^&?\(/)
    { debug(get_string('Indirect', $off, $num)) if $DUMP;
      ++$slf->{'_err'};
      return;
    }
    elsif ($off =~ s/^&//o)  # Relative offset
    { $off = $off
        ? ['seek', (substr($off, 0, 1) eq q{0}) ? oct($off) : $off, 1]
        : undef;
    }
    else                     # Absolute offset
    { $off = ['seek', (substr($off, 0, 1) eq q{0}) ? oct($off) : $off, 0];
    }
  }
  else
  { debug(get_string('Offset', $lin, $num)) if $DUMP;
    ++$slf->{'_err'};
    return;
  }

  # Determine the mask
  $msk = (substr($1, 0, 1) eq q{0}) ? oct($1) : $1 if $typ =~ s/&(.*)//;

  # Check type validity
  unless (exists($tb_tpl{$typ}))
  { if ($typ =~ m{^(string)(/[bct]+)?$})
    { ($typ, $msk) = ($1, [$2 || q{}]);
    }
    elsif ($typ =~ m{^(regex)(/[cs]+)?$})
    { ($typ, $msk) = ($1, [$2 || q{}]);
    }
    elsif ($typ =~ m{^(search)/(\d+)(/[bct]+)?$})
    { ($typ, $msk) = ($1, [$2, $3 || q{}]);
    }
    elsif ($typ ne 'clear' && $typ ne 'default')
    { debug(get_string('Type', $typ, $num)) if $DUMP;
      ++$slf->{'_err'};
      return;
    }
  }

  # Take everything after the first non-escaped space
  $lin =~ s/\n?$/\n/;
  if ($lin =~ s/([^\\])\s+(.*)/$1/)
  { $msg = $2;
  }
  else
  { debug(get_string('Syntax', $num)) if $DUMP;
    ++$slf->{'_err'};
    return;
  }

  # Extract the operator
  $lin =~ s/\n$//o;
  $opr = ($typ eq 'regex')          ? q{~} :
         ($lin =~ s/^([><&^=!])//o) ? $1 :
         ($lin eq q{x})             ? q{x} :
                                      q{=};

  # Extract the value
  if ($typ eq 'string')
  { # Perform octal, hexadecimal, and escape conversions
    $val = $lin;
    $val =~ s/\\x([0-9a-fA-F][0-9a-fA-F])/pack('H2', $1)/eg;
    $val =~ s/\\([0-7]{1,3})/chr(oct($1))/eg;
    $val =~ s/\\(.)/$tb_esc{$1} || $1/eg;
    $val = lc($val) if index($msk->[0], 'c', 1) > 0;

    # Determine the number bytes to read
    if ($opr =~ m/[>x]/o)
    { $siz = 0;
    }
    elsif ($opr =~ /[=<!]/o)
    { $siz = ($msk->[0] =~ m/[bt]/) ? 0 : length($val);
    }
    else
    { debug(get_string('String', $opr, $num)) if $DUMP;
      ++$slf->{'_err'};
      return;
    }
  }
  elsif ($typ eq 'clear')
  { $val = $lin;
  }
  elsif ($typ eq 'default')
  { $val = $lin;
  }
  elsif ($typ eq 'regex')
  { # Perform octal, hexadecimal, and escape conversions
    $val = $lin;
    $val =~ s/\\x([0-9a-fA-F][0-9a-fA-F])/pack('H2', $1)/eg;
    $val =~ s/\\([0-7]{1,3})/chr(oct($1))/eg;
    $val =~ s/\\(.)/$tb_esc{$1} || $1/eg;
    $siz = 0;

    # Validate the regular expression
    unless (defined(RDA::Object::View->is_re($val, 1)))
    { debug(get_string('Regexp', $num, $@)) if $DUMP;
      ++$slf->{'_err'};
      return;
    }

    # Detect capture buffers
    $opr = q{?} unless $val =~ m/\([^\?].*?\)/;
  }
  elsif ($typ =~ m/^search\//)
  { $val = $lin;
    $val =~ s/\\x([0-9a-fA-F][0-9a-fA-F])/pack('H2', $1)/eg;
    $val =~ s/\\([0-7]{1,3})/chr(oct($1))/eg;
    $val =~ s/\\(.)/$tb_esc{$1} || $1/eg;
    $siz = length($val);
  }
  elsif (exists($tb_tpl{$typ}))
  { ($tpl, $siz) = @{$tb_tpl{$typ}};

    # Extract a number from the string
    $val = ($opr eq q{x})  ? 0 :
           ($lin =~ /^0/o) ? oct($lin) :
                             int($lin);
  }
  else
  { debug(get_string('Type', $typ, $num)) if $DUMP;
    ++$slf->{'_err'};
    return;
  }

  # Determine thye MIME contribution
  $mim = $opt->{'mime'} if exists($opt->{'mime'});

  # Return a magic record
  return [$off, $siz, $typ, $msk, $opr, $val, $tpl, $msg, $mim, $sub];
}

# Read the next entry from the magic file
sub _read_entry  ## no critic (Complex)
{ my ($slf, $tbl, $lvl, $flg) = @_;
  my ($cur, $ifh, $itm, $lin);

  $ifh = $slf->{'_ifh'};
  $lin = $slf->{'_buf'};
  $lvl = 0 unless defined($lvl);
  for (;;)  ## no critic (Loop)
  { $lin = q{} unless defined($lin);

    # Skip comments and empty lines
    if ($lin =~ /^\#/ || $lin =~ /^\s*$/)
    { return if $ifh->eof;
      $lin = <$ifh>;
      $slf->{'_lin'}++;
      next;
    }

    # Treat MIME definition
    if ($lin =~ m/^!:(mime)\s+(\S+)/)
    { $itm->[3]->{$1} = $2 if ref($itm) eq 'ARRAY';

      # Read the next line
      return $flg ? $itm : $cur if $ifh->eof;
      $lin = <$ifh>;
      $slf->{'_lin'}++;
    }

    # Determine the line level
    ($cur) = ($lin =~ m/^(>+)/);
    $cur = defined($cur) ? length($cur) : 0;

    # Treat the line according to its level
    if ($cur > $lvl)
    { # Execute the code recursively
      $slf->{'_buf'} = $lin;
      return $flg ? $itm : $cur
        if !defined($cur = _read_entry($slf, $itm->[2], $lvl + 1))
        || $cur < $lvl
        || $slf->{'_ifh'}->eof;
      $lin = $slf->{'_buf'};
    }
    elsif ($cur < $lvl)
    { # Save the line and exit
      $slf->{'_buf'} = $lin;
      return $flg ? $itm : $cur;
    }
    elsif (ref($itm) eq 'ARRAY' && @{$itm})
    { # As we already have an entry, save this line for the next call and exit
      $slf->{'_buf'} = $lin;
      return $flg ? $itm : $cur;
    }
    else
    { # Create a empty entry and add it in the list
      push(@{$tbl}, $itm = [$lin, $slf->{'_lin'}, [], {}]);

      # Read the next line
      return $flg ? $itm : $cur if $ifh->eof;
      $lin = <$ifh>;
      $slf->{'_lin'}++;
    }
  }
}

# Read a line
sub _read_line
{ my ($ifh, $skp) = @_;
  my ($chr, $dat);

  $dat = q{};
  $dat .= $chr
    while defined($chr = $ifh->getc()) && $chr ne qq{\0} && $chr ne qq{\n};
  return _read_line($ifh, --$skp) if $skp && $dat =~ m/^#/;
  return ($dat =~ m/(.*)/s);
}

# Adjust the handle position
sub _set_off
{ my ($ifh, $cmd) = @_;
  my ($off, $pos, $siz, $tpl, $typ, $val);

  return $cmd unless ref($cmd) eq 'ARRAY';
  $typ = $cmd->[0];
  if ($typ eq 'seek')
  { return 1 unless defined($val = _set_off($ifh, $cmd->[1]));
    debug(sprintf(q{TYPE> SEEK(0%o,%s)}, $val, $cmd->[2])) if $DUMP;
    return $ifh->seek($val, $cmd->[2]);
  }
  if ($typ eq 'read')
  { return unless defined($val = _set_off($ifh, $cmd->[1]));
    ($tpl, $siz) = @{$tb_ind{$cmd->[2]}};
    return unless $ifh->read($val, $siz) == $siz;
    $val = (ref($tpl) eq 'ARRAY')
      ? unpack($tpl->[2], pack($tpl->[1], unpack($tpl->[0], $val)))
      : unpack($tpl, $val);
    debug(q{TYPE> READ(}.$cmd->[2].qq{): $val}) if $DUMP;
    return $val;
  }
  return _set_off($ifh, $cmd->[1]) if $typ eq 'dir';
  if ($typ eq 'ind')
  { $pos = $ifh->getpos;
    $off = _set_off($ifh, $cmd->[1]);
    $ifh->setpos($pos);
    return $off;
  }
  ## no critic (Bit)
  return _set_off($ifh, $cmd->[1]) + _set_off($ifh, $cmd->[2]) if $typ eq q{+};
  return _set_off($ifh, $cmd->[1]) - _set_off($ifh, $cmd->[2]) if $typ eq q{-};
  return _set_off($ifh, $cmd->[1]) * _set_off($ifh, $cmd->[2]) if $typ eq q{*};
  return _set_off($ifh, $cmd->[1]) / _set_off($ifh, $cmd->[2]) if $typ eq q{/};
  return _set_off($ifh, $cmd->[1]) % _set_off($ifh, $cmd->[2]) if $typ eq q{%};
  return _set_off($ifh, $cmd->[1]) & _set_off($ifh, $cmd->[2]) if $typ eq q{&};
  return _set_off($ifh, $cmd->[1]) | _set_off($ifh, $cmd->[2]) if $typ eq q{|};
  return _set_off($ifh, $cmd->[1]) ^ _set_off($ifh, $cmd->[2]) if $typ eq q{^};
  return;
}

# --- SDCL extensions ---------------------------------------------------------

# Attach the file type identification object
sub _begin_control
{ my ($pkg) = @_;
  my ($agt);

  $agt = $pkg->get_agent;
  $pkg->set_top('TYP', $agt->get_registry('TYP', \&new, __PACKAGE__,
    $agt->get_config->get_file('D_RDA_DAT', 'magic.txt')));
  return;
}

# Detach the file type identification object
sub _end_control
{ my ($pkg) = @_;

  $pkg->set_top('TYP');
  return;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Build|RDA::Build>,
L<RDA::Object|RDA::Object>,
L<RDA::Object::Buffer|RDA::Object::Buffer>,
L<RDA::Object::Rda|RDA::Object::Rda>,
L<RDA::Object::View|RDA::Object::View>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
