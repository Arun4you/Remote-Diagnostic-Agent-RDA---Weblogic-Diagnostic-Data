# FILTER.pm: Filter Command Library

package RDA::Request::FILTER;

# $Id: FILTER.pm,v 1.27 2015/05/09 14:47:00 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Request/FILTER.pm,v 1.27 2015/05/09 14:47:00 RDA Exp $
#
# Change History
# 20150508  MSC  Change the display.

=head1 NAME

RDA::Request::FILTER - Filter Command Library

=head1 SYNOPSIS

require RDA::Request::RDA;

=head1 DESCRIPTION

The objects of the C<RDA::Request::RDA> class are used to manage output
filtering.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use IO::File;
  use RDA::Text qw(get_string);
  use RDA::Agent;
  use RDA::Handle::Filter qw(%FLT_FORMATS);
  use RDA::Object;
  use RDA::Object::Message;
  use RDA::Object::Rda qw($CREATE $FIL_PERMS);
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.27 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(Exporter);

# Define the global private constants
my $FILTER = ($^O eq 'VMS')        ? 'filter.vms' :
             ($^O eq 'MSWin32')    ? 'filter.win' :
             ($^O eq 'MSWin64')    ? 'filter.win' :
             ($^O eq 'Windows_NT') ? 'filter.win' :
             ($^O eq 'cygwin')     ? 'filter.win' :
                                     '.filter';

my $RE_NAM = qr/^[A-Z][A-Z\d\_]*$/;

my $NL  = qq{\n};
my $SPC = q{ };
my $UND = q{_};

# Define the global private variables
## no critic (Interpolation,Numbered)
my @tb_ip4 = (
  '<<$1:$3>>\d{1,3}(\.\d{1,3}){3}',
  );
my @tb_ip6 = (
  '<<$1:$3>>[A-F\d]{1,4}(\:[A-F\d]{1,4}){7}',
  '<<$1:$4>>([A-F\d]{1,4}\:){1,5}(\:[A-F\d]{1,4}){1,5}',
  '<<$1:$3>>\:(\:[A-F\d]{1,4}){1,6}',
  '<<$1:$3>>([A-F\d]{1,4}\:){1,6}\:',
  );
my @tb_msk = (
  '<<$1:$3>>255(\.\d{1,3}){3}',
  '<<$1:$2>>0\.0\.0\.0',
  );
## use critic
my %tb_cmd = (
  'FILTER.ADD_FILE'     => \&_do_add_file,
  'FILTER.ADD_FORMAT'   => \&_do_add_format,
  'FILTER.ADD_META'     => \&_do_add_meta,
  'FILTER.ADD_MODULE'   => \&_do_add_module,
  'FILTER.ADD_PATTERN'  => \&_do_add_pattern,
  'FILTER.ADD_REPORT'   => \&_do_add_report,
  'FILTER.ADD_RESTRICT' => \&_do_add_restrict,
  'FILTER.ADD_SET'      => \&_do_add_set,
  'FILTER.ADD_TAG'      => \&_do_add_tag,
  'FILTER.CLEAR'        => \&_do_clear,
  'FILTER.DEFAULT'      => \&_do_default,
  'FILTER.DEFINE'       => \&_do_define,
  'FILTER.DEL_FILE'     => \&_do_del_file,
  'FILTER.DEL_FORMAT'   => \&_do_del_format,
  'FILTER.DEL_META'     => \&_do_del_meta,
  'FILTER.DEL_MODULE'   => \&_do_del_module,
  'FILTER.DEL_PATTERN'  => \&_do_del_pattern,
  'FILTER.DEL_REPORT'   => \&_do_del_report,
  'FILTER.DEL_RESTRICT' => \&_do_del_restrict,
  'FILTER.DEL_SET'      => \&_do_del_set,
  'FILTER.DEL_TAG'      => \&_do_del_tag,
  'FILTER.DISABLE'      => \&_do_disable,
  'FILTER.DSP_SET'      => \&_do_dsp_set,
  'FILTER.ENABLE'       => \&_do_enable,
  'FILTER.EXP_META'     => \&_do_expand_meta,
  'FILTER.EXPORT'       => \&_do_export,
  'FILTER.GET_FILES'    => \&_do_get_files,
  'FILTER.GET_FORMATS'  => \&_do_get_formats,
  'FILTER.GET_META'     => \&_do_get_meta,
  'FILTER.GET_MODULES'  => \&_do_get_modules,
  'FILTER.GET_REPORTS'  => \&_do_get_reports,
  'FILTER.GET_RESTRICT' => \&_do_get_restrict,
  'FILTER.GET_SETS'     => \&_do_get_sets,
  'FILTER.GET_TAGS'     => \&_do_get_tags,
  'FILTER.REMOVE'       => \&_do_remove,
  'FILTER.RESET'        => \&_do_reset,
  'FILTER.SAVE'         => \&_do_save,
  'FILTER.SET'          => \&_do_set,
  'FILTER.TEST'         => \&_do_test,
  );
my %tb_def = (
  format  => 'W_FORMAT',
  options => 'W_OPTIONS',
  string  => 'T_STRING',
  );
my %tb_fam = (
  cygwin  => 'SYSTEM.RESTRICT.T_UNIX',
  unix    => 'SYSTEM.RESTRICT.T_UNIX',
  vms     => 'SYSTEM.RESTRICT.T_VMS',
  windows => 'SYSTEM.RESTRICT.T_WINDOWS',
  );
my %tb_set = (
  cfm     => [1, 'OUTPUT.REFINE.N_CFM',  0],
  gid     => [0, 'FILTER.N_MINIMUM_GID', 0],
  regroup => [1, 'FILTER.N_REGROUP',     1],
  uid     => [0, 'FILTER.N_MINIMUM_UID', 0],
  );

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<$h = RDA::Request::FILTER-E<gt>new($agt)>

The object constructor. This method enables you to specify the agent reference
as an argument.

C<RDA::Request::FILTER> is represented by a blessed hash reference. The
following special keys are used:

=over 10

=item S<  B<'_agt'> > Reference to the agent object

=item S<  B<'_cfg'> > Reference to the RDA software configuration

=item S<  B<'_col'> > Reference to the collector object

=item S<  B<'_def'> > Reference to the result set definition

=item S<  B<'_flt'> > Reference to the filter definition

=item S<  B<'_lng'> > Reference to the SDSL language control object

=item S<  B<'_out'> > Reference to the output definition

=back

Internal keys are prefixed by an underscore.

=cut

sub new
{ my ($cls, $agt) = @_;
  my ($col, $def);

  # Create the library object and return the object reference
  $col = $agt->get_collector;
  $def = $col->get_definition;
  return bless {
    _agt => $agt,
    _cfg => $agt->get_config,
    _col => $col,
    _def => $def,
    _flt => $def->find('FILTER', 1),
    _lng => $agt->get_lang('SDSL'),
    _out => $def->find('OUTPUT.REFINE', 1),
    }, ref($cls) || $cls;
}

=head2 S<$h-E<gt>delete_object>

This method deletes the library object.

=cut

sub delete_object
{ RDA::Object::dump_caller($_[0], 'Commands') if $RDA::Object::DELETE;
  undef %{$_[0]};
  undef $_[0];
  return;
}

=head2 S<$h-E<gt>exec_command($req)>

This method executes the command specified in the message.

=cut

sub exec_command
{ my ($slf, $req) = @_;

  my $cmd = $req->{'msg'};
  return exists($tb_cmd{$cmd})
    ? &{$tb_cmd{$cmd}}($slf, $req)
    : $req->error('NotImplemented', get_string('BAD_COMMAND', $cmd));
}

=head1 FILTER MANAGEMENT COMMANDS

=head2 FILTER.ADD_FILE - Add file command

This command associates a new customer file management level to the specified
files. It supports the following attributes:

=over 9

=item B<  cfm>

Specifies the customer file manager level (C<3> by default).

=item B<  paths>

Specifies a list of file paths.

=back

=cut

sub _do_add_file
{ my ($slf, $req) = @_;
  my ($cfm, $cnt, $hsh, $out);

  # Treat the request
  $cnt = 0;
  $out = $slf->{'_out'};
  eval {
    # Determine the customer file management level
    $cfm = _get_cfm($req, 3);

    # Add the new file levels
    $hsh = $out->get_hash('N_FIL');
    foreach my $pth ($req->get_value('paths'))
    { next unless RDA::Object::Rda->is_absolute($pth);
      $hsh->{RDA::Object::Rda->native($pth, 1)} = $cfm;
      ++$cnt;
    }
    $out->set_temp('N_FIL', $hsh);

    # Run the module setup and save the context definition
    _setup($slf, 1) if $cnt;
    };

  # Indicate the completion status
  return $req->reply($@, 'AddFile');
}

=head2 FILTER.ADD_FORMAT - Add format command

This command defines additional substitution formats. It supports the following
attribute:

=over 8

=item B<  args>

Specifies a list of name-definition pairs. A format name must start with an
uppercase letter, followed by uppercase letters or underscores.

=back

=cut

sub _do_add_format
{ my ($slf, $req) = @_;
  my ($flt, $fmt, $tbl, $val, @arg);

  # Treat the request
  $flt = $slf->{'_flt'};
  eval {
    # Add the new formats
    $tbl = $flt->get_hash('T_FORMATS');
    @arg = $req->get_value('args');
    while (($fmt, $val) = splice(@arg, 0, 2))
    { $tbl->{$fmt} = $val if $fmt =~ m/^[A-Z][A-Z\d\_]*$/ && $val;
    }
    $flt->set_temp('T_FORMATS', $tbl);

    # Run the module setup and save the context definition
    _setup($slf);
    };

  # Indicate the completion status
  return $req->reply($@, 'AddFormat');
}

=head2 FILTER.ADD_META - Add meta command

This command adds a new directory structure to the list of directories where
status file information can be collected. It supports the following attributes:

=over 9

=item B<  level>

Specifies the recursion level (C<4> by default).

=item B<  paths>

Specifies a list of directory paths.

=back

=cut

sub _do_add_meta
{ my ($slf, $req) = @_;
  my ($cnt, $hsh, $lvl, $out);

  # Treat the request
  $cnt = 0;
  $out = $slf->{'_out'};
  eval {
    # Determine the recursion level
    $lvl = 4
      unless defined($lvl = $req->get_first('level')) && $lvl =~ m/^\d+$/;

    # Add the new directory structures
    $hsh = $out->get_hash('N_META');
    foreach my $pth ($req->get_value('paths'))
    { $hsh->{$pth} = $lvl;
      ++$cnt;
    }
    $out->set_temp('N_META', $hsh);

    # Run the module setup and save the context definition
    _setup($slf, 1) if $cnt;
    };

  # Indicate the completion status
  return $req->reply($@, 'AddMeta');
}

=head2 FILTER.ADD_MODULE - Add module command

This command associates a new customer file management level to the specified
modules. It supports the following attributes:

=over 9

=item B<  cfm>

Specifies the customer file manager level (C<3> by default).

=item B<  names>

Specifies a list of module abbreviations.

=back

=cut

sub _do_add_module
{ my ($slf, $req) = @_;
  my ($cfm, $cnt, $hsh, $key, $out);

  # Treat the request
  $cnt = 0;
  $out = $slf->{'_out'};
  eval {
    # Determine the customer file management level
    $cfm = _get_cfm($req, 3);

    # Add the new module levels
    foreach my $nam ($req->get_value('names'))
    { next unless $nam =~ m/^([A-Z][A-Z\d]*)[_\.]([A-Z][A-Z\d]*)_?$/;
      $out->set_temp("$1.$2.N_MOD", $cfm);
      ++$cnt;
    }

    # Run the module setup and save the context definition
    _setup($slf, 1) if $cnt;
    };

  # Indicate the completion status
  return $req->reply($@, 'AddModule');
}

=head2 FILTER.ADD_PATTERN - Add pattern command

This command adds more patterns in the pattern list of the specified rule
set. It supports the following attributes:

=over 8

=item B<  args>

Specifies a list of regular expressions.

=item B<  name>

Specifies the rule set name.

=back

=cut

sub _do_add_pattern
{ my ($slf, $req) = @_;
  my ($nam, $set);

  # Validate the request
  $nam = $req->get_first('name', q{});
  return $req->error('BadSet')
    unless $nam =~ $RE_NAM && ($set = $slf->{'_flt'}->find($nam));

  # Treat the request
  eval {
    # Treat the request
    $set->set_temp('T_PATTERNS', [$set->get_value('T_PATTERNS'),
      grep {$_} $req->get_value('args')]);

    # Run the module setup and save the context definition
    _setup($slf);
    };

  # Indicate the completion status
  return $req->reply($@, 'AddPattern');
}

=head2 FILTER.ADD_REPORT - Add report command

This command associates a new customer file management level to the specified
reports. It supports the following attributes:

=over 9

=item B<  cfm>

Specifies the customer file manager level (C<3> by default).

=item B<  names>

Specifies a list of report names.

=back

=cut

sub _do_add_report
{ my ($slf, $req) = @_;
  my ($cfm, $out, @key, %hsh);

  # Treat the request
  $out = $slf->{'_out'};
  eval {
    # Determine the customer file management level
    $cfm = _get_cfm($req, 3);

    # Add the new report levels
    foreach my $nam ($req->get_value('names'))
    { my ($key);

      next unless $nam =~ m/^([A-Z][A-Z\d]*)_([A-Z][A-Z\d]*)_(\w+)$/;
      $key = "$1.$2.N_RPT";
      $hsh{$key} = $out->get_hash($key) unless exists($hsh{$key});
      $hsh{$key}->{$3} = $cfm;
    }

    # Run the module setup and save the context definition
    if (@key = keys(%hsh))
    { foreach my $key (@key)
      { $out->set_temp($key, $hsh{$key});
      }
      _setup($slf, 1);
    }
    };

  # Indicate the completion status
  return $req->reply($@, 'AddReport');
}

=head2 FILTER.ADD_RESTRICT - Add restriction command

This command adds the specified commands to the list of commands with execution
restrictions. It supports the following attributes:

=over 10

=item B<  family>

Specifies the related operating system family.

=item B<  paths>

Specifies a list of command paths.

=back

=cut

sub _do_add_restrict
{ my ($slf, $req) = @_;
  my ($cnt, $def, $nam, %cmd);

  # Treat the request
  $cnt = 0;
  $def = $slf->{'_def'};
  eval {
    # Determine the property name
    $nam = $req->get_first('family');
    $nam = (defined($nam) && exists($tb_fam{$nam = lc($nam)}))
      ? $tb_fam{$nam}
      : $tb_fam{lc($slf->{'_cfg'}->get_family)};

    # Add the new commands
    %cmd = map {$_ => 0} $def->get_value($nam);
    foreach my $pth ($req->get_value('paths'))
    { next if exists($cmd{$pth}) || !RDA::Object::Rda->is_path($pth);
      $cmd{$pth} = 1;
      ++$cnt;
    }

    # Run the module setup and save the context definition
    if ($cnt)
    { $def->set_temp($nam, [sort keys(%cmd)]);
      _setup($slf, 1);
      $slf->{'_agt'}->get_system->reset_restrictions;
    }
    };

  # Indicate the completion status
  return $req->reply($@, 'AddRestriction');
}

=head2 FILTER.ADD_SET - Add set command

This command adds rule sets at the end of the rule set lists. It removes any
previous occurrences and preserves definitions of existing rule sets. It
supports the following attribute:

=over 8

=item B<  args>

Specifies a list of name-description pairs.

=back

=cut

sub _do_add_set
{ my ($slf, $req) = @_;
  my ($dsc, $flt, $nam, $set, @arg, @tbl);

  # Treat the request
  $flt = $slf->{'_flt'};
  eval {
    # Add the new rule sets
    @arg = $req->get_value('args');
    @tbl = $flt->get_value('W_SETS');
    while (($nam, $dsc) = splice(@arg, 0, 2))
    { next unless $nam =~ $RE_NAM;
      @tbl = ((grep {$_ ne $nam} @tbl), $nam);
      $set = $flt->find($nam, 1);
      $set->set_temp('T_DESC',   $dsc || $set->get_first('T_DESC', $nam));
      $set->set_temp('T_STRING', '%R:'.$nam.q{%})
        unless defined($set->get_first('T_STRING'));
    }
    $flt->set_temp('W_SETS', [@tbl]);

    # Run the module setup and save the context definition
    _setup($slf, 1);
    };

  # Indicate the completion status
  return $req->reply($@, 'AddSet');
}

=head2 FILTER.ADD_TAG - Add tag command

This command associates a new customer file management level to the specified
tags. It supports the following attributes:

=over 8

=item B<  cfm>

Specifies the customer file manager level (C<3> by default).

=item B<  tags>

Specifies a list of tags.

=back

=cut

sub _do_add_tag
{ my ($slf, $req) = @_;
  my ($cfm, $cnt, $hsh, $out);

  # Treat the request
  $cnt = 0;
  $out = $slf->{'_out'};
  eval {
    # Determine the customer file management level
    $cfm = _get_cfm($req, 3);

    # Add the new tag levels
    $hsh = $out->get_hash('N_TAG');
    foreach my $tag ($req->get_value('tags'))
    { next unless $tag =~ m/^\w+$/;
      $hsh->{$tag} = $cfm;
      ++$cnt;
    }
    $out->set_temp('N_TAG', $hsh);

    # Run the module setup and save the context definition
    _setup($slf, 1) if $cnt;
    };

  # Indicate the completion status
  return $req->reply($@, 'AddTag');
}

=head2 FILTER.CLEAR - Clear command

This command disables the filter and clears the filter definition. It supports
the following attribute:

=over 9

=item B<  force>

It performs this operation only when this attribute is set (false by default).

=back

=cut

sub _do_clear
{ my ($slf, $req) = @_;

  # Do not execute it unless in force mode
  return $req->error('NoForce') unless $req->get_first('force');

  # Treat the request
  eval {
    # Disable the filter
    $slf->{'_flt'}->set_temp('B_ENABLED', 0);

    # Run the module setup to delete the filter definition
    _setup($slf, 0);
    };

  # Indicate the completion status
  return $req->reply($@, 'Clear');
}

=head2 FILTER.DEFINE - Define command

This command defines the specified rule set. It supports the following
attributes:

=over 11

=item B<  format>

When present, specifies the substitution format.

=item B<  name>

Specifies the rule set name.

=item B<  options>

When present, specifies the matching options.

=item B<  string>

When present, specifies the substitution string.

=back

=cut

sub _do_define
{ my ($slf, $req) = @_;
  my ($cnt, $nam, $set, $val);

  # Validate the request
  $nam = $req->get_first('name', q{});
     $nam =~ $RE_NAM && ($set = $slf->{'_flt'}->find($nam));
  return $req->error('BadSet')
    unless $nam =~ $RE_NAM && ($set = $slf->{'_flt'}->find($nam));

  # Treat the request
  eval {
    # Treat the change
    $cnt = 0;
    foreach my $key (keys(%tb_def))
    { next unless defined($val = $req->get_first($key));
      $set->set_temp($tb_def{$key}, $val);
      ++$cnt;
    }

    # Run the module setup and save the context definition
    _setup($slf) if $cnt;
    };

  # Indicate the completion status
  return $req->reply($@, 'Define');
}

=head2 FILTER.DEL_FILE - Delete file command

This command deletes any customer file management level associated to the
specified files. It supports the following attribute:

=over 9

=item B<  paths>

Specifies a list of file paths.

=back

=cut

sub _do_del_file
{ my ($slf, $req) = @_;
  my ($cnt, $hsh, $out);

  # Treat the request
  $cnt = 0;
  $out = $slf->{'_out'};
  eval {
    # Delete the specified entries
    $hsh = $out->get_hash('N_FIL');
    foreach my $pth ($req->get_value('paths'))
    { ++$cnt if defined(delete($hsh->{RDA::Object::Rda->native($pth,1)}));
    }
    $out->set_temp('N_FIL', $hsh);

    # Run the module setup and save the context definition
    _setup($slf, 1) if $cnt;
    };

  # Indicate the completion status
  return $req->reply($@, 'DeleteFile');
}

=head2 FILTER.DEL_FORMAT - Delete format command

This command deletes the specified user-defined substitution formats. It
supports the following attribute:

=over 8

=item B<  names>

Specifies the names of the formats to delete.

=back

=cut

sub _do_del_format
{ my ($slf, $req) = @_;
  my ($tbl);

  # Treat the request
  eval {
    # Delete the specified formats
    $tbl = $slf->{'_flt'}->get_hash('T_FORMATS');
    foreach my $fmt ($req->get_value('names'))
    { delete($tbl->{$fmt});
    }
    $slf->{'_flt'}->set_temp('T_FORMATS', $tbl);

    # Run the module setup and save the context definition
    _setup($slf);
    };

  # Indicate the completion status
  return $req->reply($@, 'DeleteFormat');
}

=head2 FILTER.DEL_META - Delete meta command

This command removes directory structures from the list of directories where
status file information can be collected. It supports the following attribute:

=over 9

=item B<  paths>

Specifies a list of directory paths.

=back

=cut

sub _do_del_meta
{ my ($slf, $req) = @_;
  my ($cnt, $hsh, $out);

  # Treat the request
  $cnt = 0;
  $out = $slf->{'_out'};
  eval {
    # Delete the specified entries
    $hsh = $out->get_hash('N_META');
    foreach my $pth ($req->get_value('paths'))
    { ++$cnt if defined(delete($hsh->{$pth}));
    }
    $out->set_temp('N_META', $hsh);

    # Run the module setup and save the context definition
    _setup($slf, 1) if $cnt;
    };

  # Indicate the completion status
  return $req->reply($@, 'DeleteMeta');
}

=head2 FILTER.DEL_MODULE - Delete module command

This command deletes any customer file management level associated to the
specified modules. It supports the following attribute:

=over 9

=item B<  names>

Specifies a list of module abbreviations.

=back

=cut

sub _do_del_module
{ my ($slf, $req) = @_;
  my ($cnt, $hsh, $key, $out);

  # Treat the request
  $cnt = 0;
  $out = $slf->{'_out'};
  eval {
    # Delete the specified entries
    foreach my $nam ($req->get_value('names'))
    { ++$cnt if $nam =~ m/^([A-Z][A-Z\d]*)[_\.]([A-Z][A-Z\d]*)_?$/
        && defined($out->set_temp("$1.$2.N_MOD"));
    }

    # Run the module setup and save the context definition
    _setup($slf, 1) if $cnt;
    };

  # Indicate the completion status
  return $req->reply($@, 'DeleteModule');
}

=head2 FILTER.DEL_PATTERN - Delete pattern command

This command deletes the specified patterns from the pattern list of the
specified rule set. Patterns are referenced by their offset in the list. It
supports the following attributes:

=over 11

=item B<  name>

Specifies the rule set name.

=item B<  offsets>

Specifies the offsets of the patterns to delete.

=back

=cut

sub _do_del_pattern
{ my ($slf, $req) = @_;
  my ($flt, $nam, $set, @tbl);

  # Validate the request
  $nam = $req->get_first('name', q{});
  return $req->error('BadSet')
    unless $nam =~ $RE_NAM && ($set = $slf->{'_flt'}->find($nam));

  # Treat the request
  $flt = $slf->{'_flt'};
  eval {
    @tbl = $set->get_value('T_PATTERNS');
    foreach my $off ($req->get_value('offsets'))
    { $tbl[$off] = undef if $off =~ m/^\d+$/ && $off > 0 && --$off <= $#tbl;
    }
    $set->set_temp('T_PATTERNS', [grep {defined($_)} @tbl]);

    # Run the module setup and save the context definition
    _setup($slf);
    };

  # Indicate the completion status
  return $req->reply($@, 'DeletePattern');
}

=head2 FILTER.DEL_REPORT - Delete report command

This command deletes any customer file management level associated to the
specified reports. It supports the following attribute:

=over 9

=item B<  names>

Specifies a list of report names.

=back

=cut

sub _do_del_report
{ my ($slf, $req) = @_;
  my ($cnt, $key, $out, @key, %hsh);

  # Treat the request
  $cnt = 0;
  $out = $slf->{'_out'};
  eval {
    # Delete the specified entries
    foreach my $nam ($req->get_value('names'))
    { next unless $nam =~ m/^([A-Z][A-Z\d]*)_([A-Z][A-Z\d]*)_(\w+)$/;
      $key = "$1.$2.N_RPT";
      $hsh{$key} = $out->get_hash($key) unless exists($hsh{$key});
      delete($hsh{$key}->{$3});
    }

    # Run the module setup and save the context definition
    if (@key = keys(%hsh))
    { foreach my $key (@key)
      { $out->set_temp($key, $hsh{$key});
      }
      _setup($slf, 1);
    }
    };

  # Indicate the completion status
  return $req->reply($@, 'DeleteReport');
}

=head2 FILTER.DEL_RESTRICT - Delete restriction command

This command removes the specified commands from the list of commands with
execution restrictions. It supports the following attributes:

=over 10

=item B<  family>

Specifies the related operating system family.

=item B<  paths>

Specifies a list of command paths.

=back

=cut

sub _do_del_restrict
{ my ($slf, $req) = @_;
  my ($cnt, $def, $nam, %cmd);

  # Treat the request
  $cnt = 0;
  $def = $slf->{'_def'};
  eval {
    # Determine the property name
    $nam = $req->get_first('family');
    $nam = (defined($nam) && exists($tb_fam{$nam = lc($nam)}))
      ? $tb_fam{$nam}
      : $tb_fam{lc($slf->{'_cfg'}->get_family)};

    # Delete the specified entries
    %cmd = map {$_ => 1} $def->get_value($nam);
    foreach my $pth ($req->get_value('paths'))
    { ++$cnt if delete($cmd{$pth});
    }

    # Run the module setup and save the context definition
    if ($cnt)
    { $def->set_temp($nam, [sort keys(%cmd)]);
      _setup($slf, 1);
      $slf->{'_agt'}->get_system->reset_restrictions;
    }
    };

  # Indicate the completion status
  return $req->reply($@, 'DelRestriction');
}

=head2 FILTER.DEL_SET - Delete set command

This command deletes the specified rule set. It supports the following
attribute:

=over 9

=item B<  names>

Specifies the names of the rule sets to delete.

=back

=cut

sub _do_del_set
{ my ($slf, $req) = @_;
  my (@tbl);

  # Treat the request
  eval {
    # Remove the specified sets
    @tbl = $slf->{'_flt'}->get_value('W_SETS');
    foreach my $set (@_)
    { @tbl = grep {$_ ne $set} $req->get_value('names');
    }
    $slf->{'_flt'}->set_temp('W_SETS', [@tbl]);

    # Run the module setup and save the context definition
    _setup($slf);
    };

  # Indicate the completion status
  return $req->reply($@, 'DeleteSet');
}

=head2 FILTER.DEL_TAG - Delete tag command

This command deletes any customer file management level associated to the
specified tags. It supports the following attribute:

=over 8

=item B<  tags>

Specifies a list of tags.

=back

=cut

sub _do_del_tag
{ my ($slf, $req) = @_;
  my ($cnt, $hsh, $out);

  # Treat the request
  $cnt = 0;
  $out = $slf->{'_out'};
  eval {
    # Delete the specified entries
    $hsh = $out->get_hash('N_TAG');
    foreach my $tag ($req->get_value('tags'))
    { ++$cnt if $tag =~ m/^\w+$/ && defined(delete($hsh->{$tag}));
    }
    $out->set_temp('N_TAG', $hsh);

    # Run the module setup and save the context definition
    _setup($slf, 1) if $cnt;
    };

  # Indicate the completion status
  return $req->reply($@, 'DeleteTag');
}

=head2 FILTER.DISABLE - Disable command

This command disables the filter. It generates the default filter configuration
if the module is not configured yet.

=cut

sub _do_disable
{ my ($slf, $req) = @_;

  # Treat the request
  eval {
    # Disable the filter
    $slf->{'_flt'}->set_temp('B_ENABLED', 0);

    # Run the module setup and save the context definition
    _setup($slf);
    };

  # Indicate the completion status
  return $req->reply($@, 'Disable');
}

=head2 FILTER.DSP_SET - Display set command

This command displays the definition of the specified rule sets. It supports
the following attribute:

=over 9

=item B<  names>

Specifies the names of the rule sets to display (all by default).

=back

=cut

sub _do_dsp_set
{ my ($slf, $req) = @_;
  my ($buf, $flt, $off, $sep, $set, @pat, @tbl);

  # Treat the request
  $buf = q{};
  $flt = $slf->{'_flt'};
  @tbl = $flt->get_value('W_SETS')
    unless (@tbl = $req->get_value('names'));
  foreach my $nam (@tbl)
  { next unless ($set = $flt->find($nam));
    $off = 0;
    $buf .= q{.N1}.$NL if $buf;
    $buf .= q{.M 2 '}.get_string('TtlSet', $nam,
      $set->get_first('T_DESC', q{})).q{'}.$NL;
    $buf .= get_string('SetFormat').q{|}
      .$set->get_first('W_FORMAT', q{})."\\040".$NL;
    $buf .= get_string('SetString').q{|}
      .$set->get_first('T_STRING', q{}).$NL;
    $buf .= get_string('SetOptions').q{|}
      .$set->get_first('W_OPTIONS', q{})."\\040".$NL;
    $sep = get_string('SetPatterns').q{|};
    foreach my $pat ($set->get_value('T_PATTERNS'))
    { $buf .= $sep.sprintf('%2d. %s', ++$off, $pat);
      $sep = '\012';  ## no critic (Interpolation)
    }
    $buf .= $sep.get_string('NoPatterns') unless $off;
    $buf .= $NL.$NL;
  }

  # Indicate the completion status
  return _display($slf, $req, 'OK.DisplaySet', $buf || get_string('NoSets'));
}

=head2 FILTER.ENABLE - Enable command

This command enables the filter. It generates the default filter configuration
if the module is not configured yet.

=cut

sub _do_enable
{ my ($slf, $req) = @_;

  # Treat the request
  eval {
    # Generate the default rules
    _set_default($slf, $req) unless $slf->{'_flt'}->is_defined('W_SETS');

    # Enable the filter
    $slf->{'_flt'}->set_temp('B_ENABLED', 1);

    # Run the module setup and save the context definition
    _setup($slf);
    };

  # Indicate the completion status
  return $req->reply($@, 'Enable');
}

=head2 FILTER.EXP_META - Expand meta command

This command replaces recursive directory specifications by equivalent
descriptions where the directory and all its subdirectories have their own
specifications (one level at the time). It supports the following attribute:

=over 12

=item B<  excludes>

Specifies the name of the subdirectories to exclude from the expansion
(none by default).

=item B<  paths>

Specifies the path of the directories to expand.

=back

=cut

sub _do_expand_meta
{ my ($slf, $req) = @_;
  my ($cnt, $hsh, $lvl, $out, $pth, %skp);

  # Treat the request
  $cnt = 0;
  $out = $slf->{'_out'};
  eval {
    # Add the new directory structures
    $hsh = $out->get_hash('N_META');
    %skp = map {$_ => 1} $req->get_value('excludes');
    foreach my $dir ($req->get_value('paths'))
    { next unless ($lvl = $hsh->{$dir}) && opendir(DIR, $dir);
      $hsh->{$dir} = 0;
      --$lvl ;
      foreach my $nam (readdir(DIR))
      { next if $nam =~ m/^\.+$/ || exists($skp{$nam});
        $hsh->{$pth} = $lvl
          if -d ($pth = RDA::Object::Rda->cat_file($dir, $nam))
          && !exists($hsh->{$pth});
      }
      closedir(DIR);
      ++$cnt;
    }
    $out->set_temp('N_META', $hsh);

    # Run the module setup and save the context definition
    _setup($slf, 1) if $cnt;
    };

  # Indicate the completion status
  return $req->reply($@, 'ExpandMeta');
}

=head2 FILTER.EXPORT - Export command

This command exports the filter definition.

=cut

sub _do_export  ## no critic (Complex)
{ my ($slf, $req) = @_;
  my ($buf, $def, $exe, $flt, $itm, $out, $rem, $sep, $set, $tbl, $val,
      @fmt, @rda);

  # Treat the request
  eval {
    $def = $slf->{'_def'};
    $flt = $slf->{'_flt'};
    $out = $slf->{'_out'};
    if (RDA::Object::Rda->is_windows)
    { $buf = q{@echo off}.$NL;  ## no critic (Interpolation)
      $exe = q{};
      $rem = 'REM ';
      $sep = q{};
    }
    elsif (RDA::Object::Rda->is_vms)
    { $buf = q{};
      $exe = q{$ };
      $rem = q{$! };  ## no critic (Interpolation)
      $sep = q{"};
    }
    else
    { $buf = q{#!/bin/sh}.$NL;
      $exe = q{};
      $rem = q{# };
      $sep = q{};
    }
    @rda = $slf->{'_cfg'}->get_value('T_SELF');

    # Clear any existing definition
    $buf .= $exe.join($SPC, @rda, "-XFilter clear $sep-f$sep").$NL;

    # Export the rule sets
    foreach my $nam ($flt->get_value('W_SETS'))
    { next unless ($set = $flt->find($nam));
      $buf .= $NL.$rem.get_string('Define', $nam).$NL;
      $buf .= $exe.join($SPC, @rda, '-XFilter add set', $nam,
        _exp_str($set->get_first('T_DESC'))).$NL;
      $buf .= $exe.join($SPC, @rda, '-XFilter set string', $nam,
        _exp_str($val)).$NL
        if defined($val = $set->get_first('T_STRING'));
      $buf .= $exe.join($SPC, @rda, '-XFilter set format', $nam,
        _exp_str($val)).$NL
        if defined($val = $set->get_first('T_FORMAT'));
      $buf .= $exe.join($SPC, @rda, '-XFilter set options', $nam,
        _exp_str($val)).$NL
        if defined($val = $set->get_first('W_OPTIONS'));
      foreach my $pat ($set->get_value('T_PATTERNS'))
      { $buf .= $exe.join($SPC, @rda, '-XFilter add pattern', $nam,
          _exp_str($pat)).$NL if $pat;
      }
    }

    # Export the limits
    $buf .= $NL.$rem.get_string('Limits').$NL;
    if (RDA::Object::Rda->is_unix)
    { $buf .= $exe.join($SPC, @rda, '-XFilter set gid', $val).$NL
        if defined($val = $flt->get_first('N_MINIMUM_GID'));
      $buf .= $exe.join($SPC, @rda, '-XFilter set uid', $val).$NL
        if defined($val = $flt->get_first('N_MINIMUM_UID'));
    }
    $buf .= $exe.join($SPC, @rda, '-XFilter set cfm', $val).$NL
      if defined($val = $out->get_first('N_CFM'));
    $buf .= $exe.join($SPC, @rda, '-XFilter set regroup', $val).$NL
      if defined($val = $flt->get_first('N_REGROUP'));

    # Export the user defined substitution formats
    if (@fmt = keys(%{$tbl = $flt->get_hash('T_FORMATS')}))
    { $buf .= $NL.$rem.get_string('Formats').$NL;
      foreach my $fmt (sort @fmt)
      { $buf .= $exe.join($SPC, @rda, '-XFilter add format', $fmt,
          _exp_str($tbl->{$fmt})).$NL if $fmt;
      }
    }

    # Export the execution restrictions
    if ($itm = $def->find('SYSTEM.RESTRICT'))
    { $buf .= $NL.$rem.get_string('Restrictions').$NL;
      foreach my $str ($itm->get_value('T_UNIX'))
      { $buf .= $exe.join($SPC, @rda, '-XFilter add unix restriction',
          _exp_str($str)).$NL;
      }
      foreach my $str ($itm->get_value('T_VMS'))
      { $buf .= $exe.join($SPC, @rda, '-XFilter add vms restriction',
          _exp_str($str)).$NL;
      }
      foreach my $str ($itm->get_value('T_WINDOWS'))
      { $buf .= $exe.join($SPC, @rda, '-XFilter add windows restriction',
          _exp_str($str)).$NL;
      }
    }

    # Export the customer file management configuration
    $buf .= $NL.$rem.get_string('Cfm').$NL;
    if (ref($tbl = $out->get_value('N_FIL')) eq 'HASH')
    { foreach my $key (keys(%{$tbl}))
      { $buf .= $exe.join($SPC, @rda, '-XFilter add file', $tbl->{$key},
          _exp_str($key)).$NL;
      }
    }
    if (ref($tbl = $out->get_value('N_TAG')) eq 'HASH')
    { foreach my $key (keys(%{$tbl}))
      { $buf .= $exe.join($SPC, @rda, '-XFilter add tag', $tbl->{$key},
          _exp_str($key)).$NL;
      }
    }
    foreach my $abr ($out->grep('^N_(MOD|RPT)$','or'))
    { $buf .= $exe.join($SPC, @rda, '-XFilter add module', $val, $abr).$NL
        if defined($val = $out->get_first("$abr.N_MOD"));
      if (ref($tbl = $out->get_value("$abr.N_RPT")) eq 'HASH')
      { $val = $abr.$UND;
        $val =~ s/\./_/g;
        foreach my $key (keys(%{$tbl}))
        { $buf .= $exe.join($SPC, @rda, '-XFilter add report', $tbl->{$key},
            _exp_str($val.$key)).$NL;
        }
      }
    }

    # Export the metadata directives
    if (ref($tbl = $out->get_value('N_META')) eq 'HASH')
    { $buf .= $NL.$rem.get_string('Meta').$NL;
      foreach my $key (keys(%{$tbl}))
      { $buf .= $exe.join($SPC, @rda, '-XFilter add meta', $tbl->{$key},
          _exp_str($key)).$NL;
      }
    }

    # Enable the filter when required
    $buf .= $NL.$rem.get_string('Enable').$NL
      .$exe.join($SPC, @rda, '-XFilter enable').$NL
      if $flt->get_first('B_ENABLED');

    # Display the script
    syswrite($slf->{'_agt'}->get_screen, $buf, length($buf));
    };

  # Indicate the completion status
  return $req->reply($@, 'Export');
}

sub _exp_str
{ my ($val) = @_;

  $val =~ s{([^\040-\041\050-\133\135-\176])}
           {sprintf('\0x%02X', ord($1))}eg;
  return q{"}.$val.q{"};
}

=head2 FILTER.GET_FILES - Get CFM files command.

This command lists the files with an user-defined customer file management
level. It supports the following attribute:

=over 13

=item B<  separator>

Specifies the string for separating the file from its level (C<\001> by
default).

=back

=cut

sub _do_get_files
{ my ($slf, $req) = @_;
  my ($lst, $sep, $tbl);

  # Treat the request
  eval {
    $sep = $req->get_first('separator', "\001");
    $tbl = $slf->{'_out'}->get_hash('N_FIL');
    $lst = [map {$tbl->{$_}.$sep.$_} sort keys(%{$tbl})];
    };

  # Indicate the completion status
  return $req->reply($@, 'GetCfmFiles', list => $lst);
}

=head2 FILTER.GET_FORMATS - Get format command

This command lists the defined substitution formats with their definition. It
supports the following attribute:

=over 13

=item B<  separator>

Specifies the string for separating the name from its definition (C<\001> by
default).

=back

=cut

sub _do_get_formats
{ my ($slf, $req) = @_;
  my ($dsc, $sep, $tbl, @ext, @int);

  # Treat the request
  $sep = $req->get_first('separator', "\001");
  foreach my $fmt (sort keys(%FLT_FORMATS))
  { push(@int, $fmt.$sep.$FLT_FORMATS{$fmt});
  }
  $tbl = $slf->{'_flt'}->get_hash('T_FORMATS');
  foreach my $fmt (sort keys(%{$tbl}))
  { push(@ext, $fmt.$sep.$dsc) if ($dsc = $tbl->{$fmt});
  }
  $slf->{'_flt'}->set_temp('T_FORMATS', $tbl);

  # Indicate the completion status
  return $req->new('OK.GetFormats', external => [@ext], internal => [@int]);
}

=head2 FILTER.GET_META - Meta list command

This command lists the paths of all directories where status file information
can be collected. It prefixes each directory path with the corresponding
recursion level. It supports the following attributes:

=over 13

=item B<  expanded>

When true, provides the expanded list of directories.

=item B<  separator>

Specifies the string for separating the directory path from the recursion level
(C<\001> by default).

=back

=cut

sub _do_get_meta
{ my ($slf, $req) = @_;
  my ($lst, $sep, $tbl);

  # Treat the request
  eval {
    $sep = $req->get_first('separator', "\001");
    if ($req->get_first('expanded'))
    { $lst = [map {q{0}.$sep.$_} sort $slf->{'_out'}->get_value('D_META')];
    }
    else
    { $tbl = $slf->{'_out'}->get_hash('N_META');
      $lst = [map {$tbl->{$_}.$sep.$_} sort keys(%{$tbl})];
    }
    };

  # Indicate the completion status
  return $req->new('OK.GetMeta', list => $lst);
}

=head2 FILTER.GET_MODULES - Module list command.

This command lists the modules with an user-defined customer file management
level. It supports the following attribute:

=over 13

=item B<  separator>

Specifies the string for separating the module from its level (C<\001> by
default).

=back

=cut

sub _do_get_modules
{ my ($slf, $req) = @_;
  my ($lst, $out, $sep, $tbl);

  # Treat the request
  eval {
    $out = $slf->{'_out'};
    $sep = $req->get_first('separator', "\001");
    $lst = [map {$out->get_value(qq{$_.N_MOD}).$sep.$_}
                $out->grep('N_MOD','or')];
    };

  # Indicate the completion status
  return $req->reply($@, 'GetCfmModules', list => $lst);
}

=head2 FILTER.GET_REPORTS - Report list command.

This command lists the reports with an user-defined customer file management
level. It supports the following attribute:

=over 13

=item B<  separator>

Specifies the string for separating the report from its level (C<\001> by
default).

=back

=cut

sub _do_get_reports
{ my ($slf, $req) = @_;
  my ($out, $sep, $tbl, @lst);

  # Treat the request
  eval {
    $out = $slf->{'_out'};
    $sep = $req->get_first('separator', "\001");
    foreach my $mod (sort $out->grep('N_RPT','or'))
    { $tbl = $out->get_hash(qq{$mod.N_RPT});
      $mod =~ s/\./_/g;
      push(@lst, map {$tbl->{$_}.$sep.$mod.q{_}.$_} sort keys(%{$tbl}));
    }
    };

  # Indicate the completion status
  return $req->reply($@, 'GetCfmReports', list => [@lst]);
}

=head2 FILTER.GET_RESTRICT - Execution restriction list command

This command lists the commands with execution restrictions per operating
system family. It supports the following attribute:

=over 13

=item B<  separator>

Specifies the string for separating the operating system family from the
command (C<\001> by default).

=back

=cut

sub _do_get_restrict
{ my ($slf, $req) = @_;
  my ($sep, @cmd);

  # Treat the request
  $sep = $req->get_first('separator', qq{\001});
  foreach my $fam (sort keys(%tb_fam))
  { foreach my $cmd ($slf->{'_def'}->get_value($tb_fam{$fam}))
    { push(@cmd, $fam.$sep.$cmd) if $cmd;
    }
  }

  # Indicate the completion status
  return $req->new('OK.GetRestrictions', list => [@cmd]);
}

=head2 FILTER.GET_SETS - Set list command

This command returns the description of the defined rule sets. It supports
the following attribute:

=over 13

=item B<  separator>

Specifies the string for separating the name from its description (C<\001> by
default).

=back

=cut

sub _do_get_sets
{ my ($slf, $req) = @_;
  my ($flt, $sep, @set);

  # Treat the request
  $flt = $slf->{'_flt'};
  $sep = $req->get_first('separator', qq{\001});
  foreach my $nam ($flt->get_value('W_SETS'))
  { push(@set, $nam.$sep.$flt->get_first(qq{$nam.T_DESC}, q{})) if $nam;
  }

  # Indicate the completion status
  return $req->new('OK.GetSets', sets => [@set]);
}

=head2 FILTER.GET_TAGS - Tag restriction list command.

This command lists the tags with an user-defined customer file management
level. It supports the following attribute:

=over 13

=item B<  separator>

Specifies the string for separating the tag from its level (C<\001> by
default).

=back

=cut

sub _do_get_tags
{ my ($slf, $req) = @_;
  my ($lst, $sep, $tbl);

  # Treat the request
  eval {
    $sep = $req->get_first('separator', "\001");
    $tbl = $slf->{'_out'}->get_hash('N_TAG');
    $lst = [map {$tbl->{$_}.$sep.$_} sort keys(%{$tbl})];
    };

  # Indicate the completion status
  return $req->reply($@, 'GetCfmTags', list => $lst);
}

=head2 FILTER.RESET - Reset command

This command resets the filter, restoring its default configuration. It
supports the following attribute:

=over 9

=item B<  force>

It performs this operation only when this attribute is set (false by default).

=back

=cut

sub _do_reset
{ my ($slf, $req) = @_;

  # Do not execute it unless in force mode
  return $req->error('NoForce') unless $req->get_first('force');

  # Treat the request
  eval {
    # Define the default rules
    _set_default($slf, $req);

    # Run the module setup and save the context definition
    _setup($slf);
    };

  # Indicate the completion status
  return $req->reply($@, 'Reset');
}

=head2 FILTER.SET - Set command

This command sets the limits. It supports the following attributes:

=over 11

=item B<  cfm>

Specifies the maximum customer file management level to include in the result
set. When no value is provided, it removes the limit.

=item B<  gid>

Specifies the minimum group identifier to consider for scrubbing groups for
UNIX. When no value is provided, it restores the default value.

=item B<  regroup>

Specifies the number of patterns that can be regrouped in a substitution
statement. When no value is provided, it restores the default value.

=item B<  uid>

Specifies the minimum user identifier to consider for scrubbing users for
UNIX. When no value is provided, it restores the default value.

=back

=cut

sub _do_set
{ my ($slf, $req) = @_;
  my ($cnt, $def, $flg, $val);

  # Treat the request
  $def = $slf->{'_def'};
  eval {
    # Set the limits
    $cnt = 0;
    $flg = RDA::Object::Rda->is_unix || RDA::Object::Rda->is_cygwin;
    foreach my $key (keys(%tb_set))
    { next unless defined($val = $req->get_first($key));
      if (length($val) && ($flg || $tb_set{$key}->[0]))
      { # Set the new value as temporary value when numeric
        $def->set_temp($tb_set{$key}->[1], $val)
          if $val =~ m/^\d+$/ && $val >= $tb_set{$key}->[2];
      }
      else
      { # Delete the value
        $def->set_temp($tb_set{$key}->[1]);
      }
      ++$cnt;
    }

    # Run the module setup and save the context definition
    _setup($slf, 1) if $cnt;
    };

  # Indicate the completion status
  return $req->reply($@, 'Set');
}

=head2 FILTER.TEST - Test command

This command tests the filter generation. It supports the following attribute:

=over 11

=item B<  display>

When set, it displays the rule code (false by default).

=back

=cut

sub _do_test
{ my ($slf, $req) = @_;
  my ($flt);

  # Generate the filter
  $flt = eval {RDA::Handle::Filter->new($slf->{'_flt'})};
  $req->add_error($@) if $@;

  # Indicate the completion status
  return
  $req->has_errors           ? $req->error('Test', {exit => 1}) :
  $req->get_first('display') ? _display($slf, $req, 'OK.Test', $flt->display) :
                               $req->new('OK.Test');
}

=head1 AUTOMATIC FILTERING COMMANDS

=head2 FILTER.DEFAULT - Default command

This command generates temporary properties containing the default filter
configuration. On successful completion, it returns the list of generated sets
in the C<sets> attribute.

=cut

sub _do_default
{ my ($slf, $req) = @_;

  # Generate the default rules
  eval {_set_default($slf, $req)};

  # Indicate the completion status
  return $req->reply($@, 'Default',
    sets => [$slf->{'_flt'}->get_value('W_SETS')]);
}

sub _set_default  ## no critic (Complex)
{ my ($slf, $req) = @_;
  my ($cfg, $def, $fil, $flt, $ifh, $out);

  $cfg = $slf->{'_cfg'};
  $def = $slf->{'_def'};
  $flt = $slf->{'_flt'};
  $out = $slf->{'_out'};
  if ((defined($fil = $cfg->get_env('RDA_FILTER')) &&
       -r ($fil = $cfg->cat_file($fil)))
    || -r ($fil = $cfg->get_file('D_RDA', $FILTER))
    || -r ($fil = $cfg->get_file('D_CWD', $FILTER))
    || -r ($fil = $FILTER))
  { $ifh = IO::File->new;
    if ($ifh->open("<$fil"))
    { my ($abr, $fmt, $key, $lvl, $tbl, $val, @set, %fmt, %set);

      while (<$ifh>)
      { next unless m/^\s*(\w+)='(.*)'/;
        $key = $1;
        $val = $2;
        $val =~ s/&#10;/\n/g;
        $val =~ s/&#34;/"/g;
        $val =~ s/&#39;/'/g;
        if ($key =~ s/^FILTER_//)
        { if ($key eq 'SETS')
          { %set = map {$_ => 1} (@set = split(/\#/, $val));
            $flt->set_temp('W_SETS', [@set]);
          }
          elsif ($key =~ m/^(\w+)_(DESC|FORMAT|OPTIONS|PATTERNS|STRING)$/)
          {
            $flt->set_temp(
              $1.q{.}.(($2 eq 'FORMAT' || $2 eq 'OPTIONS') ? 'W_' : 'T_').$2,
              ($2 eq 'PATTERNS') ? [split(/\#/, $val)] : $val)
              if exists($set{$1});
          }
          elsif ($key eq 'FORMATS')
          { %fmt = map {$_ => 1} split(/\#/, $val);
            $fmt = $flt->get_hash('T_FORMATS');
          }
          elsif ($key =~ m/^FORMAT_(\w+)$/)
          { $fmt->{$1} = $val if exists($fmt{$1});
          }
          elsif ($key =~ m/^MINIMUM_(GID|UID)$/)
          { $flt->set_temp("N_MINIMUM_$1", $val);
          }
        }
        elsif ($key =~ s/^SYSTEM_RESTRICT_//)
        { $def->set_temp("SYSTEM.RESTRICT.T_$key",
            [map {RDA::Object::decode($_)} split (/\#/, $val)])
            if $key =~ m/^(UNIX|VMS|WINDOWS)$/;  ## no critic (Fixed)
        }
        elsif ($key =~ s/^OUTPUT_REFINE_//)
        { if ($key =~ m/^META_(\d)$/)
          { $lvl = $1;
            $tbl = $out->get_hash($key = 'N_META');
            foreach my $nam (split (/\#/, $val))
            { $tbl->{RDA::Object::decode($nam)} = $lvl;
            }
            $out->set_temp($key, $tbl);
          }
          elsif ($key eq 'CFM')
          { $out->set_temp('N_CFM', $val) if $val =~ m/^\d$/;
          }
          elsif ($key =~ m/^FILES_(\d)$/)
          { $lvl = $1;
            $tbl = $out->get_hash($key = 'N_FIL');
            foreach my $nam (split (/\#/, $val))
            { $tbl->{RDA::Object::decode($nam)} = $lvl;
            }
            $out->set_temp($key, $tbl);
          }
          elsif ($key =~ m/^TAGS_(\d)$/)
          { $lvl = $1;
            $tbl = $out->get_hash($key = 'N_TAG');
            foreach my $nam (split (/\#/, $val))
            { $tbl->{RDA::Object::decode($nam)} = $lvl;
            }
            $out->set_temp($key, $tbl);
          }
          elsif ($key =~ m/^MODULE_([A-Z][A-Z\d]*)_([A-Z][A-Z\d]*)$/)
          { $abr = "$1.$2";
            $out->set_temp("$abr.N_MOD", $val) if $val =~ m/^\d$/;
          }
          elsif ($key =~ m/^REPORTS_([A-Z][A-Z\d]*)_([A-Z][A-Z\d]*)_(\d)$/)
          { $abr = "$1.$2";
            $lvl = $3;
            $tbl = $out->get_hash($key = "$abr.N_RPT");
            foreach my $nam (split (/\#/, $val))
            { $tbl->{RDA::Object::decode($nam)} = $lvl;
            }
            $out->set_temp($key, $tbl);
          }
        }
      }
      $flt->set_temp('T_FORMATS', $fmt) if $fmt;
      $flt->set_value('B_DEFINED', 1);
      $flt->set_value('B_ENABLED', 1);
      $ifh->close;
    }
  }
  else
  { my ($itm, @set);

    $itm = $slf->{'_col'}->get_definition;
    push(@set, _dft_config($flt, $cfg, $itm));
    push(@set, _dft_user($flt, $itm));
    push(@set, _dft_extra($flt, 'HOST', 'Additional host'));
    push(@set, _dft_group($flt));
    push(@set, _dft_mask($flt));
    push(@set, _dft_extra($flt, 'DOMAIN', 'Additional domain'));
    push(@set, _dft_ip($flt));
    push(@set, _dft_pwd($flt));
    $flt->set_temp('W_SETS', [@set]);
    $flt->set_temp('T_FORMATS', {});
    $flt->set_value('B_DEFINED', 1);
  }
  return;
}

# Define the default group rules
sub _dft_config
{ my ($flt, $cfg, $itm) = @_;
  my ($dft, $dim, $ifh, $val, @pat, @set, @tbl);

  $dft = {};

  # Treat the result set file information
  _dft_cfg_nam($dft, $cfg->get_node);
  _dft_cfg_dom($dft, $val) if ($val = $cfg->get_domain);
  foreach my $key ($itm->grep('_HOST(NAME)?S?$','r'))
  { foreach my $nam ($itm->get_value($key))
    { _dft_cfg_nam($dft, $nam);
    }
  }

  # Treat the configuration file
  if ($cfg->is_unix)
  { _dft_cfg_hst($dft, '/etc/hosts');
    $ifh = IO::File->new;
    if ($ifh->open('</etc/resolv.conf'))
    { while (<$ifh>)
      { next unless s/^(?:domain|search)\s+//;
        foreach my $nam (split(/\s+/, $_))
        { _dft_cfg_dom($dft, $nam);
        }
      }
      $ifh->close;
    }
  }
  elsif ($cfg->is_windows || $cfg->is_cygwin)
  { _dft_cfg_hst($dft, $cfg->cat_file($cfg->get_env('SYSTEMROOT'),
      'system32', 'drivers', 'etc', 'hosts'));
  }

  # Generate the settings
  if (@tbl = reverse sort keys(%{$dft->{'dom'}}))
  { @pat = ();
    foreach my $dom (@tbl)
    { $dim = $dft->{'dom'}->{$dom};
      ## no critic (Interpolation)
      push(@pat,
        sprintf('<<$1:$3>>([a-z\d][a-z\d\-]*\.){1,%d}%s', $dim - 1, $dom))
        unless $dim < 2;  ## no critic (Unless)
    }
    $flt->set_temp('DFT_HFDQ.T_DESC',     'Default domain qualified host');
    $flt->set_temp('DFT_HFDQ.T_PATTERNS', [@pat]);
    $flt->set_temp('DFT_HFDQ.T_STRING',   '%R:HOST%.%R:DOMAIN%');
    $flt->set_temp('DFT_HFDQ.W_FORMAT',   'DFT_HST');
    $flt->set_temp('DFT_HFDQ.W_OPTIONS',  'i');
    @pat = ();
    foreach my $dom (@tbl)
    { $dim = $dft->{'dom'}->{$dom} - 2;
      ## no critic (Interpolation)
      push(@pat, ($dim <= 0) ? $dom :
        sprintf('<<:$2>>([a-z\d][a-z\d\-]*\.){0,%d}%s', $dim, $dom));
    }
    $flt->set_temp('DFT_DOMAIN.T_DESC',     'Default domain');
    $flt->set_temp('DFT_DOMAIN.T_PATTERNS', [@pat]);
    $flt->set_temp('DFT_DOMAIN.T_STRING',   '%R:DOMAIN%');
    $flt->set_temp('DFT_DOMAIN.W_FORMAT',   'DFT_SYS');
    $flt->set_temp('DFT_DOMAIN.W_OPTIONS',  'i');
    @pat = ();
    foreach my $dom (@tbl)
    { $dim = $dft->{'dom'}->{$dom} - 2;
      $dom =~ s/\\\./,dc=/;
      ## no critic (Interpolation)
      push(@pat, ($dim <= 0) ? "dc=$dom" :
        sprintf('<<:$2>>(dc=[a-z\d][a-z\d\-]*\,){0,%d}dc=%s', $dim, $dom));
    }
    $flt->set_temp('DFT_DC.T_DESC',     'Default LDAP domain');
    $flt->set_temp('DFT_DC.T_PATTERNS', [@pat]);
    $flt->set_temp('DFT_DC.T_STRING',   '%R:DC%');
    $flt->set_temp('DFT_DC.W_FORMAT',   'DFT_SYS');
    $flt->set_temp('DFT_DC.W_OPTIONS',  'i');
    push(@set, 'DFT_HFDQ', 'DFT_DOMAIN', 'DFT_DC');
  }
  if (@tbl = reverse sort keys(%{$dft->{'hst'}}))
  { $flt->set_temp('DFT_HOST.T_DESC',     'Default host');
    $flt->set_temp('DFT_HOST.T_PATTERNS', [@tbl]);
    $flt->set_temp('DFT_HOST.T_STRING',   '%R:HOST%');
    $flt->set_temp('DFT_HOST.W_FORMAT',   'DFT_HST');
    $flt->set_temp('DFT_HOST.W_OPTIONS',  'i');
    push(@set, 'DFT_HOST');
  }
  return @set;
}

sub _dft_cfg_dom
{ my ($dft, $dom) = @_;
  my ($dim, @dom);

  $dim = (@dom = split(/\./, $dom));
  $dom = $dom[-2].q{\.}.$dom[-1] if $dim > 1;
  $dft->{'dom'}->{$dom} = $dim
    if !exists($dft->{'dom'}->{$dom}) || $dim > $dft->{'dom'}->{$dom};
  return;
}

sub _dft_cfg_hst
{ my ($dft, $fil) = @_;
  my ($ifh);

  $ifh = IO::File->new;
  if ($ifh->open("<$fil"))
  { while (<$ifh>)
    { s/#.*$//;
      next unless s/^\s*\d{1,3}(?:\.\d{1,3}){3}\s+//
        || s/^\s*\:(?:\:[A-F\d]{1,4}){1,6}\s+//
        || s/^\s*[A-F\d]{1,4}(?:\:[A-F\d]{1,4}){7}\s+//
        || s/^\s*(?:[A-F\d]{1,4}\:){1,5}(?:\:[A-F\d]{1,4}){1,5}\s+//
        || s/^\s*(?:[A-F\d]{1,4}\:){1,6}\:\s+//;
      s/[\n\r\s]+$//;
      foreach my $nam (split(/\s+/, $_))
      { _dft_cfg_nam($dft, $nam);
      }
    }
    $ifh->close;
  }
  return;
}

sub _dft_cfg_nam
{ my ($dft, $nam) = @_;
  my ($dom, $hst);

  ($hst, $dom) = split(/\./, $nam, 2);
  $dft->{'hst'}->{$hst} = 1;
  _dft_cfg_dom($dft, $dom) if $dom;
  return;
}

# Define the extra rules
sub _dft_extra
{ my ($flt, $set, $dsc) = @_;

  $flt->set_temp(qq{$set.T_DESC},     $dsc);
  $flt->set_temp(qq{$set.T_PATTERNS}, []);
  $flt->set_temp(qq{$set.T_STRING},   q{%R:}.$set.q{%});
  $flt->set_temp(qq{$set.W_FORMAT},   'DFT');
  $flt->set_temp(qq{$set.W_OPTIONS},   q{});
  return $set;
}

# Define the default group rules
sub _dft_group  ## no critic (Complex)
{ my ($flt) = @_;
  my ($gid, $ifh, $lim, $nam, @tbl, %tbl);

  if (RDA::Object::Rda->is_unix)
  { $ifh = IO::File->new;
    $lim = $flt->get_first('N_MINIMUM_GID', 101);
    if ($ifh->open('</etc/group'))
    { while (<$ifh>)
      { ($nam, undef, $gid) = split(/:/, $_, 4);
        next if $lim && defined($gid) && $gid =~ m/^\s*(\d+)\s*$/
          && $1 >= 0 && $1 < $lim;
        $nam =~ s/^[\+\-]\@?//;
        ## no critic (Fixed)
        $tbl{$nam} = 1 unless $nam =~ m/^(?:dba|oinstall|oper|oracle|)$/;
      }
      $ifh->close;
    }
  }
  elsif (RDA::Object::Rda->is_windows || RDA::Object::Rda->is_cygwin)
  { my $flg;
    if (open(DFT, 'net localgroup |'))  ## no critic (Handle,Open)
    { while (<DFT>)
      { s/[\n\r\s]+$//;
        if (m/^\-+$/)
        { $flg = 1;
        }
        elsif (m/completed successfully/)
        { last;
        }
        elsif ($flg && s/^\*//)
        { foreach my $nam (split(/\s+\*/, $_))
          { $nam =~ s/\$.*$//;
            ## no critic (Fixed)
            $tbl{$nam} = 1
              if $nam
              && $nam !~ m/^(?:dba|oinstall|oper|ora_dba|oracle|support)$/i;
          }
        }
      }
      close(DFT);
    }
  }
  return () unless (@tbl = keys(%tbl));

  $flt->set_temp('GROUP.T_DESC',     'Group');
  $flt->set_temp('GROUP.T_PATTERNS', [reverse sort @tbl]);
  $flt->set_temp('GROUP.T_STRING',   '%R:GROUP%');
  $flt->set_temp('GROUP.W_FORMAT',   'DFT');
  $flt->set_temp('GROUP.W_OPTIONS',  q{});
  return 'GROUP';
}

# Define the default IP addresses rules
sub _dft_ip
{ my ($flt) = @_;

  $flt->set_temp('IP4.T_DESC',     'IPv4 addresses');
  $flt->set_temp('IP4.T_PATTERNS', [@tb_ip4]);  ## no critic (Numbered)
  $flt->set_temp('IP4.T_STRING',   '%R:IP4%');
  $flt->set_temp('IP4.W_FORMAT',   'DFT_IP4');
  $flt->set_temp('IP4.W_OPTIONS',  q{});

  $flt->set_temp('IP6.T_DESC',     'IPv6 addresses');
  $flt->set_temp('IP6.T_PATTERNS', [@tb_ip6]);  ## no critic (Numbered)
  $flt->set_temp('IP6.T_STRING',   '%R:IP6%');
  $flt->set_temp('IP6.W_FORMAT',   'DFT_IP6');
  $flt->set_temp('IP6.W_OPTIONS',  q{});
  return ('IP4', 'IP6');
}

# Define the default network mask rules
sub _dft_mask
{ my ($flt) = @_;

  $flt->set_temp('MASK.T_DESC',     'Network mask');
  $flt->set_temp('MASK.T_PATTERNS', [@tb_msk]);
  $flt->set_temp('MASK.T_STRING',   '%R:MASK%');
  $flt->set_temp('MASK.W_FORMAT',   'DFT_IP4');
  $flt->set_temp('MASK.W_OPTIONS',  q{});
  return 'MASK';
}

# Define the default password rules
sub _dft_pwd
{ my ($flt) = @_;

  $flt->set_temp('PWD.T_DESC',     'Passwords');
  $flt->set_temp('PWD.T_PATTERNS', ['password']);
  $flt->set_temp('PWD.T_STRING',   '%R:PASSWORD%');
  $flt->set_temp('PWD.W_FORMAT',   'DFT_ATT');
  $flt->set_temp('PWD.W_OPTIONS',  'i');
  return 'PWD';
}

# Define the default user rules
sub _dft_user  ## no critic (Complex)
{ my ($flt, $itm) = @_;
  my ($nam, @tbl, %tbl);

  # Treat the result set file information
  foreach my $key ($itm->grep('_USER(NAME)?S?$','r'))
  { foreach my $nam ($itm->get_value($key))
    { $tbl{$1} = 0 if $nam =~ m/^([^\/\@]+)/ && $1 ne 'oracle';
    }
  }

  # Treat the configuration file
  if (RDA::Object::Rda->is_unix)
  { my ($ifh, $lim, $uid);

    $ifh = IO::File->new;
    $lim = $flt->get_first('N_MINIMUM_UID', 101);
    if ($ifh->open('</etc/passwd'))
    { while (<$ifh>)
      { ($nam, undef, $uid) = split(/:/, $_, 4);
        next if $lim && defined($uid) && $uid =~ m/^\s*(\d+)\s*$/
          && $1 >= 0 && $1 < $lim;
        $nam =~ s/^[\+\-]\@?//;
        $tbl{$nam} = 1
          unless $nam =~ m/^(oracle|)$/;  ## no critic (Fixed)
      }
      $ifh->close;
    }
  }
  elsif (RDA::Object::Rda->is_windows || RDA::Object::Rda->is_cygwin)
  { my $flg;
    if (open(DFT, 'net user |'))  ## no critic (Handle,Open)
    { while (<DFT>)
      { s/[\n\r\s]+$//;
        if (m/^\-+$/)
        { $flg = 1;
        }
        elsif (m/completed successfully/)
        { last;
        }
        elsif ($flg)
        { foreach my $nam (split(/\s+/, $_))
          { $tbl{$nam} = 1
              unless $nam =~ m/^(oracle|support)$/i;  ## no critic (Fixed)
          }
        }
      }
      close(DFT);
    }
  }
  return () unless (@tbl = keys(%tbl));

  # Generate the settings
  $flt->set_temp('USER.T_DESC',     'User');
  $flt->set_temp('USER.T_PATTERNS', [reverse sort @tbl]);
  $flt->set_temp('USER.T_STRING',   '%R:USER%');
  $flt->set_temp('USER.W_OPTIONS',  q{});
  return 'USER';
}

=head2 FILTER.REMOVE - Remove command

This command removes the saved filter definition from the work directory.

=cut

sub _do_remove
{ my ($slf, $req) = @_;
  my ($fil);

  # Treat the options

  $fil = $slf->{'_cfg'}->get_file('D_CWD', $FILTER);
  1 while unlink($fil);

  # Indicate the completion status
  return $req->reply($@, 'Remove');
}

=head2 FILTER.SAVE - Save command

This command saves the definition of an active filter in the work directory. It
does not perform the operation unless the filter is enabled. The format is
compatible with earlier RDA versions.

=cut

sub _do_save  ## no critic (Complex)
{ my ($slf, $req) = @_;
  my ($def, $flt, $fil, $ofh, $out, $set, $tbl, $val, @pat, @tbl);

  # Check if the filter is enabled
  $def = $slf->{'_def'};
  $flt = $slf->{'_flt'};
  $out = $slf->{'_out'};
  die get_string('NOT_ENABLED')
    unless $flt->get_first('B_ENABLED') && $flt->get_first('B_DEFINED');

  # Create a .filter file, abort if not able to create
  $fil = $slf->{'_cfg'}->get_file('D_CWD', $FILTER);
  $ofh = IO::File->new;
  $ofh->open($fil, $CREATE, $FIL_PERMS)
    or die get_string('ERR_SAVE', $fil, $!);

  # Save the rule sets
  if (@tbl = $flt->get_value('W_SETS'))
  { print {$ofh} q{FILTER_SETS=}._sav_str(join(q{#}, @tbl)).$NL;
    foreach my $nam (@tbl)
    { next unless ($set = $flt->find($nam));
      print {$ofh} qq{FILTER_${nam}_DESC=}
        ._sav_str($set->get_first('T_DESC')).$NL;
      print {$ofh} qq{FILTER_${nam}_STRING=}._sav_str($val).$NL
        if defined($val = $set->get_first('T_STRING'));
      print {$ofh} qq{FILTER_${nam}_PATTERNS=}._sav_str(join(q{#}, @pat)).$NL
        if (@pat = $set->get_value('T_PATTERNS'));
      print {$ofh} qq{FILTER_${nam}_FORMAT=}._sav_str($val).$NL
        if defined($val = $set->get_first('W_FORMAT'));
      print {$ofh} qq{FILTER_${nam}_OPTIONS=}._sav_str($val).$NL
        if defined($val = $set->get_first('W_OPTIONS'));
    }
  }

  # Save the limits
  print {$ofh} qq{FILTER_MINIMUM_GID='$val'}.$NL
    if defined($val = $flt->get_first('N_MINIMUM_GID'));
  print {$ofh} qq{FILTER_MINIMUM_UID='$val'}.$NL
    if defined($val = $flt->get_first('N_MINIMUM_UID'));
  print {$ofh} qq{FILTER_REGROUP='$val'}.$NL
    if defined($val = $flt->get_first('N_REGROUP'));

  # Save the user defined substitution formats
  $tbl = $flt->get_hash('T_FORMATS');
  if (@tbl = keys(%{$tbl}))
  { print {$ofh} q{FILTER_FORMATS=}._sav_str(join(q{#}, @tbl)).$NL;

    foreach my $fmt (@tbl)
    { print {$ofh} qq{FILTER_FORMAT_$fmt=}._sav_str($tbl->{$fmt}).$NL if $fmt;
    }
  }

  # Save the execution restrictions
  if ($set = $def->find('SYSTEM.RESTRICT'))
  { print {$ofh} 'SYSTEM_RESTRICT_UNIX='._sav_arr(@tbl).$NL
      if (@tbl = $set->get_value('T_UNIX'));
    print {$ofh} 'SYSTEM_RESTRICT_VMS='._sav_arr(@tbl).$NL
      if (@tbl = $set->get_value('T_VMS'));
    print {$ofh} 'SYSTEM_RESTRICT_WINDOWS='._sav_arr(@tbl).$NL
      if (@tbl = $set->get_value('T_WINDOWS'));
  }

  # Save the customer file management configuration
  print {$ofh} qq{OUTPUT_REFINE_CFM='$val'}.$NL
    if defined($val = $out->get_first('N_CFM'));
  _sav_hsh($ofh, q{OUTPUT_REFINE_FILES_}, $tbl)
    if ref($tbl = $out->get_value('N_FIL')) eq 'HASH';
  _sav_hsh($ofh, q{OUTPUT_REFINE_TAGS_}, $tbl)
    if ref($tbl = $out->get_value('N_TAG')) eq 'HASH';
  foreach my $abr ($out->grep('^N_(MOD|RPT)$','or'))
  { $set = $abr;
    $set =~ s/\./_/g;
    print {$ofh} qq{OUTPUT_REFINE_MODULE_$set='$val'}.$NL
      if defined($val = $out->get_first("$abr.N_MOD"));
    _sav_hsh($ofh, q{OUTPUT_REFINE_REPORTS_}.$set.$UND, $tbl)
      if ref($tbl = $out->get_value("$abr.N_RPT")) eq 'HASH';
  }

  # Save the metadata directives
  _sav_hsh($ofh, q{OUTPUT_REFINE_META_}, $tbl)
    if ref($tbl = $out->get_value('N_META')) eq 'HASH';

  # Close the file
  $ofh->close;

  # Indicate the completion status
  return $req->reply($@, 'Save');
}

sub _sav_arr
{ return q{'}.join(q{#}, map {_sav_itm($_)} @_).q{'};
}

sub _sav_hsh
{ my ($ofh, $pre, $tbl) = @_;
  my (%tbl);

  foreach my $key (keys(%{$tbl}))
  { push(@{$tbl{$tbl->{$key}}}, _sav_itm($key));
  }
  foreach my $key (keys(%tbl))
  { print {$ofh} $pre.$key.q{='}.join(q{#}, @{$tbl{$key}}).q{'}.$NL;
  }
  return;
}

sub _sav_itm
{ my ($val) = @_;

  $val =~ s{([^\040-\042\044-\133\135-\173\175-\176])}
           {sprintf('\0x%02X', ord($1))}eg;
  return $val;
}

sub _sav_str
{ my ($str) = @_;

  $str =~ s/\n/&#10;/g;
  $str =~ s/\"/&#34;/g;
  $str =~ s/\'/&#39;/g;
  return "'$str'";
}

# --- Internal routines -------------------------------------------------------

# Display the result
sub _display
{ my ($slf, $req, $sta, $buf) = @_;
  my ($err, $msg);

  $msg = RDA::Object::Message->new('DISPLAY.DSP_REPORT',
    page => 1)->add_data($buf);
  return ($err = $slf->{'_agt'}->submit(q{.}, $msg)->is_error($req))
    ? $req->error($err)
    : $req->new($sta);
}

# Get the CFM level
sub _get_cfm
{ my ($req, $dft) = @_;
  my ($cfm);

  $cfm = $req->get_first('cfm');
  return (defined($cfm) && $cfm =~ m/^\d$/) ? $cfm : $dft;
}

# Set up the filter
sub _setup
{ my ($slf, $flg) = @_;
  my ($obj);

  $slf->{'_flt'}->set_temp('B_DEFINED', $flg) if defined($flg);
  $obj = $slf->{'_lng'}->load_package('RDA:DCfilter')
    or die get_string('NO_PACKAGE');
  $obj->isolate;
  $obj->setup(1);
  $slf->{'_col'}->save;
  return;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Handle::Filter|RDA::Handle::Filter>,
L<RDA::Object|RDA::Object>,
L<RDA::Object::Collect|RDA::Object::Collect>,
L<RDA::Object::Item|RDA::Object::Item>,
L<RDA::Object::Message|RDA::Object::Message>,
L<RDA::Object::Rda|RDA::Object::Rda>,
L<RDA::Options|RDA::Options>,
L<RDA::Request::DISPLAY|RDA::Request::DISPLAY>,
L<RDA::SDSL::Language|RDA::SDSL::Language>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
