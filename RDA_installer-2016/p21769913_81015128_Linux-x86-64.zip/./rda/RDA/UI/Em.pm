# Em.pm: Enterprise Manager Command Package

package RDA::UI::Em;

# $Id: Em.pm,v 1.4 2015/10/23 22:16:46 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/UI/Em.pm,v 1.4 2015/10/23 22:16:46 RDA Exp $
#
# Change History
# 20151023  MSC  Add error messages.

=head1 NAME

RDA::UI::Em - Enterprise Manager Command Package

=head1 SYNOPSIS

 <rda> <options> -XEm <command> <switches> <arg> ...

 <sdci> <options> -XEm <command> <switches> <arg> ...

=head1 DESCRIPTION

This user interface interacts with Enterprise Manager tools.

The following commands are available:

=for stopwords agtvfy omsvfy repvfy

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::Text qw(get_string);
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.4 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(Exporter);

# Define the global private constants
my $GRP = 'EM';
my $MOD = 'EM:TLem';

# Define the global private variables
#   Text:NO_KIT
#   Text:NO_COMMAND
#   Text:BAD_COMMAND
#   Text:BAD_PERMS

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<agtvfy [-a dir] [-k dir] [-o|-r nam] ...>

This command tries to locate the Enterprise Manager diagnostic kit and to
execute the specified F<agtvfy> command. It supports additional command
switches:

=over 10

=item B<  -a dir>

Specifies the agent Oracle home directory.

=item B<  -k dir>

Specifies the EMDIAG kit home directory.

=item B<  -o>

Displays the command results.

=item B<  -r nam>

Stores the command results in the specified report.

=back

=cut

sub agtvfy
{ my ($agt, @arg) = @_;
  my ($nam, $ret, $rsp, @err);

  # Execute the request
  $rsp = $agt->submit(q{.}, 'RDA.RUN',
    args      => [@arg],
    groups    => $GRP,
    tool      => $MOD,
    sections  => 'agtvfy');

  # Add the error
  $agt->add_error(get_string(@err))
    if (@err = $rsp->get_value('error'));

  # Display requested note
  $agt->submit(q{.}, 'DISPLAY.DSP_TEXT',
    name      => "em-$nam",
    set_docid => 1374441.1,
    set_tool  => 'Agtvfy') if defined($nam = $rsp->get_first('display'));

  # Indicate the completion status
  return defined($ret = $rsp->get_first('exit_only')) ? $ret : $rsp;
}

=head2 S<help>

This command displays the command syntax and the related explanations.

=cut

sub help
{ return shift->submit(q{.}, 'DISPLAY.DSP_POD', package => __PACKAGE__);
}

=head2 S<omsvfy [-g dir] [-k dir] [-o|-r nam] ...>

This command tries to locate the Enterprise Manager diagnostic kit and to
execute the specified F<repvfy> command. It supports additional command
switches:

=over 10

=item B<  -g dir>

Specifies the Enterprise Manager grid Oracle home directory.

=item B<  -k dir>

Specifies the EMDIAG kit home directory.

=item B<  -o>

Displays the command results.

=item B<  -r nam>

Stores the command results in the specified report.

=back

=cut

sub omsvfy
{ my ($agt, @arg) = @_;
  my ($nam, $ret, $rsp, @err);

  # Execute the request
  $rsp = $agt->submit(q{.}, 'RDA.RUN',
    args      => [@arg],
    groups    => $GRP,
    tool      => $MOD,
    sections  => 'omsvfy');

  # Add the error
  $agt->add_error(get_string(@err))
    if (@err = $rsp->get_value('error'));

  # Display requested note
  $agt->submit(q{.}, 'DISPLAY.DSP_TEXT',
    name      => "em-$nam",
    set_docid => 1374450.1,
    set_tool  => 'Omsvfy') if defined($nam = $rsp->get_first('display'));

  # Indicate the completion status
  return defined($ret = $rsp->get_first('exit_only')) ? $ret : $rsp;
}

=head2 S<repvfy [-k dir] [-o|-r nam] ...>

This command tries to locate the Enterprise Manager diagnostic kit and to
execute the specified F<repvfy> command. It supports additional command
switches:

=over 10

=item B<  -k dir>

Specifies the EMDIAG kit home directory.

=item B<  -o>

Displays the command results.

=item B<  -r nam>

Stores the command results in the specified report.

=back

=cut

sub repvfy
{ my ($agt, @arg) = @_;
  my ($nam, $ret, $rsp, @err);

  # Execute the request
  $rsp = $agt->submit(q{.}, 'RDA.RUN',
    args      => [@arg],
    groups    => $GRP,
    tool      => $MOD,
    sections  => 'repvfy');

  # Add the error
  $agt->add_error(get_string(@err))
    if (@err = $rsp->get_value('error'));

  # Display requested note
  $agt->submit(q{.}, 'DISPLAY.DSP_TEXT',
    name     => "em-$nam",
    set_docid => 1426973.1,
    set_tool => 'Repvfy') if defined($nam = $rsp->get_first('display'));

  # Indicate the completion status
  return defined($ret = $rsp->get_first('exit_only')) ? $ret : $rsp;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Object::Message|RDA::Object::Message>,
L<RDA::Options|RDA::Options>,
L<RDA::Request::DISPLAY|RDA::Request::DISPLAY>,
L<RDA::Request::RDA|RDA::Request::RDA>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
