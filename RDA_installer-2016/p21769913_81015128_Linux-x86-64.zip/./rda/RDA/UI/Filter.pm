# Filter.pm: Filter Command Package

package RDA::UI::Filter;

# $Id: Filter.pm,v 1.17 2015/05/08 18:17:03 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/UI/Filter.pm,v 1.17 2015/05/08 18:17:03 RDA Exp $
#
# Change History
# 20150508  MSC  Improve the documentation.

=head1 NAME

RDA::UI::Filter - Filter Command Package

=head1 SYNOPSIS

 <rda> <options> -XFilter <command> <switches> <arg> ...

 <sdci> <options> -XFilter <command> <switches> <arg> ...

=head1 DESCRIPTION

This package regroups additional commands to control how to filter sensitive
information from the generated reports.

The following commands are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::Text qw(get_string);
  use RDA::Agent;
  use RDA::Object;
  use RDA::Object::Message;
  use RDA::Options;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.17 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(Exporter);

# Define the global private constants

# Define the global private variables
my %tb_cmd = (
  clear   => [q{force},   q{f}],
  default => [q{},        q{} ],
  disable => [q{},        q{} ],
  enable  => [q{},        q{} ],
  export  => [q{},        q{} ],
  remove  => [q{},        q{} ],
  reset   => [q{force},   q{f}],
  save    => [q{},        q{} ],
  test    => [q{display}, q{d}],
  );
my %tb_fam = map {$_ => 1} qw(unix vms windows);
my %tb_cfm = (
  files   => [q{FILTER.GET_FILES},
              'NoCfmFil', 'TtlCfmFil'],  # Text:NoCfmFil Text:TtlCfmFil
  modules => [q{FILTER.GET_MODULES},
              'NoCfmMod', 'TtlCfmMod'],  # Text:NoCfmMod Text:TtlCfmMod
  reports => [q{FILTER.GET_REPORTS},
              'NoCfmRpt', 'TtlCfmRpt'],  # Text:NoCfmRpt Text:TtlCfmRpt
  tags    => [q{FILTER.GET_TAGS},
              'NoCfmTag', 'TtlCfmTag'],  # Text:NoCfmTag Text:TtlCfmTag
  );
my %tb_set = (
  cfm     => 1,
  format  => 0,
  gid     => 1,
  options => 0,
  regroup => 1,
  string  => 0,
  uid     => 1,
  );

# Report the package version
sub Version
{ return $VERSION;
}

# Execute a simple command
sub exec  ## no critic (Builtin)
{ my ($agt, $cmd, @arg) = @_;
  my ($atr, $key, $opt);

  # Validate the command
  die get_string('BAD_COMMAND', $cmd) unless exists($tb_cmd{$cmd});
  ($atr, $key) = @{$tb_cmd{$cmd}};

  # Treat the options
  $opt = RDA::Options::getopts($key, \@arg);

  # Treat the request
  return $agt->submit(q{.}, 'FILTER.'.uc($cmd || q{}), $atr => $opt->{$key});
}

=head1 FILTER MANAGEMENT COMMANDS

=head2 S<add file [[cfm] path...]>

This command associates a new customer file management level to the specified
files.

=head2 S<add format [name format]...>

This command defines additional substitution formats. A format name must start
with an uppercase letter, followed by uppercase letters or underscores.

=head2 S<add meta [[level] path...]>

This command adds a new directory structure to the list of directories where
status file information can be collected.

=head2 S<add module [[cfm] name...]>

This command associates a new customer file management level to the specified
modules.

=head2 S<add pattern [name [re...]]>

This command adds more patterns in the pattern list of the specified rule set.

=head2 S<add report [[cfm] name...]>

This command associates a new customer file management level to the specified
reports.

=head2 S<add [unix|vms|windows] restriction [path...]>

This command adds the specified commands to the list of commands with execution
restrictions.

=for stopwords desc

=head2 S<add set [name desc]...>

This command adds rule sets at the end of the rule set lists. It removes any
previous occurrences and preserves definitions of existing rule sets.

=head2 S<add tag [[cfm] name...]>

This command associates a new customer file management level to the specified
tags.

=cut

sub add
{ my ($agt, @arg) = @_;
  my ($fam, $lvl, $nam, $typ);

  # Treat the options
  RDA::Options::getopts(q{}, \@arg);

  # Treat the request
  $typ = lc(shift(@arg) || q{});
  if (exists($tb_fam{$typ}))
  { $fam = $typ;
    $typ = lc(shift(@arg) || q{});
  }
  if ($typ eq 'file')
  { $lvl = _get_cfm(\@arg);
    return $agt->submit(q{.}, 'FILTER.ADD_FILE',
      cfm   => $lvl,
      paths => [map {RDA::Object::decode($_)} @arg]);
  }
  if ($typ eq 'format')
  { return $agt->submit(q{.}, 'FILTER.ADD_FORMAT',
      args => [map {RDA::Object::decode($_)} @arg]);
  }
  if ($typ eq 'meta')
  { $lvl = _get_level(\@arg);
    return $agt->submit(q{.}, 'FILTER.ADD_META',
      level => $lvl,
      paths => [map {RDA::Object::decode($_)} @arg]);
  }
  if ($typ eq 'module')
  { $lvl = _get_cfm(\@arg);
    return $agt->submit(q{.}, 'FILTER.ADD_MODULE',
      cfm   => $lvl,
      names => [map {RDA::Object::decode($_)} @arg]);
  }
  if ($typ eq 'pattern')
  { $nam = shift(@arg);
    return $agt->submit(q{.}, 'FILTER.ADD_PATTERN',
      args => [map {RDA::Object::decode($_)} @arg],
      name => $nam);
  }
  if ($typ eq 'report')
  { $lvl = _get_cfm(\@arg);
    return $agt->submit(q{.}, 'FILTER.ADD_REPORT',
      cfm   => $lvl,
      names => [map {RDA::Object::decode($_)} @arg]);
  }
  if ($typ eq 'restrict' || $typ eq 'restriction')
  { return $agt->submit(q{.}, 'FILTER.ADD_RESTRICT',
      family => $fam,
      paths  => [map {RDA::Object::decode($_)} @arg]);
  }
  if ($typ eq 'set' || $typ eq 'rule')
  { return $agt->submit(q{.}, 'FILTER.ADD_SET',
      args => [map {RDA::Object::decode($_)} @arg]);
  }
  if ($typ eq 'tag')
  { $lvl = _get_cfm(\@arg);
    return $agt->submit(q{.}, 'FILTER.ADD_TAG',
      cfm  => $lvl,
      tags => [map {RDA::Object::decode($_)} @arg]);
  }
  return 1;
}

sub _get_cfm
{ my ($tbl) = @_;

  return (@{$tbl} && $tbl->[0] =~ m/^\d$/) ? shift(@{$tbl}) : undef;
}

sub _get_level
{ my ($tbl) = @_;

  return (@{$tbl} && $tbl->[0] =~ m/^\d+$/) ? shift(@{$tbl}) : undef;
}

=head2 S<clear -f>

This command disables the filter and clears the filter definition. It performs
this operation only when you specify the B<-f> switch.

=head2 S<delete file path...>

This command deletes any customer file management level associated to the
specified files.

=head2 S<delete format name...>

This command deletes the specified user-defined substitution formats.

=head2 S<delete meta path...>

This command removes directory structures from the list of directories where
status file information can be collected.

=head2 S<delete module name...>

This command deletes any customer file management level associated to the
specified modules.

=head2 S<delete pattern name [offset...]>

This command deletes the specified patterns from the pattern list of the
specified rule set. Patterns are referenced by their offset in the list.

=head2 S<delete report name...>

This command deletes any customer file management level associated to the
specified reports.

=head2 S<delete [unix|vms|windows] restriction path...>

This command removes the specified commands from the list of commands with
execution restrictions.

=head2 S<delete set name...>

This command deletes the specified rule set.

=head2 S<delete tag name...>

This command deletes any customer file management level associated to the
specified tags.

=cut

sub delete  ## no critic (Builtin)
{ my ($agt, @arg) = @_;
  my ($fam, $nam, $typ);

  # Treat the options
  RDA::Options::getopts(q{}, \@arg);

  # Treat the request
  $typ = lc(shift(@arg) || q{});
  if (exists($tb_fam{$typ}))
  { $fam = $typ;
    $typ = lc(shift(@arg) || q{});
  }
  if ($typ eq 'file')
  { return $agt->submit(q{.}, 'FILTER.DEL_FILE',
      paths => [@arg]);
  }
  if ($typ eq 'format')
  { return $agt->submit(q{.}, 'FILTER.DEL_FORMAT',
      names => [@arg]);
  }
  if ($typ eq 'meta')
  { return $agt->submit(q{.}, 'FILTER.DEL_META',
      paths => [@arg]);
  }
  if ($typ eq 'module')
  { return $agt->submit(q{.}, 'FILTER.DEL_MODULE',
      names => [@arg]);
  }
  if ($typ eq 'pattern')
  { $nam = shift(@arg);
    return $agt->submit(q{.}, 'FILTER.DEL_PATTERN',
      name    => $nam,
      offsets => [@arg]);
  }
  if ($typ eq 'report')
  { return $agt->submit(q{.}, 'FILTER.DEL_REPORT',
      names => [@arg]);
  }
  if ($typ eq 'restrict' || $typ eq 'restriction')
  { return $agt->submit(q{.}, 'FILTER.DEL_RESTRICT',
      family => $fam,
      paths  => [@arg]);
  }
  if ($typ eq 'set' || $typ eq 'rule')
  { return $agt->submit(q{.}, 'FILTER.DEL_SET',
      names => [@arg]);
  }
  if ($typ eq 'tag')
  { return $agt->submit(q{.}, 'FILTER.DEL_TAG',
      tags => [@arg]);
  }
  return 1;
}

=head2 S<disable>

This command disables the filter. It generates the default filter configuration
if the module is not configured yet.

=head2 S<enable>

This command enables the filter. It generates the default filter configuration
if the module is not configured yet.

=head2 S<expand [-e name,...] meta dir...>

This command replaces recursive directory specifications by equivalent
descriptions where the directory and all its subdirectories have their own
specifications (one level at the time). It will exclude the subdirectories
specified by the -e switch.

=cut

sub expand
{ my ($agt, @arg) = @_;
  my ($opt, $typ);

  # Treat the options
  $opt = RDA::Options::getopts(q{e*}, \@arg);

  # Treat the request
  $typ = lc(shift(@arg) || q{});
  return ($typ eq 'meta')
    ? $agt->submit(q{.}, 'FILTER.EXP_META',
        excludes => $opt->{'e'},
        paths    => [@arg])
    : 1;
}

=head2 S<export>

This command exports the filter definition.

=head2 S<help>

This command displays the command syntax and the related explanations.

=cut

sub help
{ return shift->submit(q{.}, 'DISPLAY.DSP_POD', package => __PACKAGE__);
}

=head2 S<list cfm [files|modules|reports|tags]...>

This command list the user-defined customer file management elements of the
specified type or all of them when no type is provided.

=head2 S<list formats>

This command lists the defined substitution formats.

=head2 S<list [-a] meta>

This command lists directories where status file information can be collected.
When the C<-a> option is specified, it shows the expanded list of directories
instead of the list of top directories with their respective recursion level.

=head2 S<list restrictions>

This command lists the commands with execution restrictions.

=head2 S<list set [name...]>

This command provides the description of the specified rules.

=head2 S<list sets>

This command lists the defined rules.

=cut

sub list  ## no critic (Complexity)
{ my ($agt, @arg) = @_;
  my ($buf, $fct, $opt, $rsp, $typ, @tbl);

  # Treat the options
  $opt = RDA::Options::getopts(q{a}, \@arg);

  # Treat the request
  $buf = q{};
  $typ = lc(shift(@arg) || q{});
  if ($typ eq 'cfm')
  { @arg = sort keys(%tb_cfm) unless @arg;
    foreach my $arg (@arg)
    { return 1 unless exists($tb_cfm{$arg});
      $rsp = $agt->submit(q{.}, RDA::Object::Message->new($tb_cfm{$arg}->[0]));
      return $rsp unless $rsp->is_success;
      $buf .= (@tbl = $rsp->get_value('list'))
        ? join(qq{\n}, q{.M 2 '}.get_string($tb_cfm{$arg}->[2]).q{'},
            map {join(q{|}, reverse split(/\001/, $_, 2))} @tbl).qq{\n\n}
        : get_string($tb_cfm{$arg}->[1]);
      $buf .= qq{.N 1\n}
    }
    return $agt->submit(q{.}, RDA::Object::Message->new(
      'DISPLAY.DSP_REPORT')->add_data($buf));
  }
  if ($typ eq 'formats')
  { $rsp = $agt->submit(q{.}, RDA::Object::Message->new('FILTER.GET_FORMATS',
      separator => q{|}));
    return $rsp unless $rsp->is_success;
    $buf .= join(qq{\n}, q{.M 2 '}.get_string('TtlInternal').q{'}, @tbl)
      .qq{\n\n.N 1\n}
      if (@tbl = $rsp->get_value('internal'));
    $buf .= join(qq{\n}, q{.M 2 '}.get_string('TtlExternal').q{'}, @tbl)
      .qq{\n\n.N 1\n}
      if (@tbl = $rsp->get_value('external'));
    return $agt->submit(q{.}, RDA::Object::Message->new(
      'DISPLAY.DSP_REPORT')->add_data($buf || get_string('NoFormats')));
  }
  if ($typ eq 'meta')
  { $rsp = $agt->submit(q{.}, RDA::Object::Message->new('FILTER.GET_META',
      expanded => $opt->{'a'}));
    return $rsp unless $rsp->is_success;
    $fct = $opt->{'a'} ? \&_fmt_second : \&_fmt_reverse;
    $buf .= join(qq{\n}, q{.M 2 '}.get_string('TtlMeta').q{'},
      map {&$fct($_)} @tbl).qq{\n\n.N 1\n}
      if (@tbl = $rsp->get_value('list'));
    return $agt->submit(q{.}, RDA::Object::Message->new(
      'DISPLAY.DSP_REPORT')->add_data($buf || get_string('NoMeta')));
  }
  if ($typ eq 'restrictions')
  { $rsp = $agt->submit(q{.}, RDA::Object::Message->new('FILTER.GET_RESTRICT',
      separator => q{|}));
    return $rsp unless $rsp->is_success;
    $buf .= join(qq{\n}, q{.M 2 '}.get_string('TtlRestrict').q{'},
                         @tbl).qq{\n\n.N 1\n}
      if (@tbl = $rsp->get_value('list'));
    return $agt->submit(q{.}, RDA::Object::Message->new(
      'DISPLAY.DSP_REPORT')->add_data($buf || get_string('NoRestrict')));
  }
  if ($typ eq 'set' || $typ eq 'rule')
  { return $agt->submit(q{.}, 'FILTER.DSP_SET', names => [@arg]);
  }
  if ($typ eq 'sets' || $typ eq 'rules')
  { $rsp = $agt->submit(q{.}, RDA::Object::Message->new('FILTER.GET_SETS',
      separator => q{|}));
    return $rsp unless $rsp->is_success;
    $buf .= join(qq{\n}, q{.M 2 '}.get_string('TtlSets').q{'},
      @tbl).qq{\n\n.N 1\n} if (@tbl = $rsp->get_value('sets'));
    return $agt->submit(q{.}, RDA::Object::Message->new(
      'DISPLAY.DSP_REPORT')->add_data($buf || get_string('NoSets')));
  }
  return 1;
}

sub _fmt_reverse
{ my ($str) = @_;

  return join(q{|}, reverse split(/\001/, $str, 2));
}

sub _fmt_second
{ my ($str) = @_;

  (undef, $str) = split(/\001/, $str, 2);
  return qq{$str|\\240};
}

=head2 S<reset [-f]>

This command resets the filter, restoring its default configuration. It performs
this operation only when you specify the B<-f> switch.

=head2 S<set cfm max>

This command specifies the maximum customer file management level to include
in the result set.

=head2 S<set format name string>

This command sets the substitution format for the specified rule set.

=head2 S<set gid min>

This command specifies the minimum group identifier to consider for scrubbing
groups for UNIX. When no value is provided, it restores the default value.

=head2 S<set options name string>

This command sets the matching options for the specified rule set.

=head2 S<set regroup number>

This command specifies the number of patterns that can be regrouped in a
substitution statement. When no value is provided, it restores the default
value.

=head2 S<set string name string>

This command sets the substitution string for the specified rule set.

=head2 S<set uid min>

This command specifies the minimum user identified to consider for scrubbing
users for UNIX. When no value is provided, it restores the default value.

=cut

sub set
{ my ($agt, @arg) = @_;
  my ($nam, $typ);

  # Treat the options
  RDA::Options::getopts(q{}, \@arg);

  # Validate the request
  return 1 unless exists($tb_set{$typ = lc(shift(@arg) || q{})});

  # Treat a limit request
  return $agt->submit(q{.}, 'FILTER.SET',
    $typ => RDA::Object::decode(shift(@arg) || q{}))
    if $tb_set{$typ};

  # Treat a definition request
  $nam = shift(@arg) || q{};
  return $agt->submit(q{.}, 'FILTER.DEFINE',
    name  => $nam,
    $typ => RDA::Object::decode(shift(@arg) || q{}));
}

=head2 S<test [-d]>

This command tests the filter generation. When the B<-d> switch is set, it
displays the rule code also.

=head1 AUTOMATIC FILTERING COMMANDS

=head2 S<default>

This command generates temporary properties containing the default filter
configuration.

=head2 S<remove>

This command removes the saved filter definition from the work directory.

=head2 S<save>

This command saves the definition of an active filter in the work directory. It
does not perform the operation unless the filter is enabled.

=cut

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Object|RDA::Object>,
L<RDA::Object::Message|RDA::Object::Message>,
L<RDA::Options|RDA::Options>,
L<RDA::Request::DISPLAY|RDA::Request::DISPLAY>,
L<RDA::Request::FILTER|RDA::Request::FILTER>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2015, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
