                   RDA - Oracle Remote Diagnostic Agent (RDA)

RDA BUILD
=========
RDA/DA bundle RDA 8.10-20151208 for Linux x64

PURPOSE
=======
RDA is a set of command line diagnostic scripts that are executed by an engine
written in the Perl programming language. RDA is used to gather detailed
information about an Oracle environment; the data gathered is in turn used to
aid in problem diagnosis. The output is also useful for seeing the overall
system configuration. You can find more information on RDA in the My Oracle
Support (MOS) document https://support.oracle.com/rs?type=doc&id=314422.1

Besides RDA product the RDA distribution kit archive (bundle) includes:
  - RDA compiled engine, rda_lin64, which is used when Perl is not available
    or there are issues with the Perl configuration.
  - The Diagnostic Assistant (DA) tool, which provides a common, light-weight
    interface to multiple diagnostic collection tools (Automatic Diagnostic
    Repository, RDA, Oracle Configuration Manager (OCM), and others).
    You can find more information about DA in the MOS document
    https://support.oracle.com/rs?type=doc&id=201804.1

Oracle Support encourages the use of RDA because it provides a comprehensive
picture of the customer's environment. This can greatly reduce service request
resolution time by minimizing the number of requests from Oracle Customer
Support for more information. RDA is designed to be as unobtrusive as possible;
it does not modify systems in any way, it only collects useful data for Oracle
Customer Support.

DOWNLOAD INSTRUCTIONS
=====================
Confirm the RDA patch selection is the correct platform for your system.
Otherwise, select the correct platform from the patch list of values or
select the correct platform from the MOS RDA "Getting Started" document
314422.1 download table, located at
https://support.oracle.com/rs?type=doc&id=314422.1#download

COMPLEMENTARY INFORMATION ON TOOL INSTALLATION AND USAGE
========================================================
Archive contains additional README files:
./rda/README_Unix.txt - Provides platform specific information.
./rda/README_irda.txt - Provides information on the RDA interface with the
                        Incident Packaging System.
./rda/engine/README_engine.txt - Provides information on the compiled engine.

When extracting the RDA distribution kit archive contents, put it into a new
directory, preserving the directory structure of the archive. Do not extract
into a directory that contains an older RDA version.

ADDITIONAL REFERENCE MATERIAL
=============================
For detailed information on RDA installation, review MOS document
https://support.oracle.com/rs?type=doc&id=314422.1#install - section
"Installation Instructions".

For the FAQ (frequently asked questions), review MOS document
 https://support.oracle.com/rs?type=doc&id=330363.1
